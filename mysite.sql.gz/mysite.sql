-- MariaDB dump 10.19  Distrib 10.11.11-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: db
-- ------------------------------------------------------
-- Server version	10.11.11-MariaDB-ubu2204-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `backend_layout`
--

DROP TABLE IF EXISTS `backend_layout`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `backend_layout` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `sorting` int(11) NOT NULL DEFAULT 0,
  `description` text DEFAULT NULL,
  `t3ver_oid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_wsid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `title` varchar(255) NOT NULL DEFAULT '',
  `config` longtext DEFAULT NULL,
  `icon` int(10) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`,`hidden`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `backend_layout`
--

LOCK TABLES `backend_layout` WRITE;
/*!40000 ALTER TABLE `backend_layout` DISABLE KEYS */;
/*!40000 ALTER TABLE `backend_layout` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `be_groups`
--

DROP TABLE IF EXISTS `be_groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `be_groups` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `description` text DEFAULT NULL,
  `tables_select` longtext DEFAULT NULL,
  `title` varchar(50) NOT NULL DEFAULT '',
  `db_mountpoints` longtext DEFAULT NULL,
  `file_mountpoints` varchar(255) DEFAULT '',
  `file_permissions` longtext DEFAULT NULL,
  `workspace_perms` smallint(5) unsigned NOT NULL DEFAULT 0,
  `pagetypes_select` longtext DEFAULT NULL,
  `tables_modify` longtext DEFAULT NULL,
  `non_exclude_fields` longtext DEFAULT NULL,
  `explicit_allowdeny` longtext DEFAULT NULL,
  `allowed_languages` varchar(255) NOT NULL DEFAULT '',
  `custom_options` longtext DEFAULT NULL,
  `groupMods` longtext DEFAULT NULL,
  `mfa_providers` longtext DEFAULT NULL,
  `TSconfig` longtext DEFAULT NULL,
  `subgroup` varchar(255) DEFAULT '',
  `category_perms` longtext DEFAULT NULL,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`,`hidden`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `be_groups`
--

LOCK TABLES `be_groups` WRITE;
/*!40000 ALTER TABLE `be_groups` DISABLE KEYS */;
/*!40000 ALTER TABLE `be_groups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `be_sessions`
--

DROP TABLE IF EXISTS `be_sessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `be_sessions` (
  `ses_id` varchar(190) NOT NULL DEFAULT '',
  `ses_iplock` varchar(39) NOT NULL DEFAULT '',
  `ses_userid` int(10) unsigned NOT NULL DEFAULT 0,
  `ses_tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `ses_data` longblob DEFAULT NULL,
  PRIMARY KEY (`ses_id`),
  KEY `ses_tstamp` (`ses_tstamp`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `be_sessions`
--

LOCK TABLES `be_sessions` WRITE;
/*!40000 ALTER TABLE `be_sessions` DISABLE KEYS */;
INSERT INTO `be_sessions` VALUES
('b9bd361adef8a740e9ac03f2d541bdd2af332a9671572f7606fe5afec1034593','[DISABLED]',1,1762879424,'a:1:{s:26:\"formProtectionSessionToken\";s:64:\"7695b0b3e4f499dcc15feec7641e97883ea344493481b007b36a2111da034db3\";}');
/*!40000 ALTER TABLE `be_sessions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `be_users`
--

DROP TABLE IF EXISTS `be_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `be_users` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `disable` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `description` text DEFAULT NULL,
  `lang` varchar(10) NOT NULL DEFAULT 'default',
  `uc` mediumblob DEFAULT NULL,
  `workspace_id` int(11) NOT NULL DEFAULT 0,
  `mfa` mediumblob DEFAULT NULL,
  `password_reset_token` varchar(100) NOT NULL DEFAULT '',
  `username` varchar(50) NOT NULL DEFAULT '',
  `password` varchar(255) NOT NULL DEFAULT '',
  `usergroup` varchar(512) DEFAULT '',
  `avatar` int(10) unsigned NOT NULL DEFAULT 0,
  `db_mountpoints` longtext DEFAULT NULL,
  `file_mountpoints` varchar(255) DEFAULT '',
  `email` varchar(255) NOT NULL DEFAULT '',
  `realName` varchar(80) NOT NULL DEFAULT '',
  `admin` smallint(5) unsigned NOT NULL DEFAULT 0,
  `options` smallint(5) unsigned NOT NULL DEFAULT 3,
  `file_permissions` longtext DEFAULT NULL,
  `workspace_perms` smallint(5) unsigned NOT NULL DEFAULT 0,
  `userMods` longtext DEFAULT NULL,
  `allowed_languages` varchar(255) NOT NULL DEFAULT '',
  `TSconfig` longtext DEFAULT NULL,
  `lastlogin` bigint(20) NOT NULL DEFAULT 0,
  `category_perms` longtext DEFAULT NULL,
  PRIMARY KEY (`uid`),
  KEY `username` (`username`),
  KEY `parent` (`pid`,`deleted`,`disable`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `be_users`
--

LOCK TABLES `be_users` WRITE;
/*!40000 ALTER TABLE `be_users` DISABLE KEYS */;
INSERT INTO `be_users` VALUES
(1,0,1762268418,1762268418,0,0,0,0,NULL,'default','a:8:{s:10:\"moduleData\";a:15:{s:57:\"TYPO3\\CMS\\Backend\\Utility\\BackendUtility::getUpdateSignal\";a:0:{}s:10:\"FormEngine\";a:2:{i:0;a:1:{s:32:\"581106f297d9eed8dec1190ee4d6b04d\";a:5:{i:0;s:29:\"Only for orientation purposes\";i:1;a:5:{s:4:\"edit\";a:1:{s:10:\"tt_content\";a:1:{i:3;s:4:\"edit\";}}s:7:\"defVals\";N;s:12:\"overrideVals\";N;s:11:\"columnsOnly\";N;s:6:\"noView\";N;}i:2;s:33:\"&edit%5Btt_content%5D%5B3%5D=edit\";i:3;a:5:{s:5:\"table\";s:10:\"tt_content\";s:3:\"uid\";i:3;s:3:\"pid\";i:1;s:3:\"cmd\";s:4:\"edit\";s:12:\"deleteAccess\";b:1;}i:4;s:0:\"\";}}i:1;s:32:\"581106f297d9eed8dec1190ee4d6b04d\";}s:16:\"extensionmanager\";a:1:{s:6:\"filter\";s:5:\"Local\";}s:6:\"web_ts\";a:1:{s:6:\"action\";s:17:\"typoscript_active\";}s:12:\"pagetsconfig\";a:1:{s:6:\"action\";s:18:\"pagetsconfig_pages\";}s:8:\"web_info\";a:1:{s:6:\"action\";s:17:\"web_info_overview\";}s:17:\"web_linkvalidator\";a:4:{s:6:\"action\";s:6:\"report\";s:15:\"report_external\";s:1:\"0\";s:11:\"report_file\";s:1:\"0\";s:9:\"report_db\";s:1:\"0\";}s:29:\"web_typoscript_constanteditor\";a:2:{s:23:\"selectedTemplatePerPage\";a:1:{i:1;i:-1;}s:16:\"selectedCategory\";s:0:\"\";}s:25:\"web_typoscript_infomodify\";a:1:{s:23:\"selectedTemplatePerPage\";a:1:{i:1;i:-1;}}s:17:\"typoscript_active\";a:6:{s:18:\"sortAlphabetically\";b:1;s:28:\"displayConstantSubstitutions\";b:1;s:15:\"displayComments\";b:1;s:23:\"selectedTemplatePerPage\";a:1:{i:1;i:-1;}s:18:\"constantConditions\";a:0:{}s:15:\"setupConditions\";a:0:{}}s:16:\"browse_links.php\";a:1:{s:12:\"expandFolder\";s:15:\"1:/user_upload/\";}s:16:\"opendocs::recent\";a:8:{s:32:\"629911c017052e9e049ce359020150c0\";a:5:{i:0;s:0:\"\";i:1;a:5:{s:4:\"edit\";a:1:{s:10:\"tt_content\";a:1:{i:7;s:4:\"edit\";}}s:7:\"defVals\";N;s:12:\"overrideVals\";N;s:11:\"columnsOnly\";N;s:6:\"noView\";N;}i:2;s:33:\"&edit%5Btt_content%5D%5B7%5D=edit\";i:3;a:5:{s:5:\"table\";s:10:\"tt_content\";s:3:\"uid\";i:7;s:3:\"pid\";i:2;s:3:\"cmd\";s:4:\"edit\";s:12:\"deleteAccess\";b:1;}i:4;s:97:\"/typo3/module/web/layout?token=9333039d925519199bb1060a19d329b457883665&id=2#element-tt_content-7\";}s:32:\"93cbed4eb4b2d59d5f7fc2b4a0e73d27\";a:5:{i:0;s:9:\"Portraits\";i:1;a:5:{s:4:\"edit\";a:1:{s:12:\"sys_category\";a:1:{i:4;s:4:\"edit\";}}s:7:\"defVals\";N;s:12:\"overrideVals\";N;s:11:\"columnsOnly\";N;s:6:\"noView\";N;}i:2;s:35:\"&edit%5Bsys_category%5D%5B4%5D=edit\";i:3;a:5:{s:5:\"table\";s:12:\"sys_category\";s:3:\"uid\";i:4;s:3:\"pid\";i:2;s:3:\"cmd\";s:4:\"edit\";s:12:\"deleteAccess\";b:1;}i:4;s:91:\"/typo3/module/web/list?token=4c8c1274372531abe0ace0f66ce7bc54e39587f6&id=2&table=&pointer=1\";}s:32:\"71e35a864bbee0063e1653fa8d62ce89\";a:5:{i:0;s:7:\"Stories\";i:1;a:5:{s:4:\"edit\";a:1:{s:12:\"sys_category\";a:1:{i:3;s:4:\"edit\";}}s:7:\"defVals\";N;s:12:\"overrideVals\";N;s:11:\"columnsOnly\";N;s:6:\"noView\";N;}i:2;s:35:\"&edit%5Bsys_category%5D%5B3%5D=edit\";i:3;a:5:{s:5:\"table\";s:12:\"sys_category\";s:3:\"uid\";i:3;s:3:\"pid\";i:2;s:3:\"cmd\";s:4:\"edit\";s:12:\"deleteAccess\";b:1;}i:4;s:91:\"/typo3/module/web/list?token=4c8c1274372531abe0ace0f66ce7bc54e39587f6&id=2&table=&pointer=1\";}s:32:\"6f529c35c48999e9f852451d8ef1c69e\";a:5:{i:0;s:11:\"Architektur\";i:1;a:5:{s:4:\"edit\";a:1:{s:12:\"sys_category\";a:1:{i:2;s:4:\"edit\";}}s:7:\"defVals\";N;s:12:\"overrideVals\";N;s:11:\"columnsOnly\";N;s:6:\"noView\";N;}i:2;s:35:\"&edit%5Bsys_category%5D%5B2%5D=edit\";i:3;a:5:{s:5:\"table\";s:12:\"sys_category\";s:3:\"uid\";i:2;s:3:\"pid\";i:2;s:3:\"cmd\";s:4:\"edit\";s:12:\"deleteAccess\";b:1;}i:4;s:91:\"/typo3/module/web/list?token=4c8c1274372531abe0ace0f66ce7bc54e39587f6&id=2&table=&pointer=1\";}s:32:\"37a926f6067a3b35f828de1212b08f18\";a:5:{i:0;s:4:\"Alle\";i:1;a:5:{s:4:\"edit\";a:1:{s:12:\"sys_category\";a:1:{i:1;s:4:\"edit\";}}s:7:\"defVals\";N;s:12:\"overrideVals\";N;s:11:\"columnsOnly\";N;s:6:\"noView\";N;}i:2;s:35:\"&edit%5Bsys_category%5D%5B1%5D=edit\";i:3;a:5:{s:5:\"table\";s:12:\"sys_category\";s:3:\"uid\";i:1;s:3:\"pid\";i:2;s:3:\"cmd\";s:4:\"edit\";s:12:\"deleteAccess\";b:1;}i:4;s:91:\"/typo3/module/web/list?token=4c8c1274372531abe0ace0f66ce7bc54e39587f6&id=2&table=&pointer=1\";}s:32:\"f87337ea07fd5e46b7487a4d63a03a03\";a:5:{i:0;s:0:\"\";i:1;a:5:{s:4:\"edit\";a:1:{s:10:\"tt_content\";a:1:{i:8;s:4:\"edit\";}}s:7:\"defVals\";N;s:12:\"overrideVals\";N;s:11:\"columnsOnly\";N;s:6:\"noView\";N;}i:2;s:33:\"&edit%5Btt_content%5D%5B8%5D=edit\";i:3;a:5:{s:5:\"table\";s:10:\"tt_content\";s:3:\"uid\";i:8;s:3:\"pid\";i:6;s:3:\"cmd\";s:4:\"edit\";s:12:\"deleteAccess\";b:1;}i:4;s:77:\"/typo3/module/web/layout?token=9333039d925519199bb1060a19d329b457883665&id=6&\";}s:32:\"a3b9454ecc0d182884b26f9c529ddb87\";a:5:{i:0;s:29:\"Only for orientation purposes\";i:1;a:5:{s:4:\"edit\";a:1:{s:10:\"tt_content\";a:1:{i:4;s:4:\"edit\";}}s:7:\"defVals\";N;s:12:\"overrideVals\";N;s:11:\"columnsOnly\";N;s:6:\"noView\";N;}i:2;s:33:\"&edit%5Btt_content%5D%5B4%5D=edit\";i:3;a:5:{s:5:\"table\";s:10:\"tt_content\";s:3:\"uid\";i:4;s:3:\"pid\";i:1;s:3:\"cmd\";s:4:\"edit\";s:12:\"deleteAccess\";b:1;}i:4;s:97:\"/typo3/module/web/layout?token=9333039d925519199bb1060a19d329b457883665&id=1#element-tt_content-4\";}s:32:\"581106f297d9eed8dec1190ee4d6b04d\";a:5:{i:0;s:29:\"Only for orientation purposes\";i:1;a:5:{s:4:\"edit\";a:1:{s:10:\"tt_content\";a:1:{i:3;s:4:\"edit\";}}s:7:\"defVals\";N;s:12:\"overrideVals\";N;s:11:\"columnsOnly\";N;s:6:\"noView\";N;}i:2;s:33:\"&edit%5Btt_content%5D%5B3%5D=edit\";i:3;a:5:{s:5:\"table\";s:10:\"tt_content\";s:3:\"uid\";i:3;s:3:\"pid\";i:1;s:3:\"cmd\";s:4:\"edit\";s:12:\"deleteAccess\";b:1;}i:4;s:77:\"/typo3/module/web/layout?token=9333039d925519199bb1060a19d329b457883665&id=1&\";}}s:18:\"list/displayFields\";a:1:{s:10:\"tt_content\";a:2:{i:0;s:6:\"header\";i:1;s:3:\"uid\";}}s:9:\"clipboard\";a:5:{s:5:\"tab_1\";a:0:{}s:5:\"tab_2\";a:0:{}s:5:\"tab_3\";a:0:{}s:7:\"current\";s:6:\"normal\";s:6:\"normal\";a:2:{s:2:\"el\";a:1:{s:12:\"tt_content|4\";s:1:\"1\";}s:4:\"mode\";s:4:\"copy\";}}s:16:\"media_management\";a:1:{s:8:\"viewMode\";s:4:\"list\";}}s:14:\"emailMeAtLogin\";i:0;s:8:\"titleLen\";i:50;s:20:\"edit_docModuleUpload\";s:1:\"1\";s:15:\"moduleSessionID\";a:15:{s:57:\"TYPO3\\CMS\\Backend\\Utility\\BackendUtility::getUpdateSignal\";s:40:\"f38629e3c5ccea9ac4b38f69d85995fc77d260c6\";s:10:\"FormEngine\";s:40:\"f38629e3c5ccea9ac4b38f69d85995fc77d260c6\";s:16:\"extensionmanager\";s:40:\"a973cd6e7ff8d6d726bc835465262b849dc99635\";s:6:\"web_ts\";s:40:\"a973cd6e7ff8d6d726bc835465262b849dc99635\";s:12:\"pagetsconfig\";s:40:\"a973cd6e7ff8d6d726bc835465262b849dc99635\";s:8:\"web_info\";s:40:\"a973cd6e7ff8d6d726bc835465262b849dc99635\";s:17:\"web_linkvalidator\";s:40:\"a973cd6e7ff8d6d726bc835465262b849dc99635\";s:29:\"web_typoscript_constanteditor\";s:40:\"a973cd6e7ff8d6d726bc835465262b849dc99635\";s:25:\"web_typoscript_infomodify\";s:40:\"a973cd6e7ff8d6d726bc835465262b849dc99635\";s:17:\"typoscript_active\";s:40:\"a973cd6e7ff8d6d726bc835465262b849dc99635\";s:16:\"browse_links.php\";s:40:\"c726807608ecc3c73f97f7f440b7e04d9950fb05\";s:16:\"opendocs::recent\";s:40:\"c726807608ecc3c73f97f7f440b7e04d9950fb05\";s:18:\"list/displayFields\";s:40:\"c726807608ecc3c73f97f7f440b7e04d9950fb05\";s:9:\"clipboard\";s:40:\"c726807608ecc3c73f97f7f440b7e04d9950fb05\";s:16:\"media_management\";s:40:\"c726807608ecc3c73f97f7f440b7e04d9950fb05\";}s:11:\"tx_recycler\";a:3:{s:14:\"depthSelection\";i:0;s:14:\"tableSelection\";s:0:\"\";s:11:\"resultLimit\";i:25;}s:10:\"inlineView\";s:272:\"{\"pages\":{\"1\":{\"sys_file_reference\":{\"1\":\"\"}}},\"tt_content\":{\"NEW690a27611b66d675893037\":{\"sys_file_reference\":[2]},\"4\":{\"sys_file_reference\":[]},\"7\":{\"tx_mask_all_cases\":{\"26\":\"1\"},\"sys_file_reference\":[\"\",14,15,16,17,19,20,21,22,23]},\"3\":{\"sys_file_reference\":[24,25]}}}\";s:11:\"colorScheme\";s:5:\"light\";}',0,NULL,'','admin','$argon2i$v=19$m=65536,t=16,p=1$V24uVTh5RWdoMXVBSE5SZA$KVGROzdb/pPm0XSlVk6Y+5Sbtqx/LfACX8YigfbddUw','',0,NULL,'','','',1,3,NULL,0,NULL,'',NULL,1762859332,NULL);
/*!40000 ALTER TABLE `be_users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cache_hash`
--

DROP TABLE IF EXISTS `cache_hash`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `cache_hash` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `identifier` varchar(250) NOT NULL DEFAULT '',
  `expires` int(10) unsigned NOT NULL DEFAULT 0,
  `content` longblob DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `cache_id` (`identifier`(180),`expires`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache_hash`
--

LOCK TABLES `cache_hash` WRITE;
/*!40000 ALTER TABLE `cache_hash` DISABLE KEYS */;
/*!40000 ALTER TABLE `cache_hash` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cache_hash_tags`
--

DROP TABLE IF EXISTS `cache_hash_tags`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `cache_hash_tags` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `identifier` varchar(250) NOT NULL DEFAULT '',
  `tag` varchar(250) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `cache_id` (`identifier`(191)),
  KEY `cache_tag` (`tag`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache_hash_tags`
--

LOCK TABLES `cache_hash_tags` WRITE;
/*!40000 ALTER TABLE `cache_hash_tags` DISABLE KEYS */;
/*!40000 ALTER TABLE `cache_hash_tags` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cache_news_category`
--

DROP TABLE IF EXISTS `cache_news_category`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `cache_news_category` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `identifier` varchar(250) NOT NULL DEFAULT '',
  `expires` int(10) unsigned NOT NULL DEFAULT 0,
  `content` longblob DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `cache_id` (`identifier`(180),`expires`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache_news_category`
--

LOCK TABLES `cache_news_category` WRITE;
/*!40000 ALTER TABLE `cache_news_category` DISABLE KEYS */;
/*!40000 ALTER TABLE `cache_news_category` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cache_news_category_tags`
--

DROP TABLE IF EXISTS `cache_news_category_tags`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `cache_news_category_tags` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `identifier` varchar(250) NOT NULL DEFAULT '',
  `tag` varchar(250) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `cache_id` (`identifier`(191)),
  KEY `cache_tag` (`tag`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache_news_category_tags`
--

LOCK TABLES `cache_news_category_tags` WRITE;
/*!40000 ALTER TABLE `cache_news_category_tags` DISABLE KEYS */;
/*!40000 ALTER TABLE `cache_news_category_tags` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cache_pages`
--

DROP TABLE IF EXISTS `cache_pages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `cache_pages` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `identifier` varchar(250) NOT NULL DEFAULT '',
  `expires` int(10) unsigned NOT NULL DEFAULT 0,
  `content` longblob DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `cache_id` (`identifier`(180),`expires`)
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache_pages`
--

LOCK TABLES `cache_pages` WRITE;
/*!40000 ALTER TABLE `cache_pages` DISABLE KEYS */;
INSERT INTO `cache_pages` VALUES
(17,'redirects_5cf7be80ac62cdd792e84c860267c5cdf79ffc45',1762883024,'x�K�2���\0O�'),
(18,'redirects_df58248c414f342c81e056b40bee12d17a08bf61',1762883024,'x�K�2���\0O�');
/*!40000 ALTER TABLE `cache_pages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cache_pages_tags`
--

DROP TABLE IF EXISTS `cache_pages_tags`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `cache_pages_tags` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `identifier` varchar(250) NOT NULL DEFAULT '',
  `tag` varchar(250) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `cache_id` (`identifier`(191)),
  KEY `cache_tag` (`tag`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache_pages_tags`
--

LOCK TABLES `cache_pages_tags` WRITE;
/*!40000 ALTER TABLE `cache_pages_tags` DISABLE KEYS */;
/*!40000 ALTER TABLE `cache_pages_tags` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cache_rootline`
--

DROP TABLE IF EXISTS `cache_rootline`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `cache_rootline` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `identifier` varchar(250) NOT NULL DEFAULT '',
  `expires` int(10) unsigned NOT NULL DEFAULT 0,
  `content` longblob DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `cache_id` (`identifier`(180),`expires`)
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache_rootline`
--

LOCK TABLES `cache_rootline` WRITE;
/*!40000 ALTER TABLE `cache_rootline` DISABLE KEYS */;
INSERT INTO `cache_rootline` VALUES
(14,'1__0_0_1_1',1765036587,'x�mUK��6�+��Ek���S��!�!� 艠EJ&L�*I�m,��g$���q�!�=	��G�g�v[�f�\nU#��3G��,\rNZ��E�5��ì�m���j��;M�)�,j����١�2�,˭�8�L�	U`U[�{0x�$͑=�Z�;�Fpo�U��g��\\vӽ�fX�F�V�/�4��+���Y`�[��s0ZC0�f� �I�𘲭kT�z!�@4��6j�M�^��e���Q޶�:ı\0�o�ˡQ��]��Q����4�K�=)��1�	9��Ձ�oj�aX��ł�2��!͉aK:S�P�h�!RI����Y�)�Yx���Z�V�O�1�4������Xs\'��:�\n��:�����6ϒ����\r6�2�����n��(��M�+*��?�i(i\0R�z�������I��a&Y>���S���p��P�(rI�5J�ݜ��:�P#�xIG)�4�l5c0Lʗ�n�g�0���Jӓ7\'�f�j���C+�ͣb�J����]�|�rظᅤ1��:{����i�<�Y��W���`���\"�Sn�C�~\0w	^�1�<\Z��ի��SX:M&tU{�����v~�k�oGEo����χ���~���?_q�����ɱ�����hs�z��D��\ZA�<��}��/��L�\Z��^��.tN��ٗ�v�����-a��/\"�d��W��: �y�&���r�D�s�8������$��l�\ng�=PH�GZ�dc�Ҏ��%�|�̏~¦�Q�����f���!����\"�H����@d��J\n�����U�F-�0~33\0I��&�i��/\'����7�\n�vh��#V�[�hI$�\'��\'��/7�����B�f����\'-\'$py6K��C�{��f����K-�D�/��}�o��n�0����Ї�7�d߲�����oEm6y'),
(15,'1__0_0_0_0',1765036587,'x�mUK��6�+��Ek���S��!�!� 艠EJ&L�*I�m,��g$���q�!�=	��G�g�v[�f�\nU#��3G��,\rNZ��E�5��ì�m���j��;M�)�,j����١�2�,˭�8�L�	U`U[�{0x�$͑=�Z�;�Fpo�U��g��\\vӽ�fX�F�V�/�4��+���Y`�[��s0ZC0�f� �I�𘲭kT�z!�@4��6j�M�^��e���Q޶�:ı\0�o�ˡQ��]��Q����4�K�=)��1�	9��Ձ�oj�aX��ł�2��!͉aK:S�P�h�!RI����Y�)�Yx���Z�V�O�1�4������Xs\'��:�\n��:�����6ϒ����\r6�2�����n��(��M�+*��?�i(i\0R�z�������I��a&Y>���S���p��P�(rI�5J�ݜ��:�P#�xIG)�4�l5c0Lʗ�n�g�0���Jӓ7\'�f�j���C+�ͣb�J����]�|�rظᅤ1��:{����i�<�Y��W���`���\"�Sn�C�~\0w	^�1�<\Z��ի��SX:M&tU{�����v~�k�oGEo����χ���~���?_q�����ɱ�����hs�z��D��\ZA�<��}��/��L�\Z��^��.tN��ٗ�v�����-a��/\"�d��W��: �y�&���r�D�s�8������$��l�\ng�=PH�GZ�dc�Ҏ��%�|�̏~¦�Q�����f���!����\"�H����@d��J\n�����U�F-�0~33\0I��&�i��/\'����7�\n�vh��#V�[�hI$�\'��\'��/7�����B�f����\'-\'$py6K��C�{��f����K-�D�/��}�o��n�0����Ї�7�d߲�����oEm6y'),
(16,'2__0_0_0_0',1765036588,'x��WK��6�+��Ab��՞�&hE�AO-Q2aITI*^c���CIQ��h��8�P�~P4�����4������d�e�����R=R)P�<�JӶ��~�e�t�]!��%�,�w���I�\Z�����yY��yR�ּe��XW��!O*Fj)P��4OV	^TBj����љn�D��G�\n�{����\"X�u#�����5�HC�z�5#�y�M��HO%��Vb�E�/]yX�8���a%�*`�B�$�	FA��3IDd�ʃW5�Q��\\�p9d�UdPL��4F nc:U:~`�u��G�m���G�辝Dy��u��H��p|���/����c�Yg��D�!�Š���sRIђ�8�R+`��r�Zړ^r!��%X��w[p��Lx۳���:J��Pqѷ��Ѐ�\Z���\nJ雐wT�P\'x��������x��n\"{�A.DG����`S�[\0l����4�\"P>��p�!�*\nAG��`��q@�*n5��MSY3a��e�ȩ�_{��e$�cׯ��M0um�*Ό�n�}X�co��(Feq���: ���pa7�u�\\tS3Q��MOJKZh�I:h��y�@���]�g���\"�1�%��q;�\n$\"�ag�r���I)�:|Et��2K|���l;g���4�Y��rVXr�wE3��E��R&����%{��H�J4���c\'g�����X���/hC\Z�]�JD�Pm>�^�\0�U�m�}�\Z����0���B��WPY֫q{�����[��|띝_�ͷ;l,��|Ωq�V;��¸Oގ��vmtv�j�Y���⎱�hŴ�U�T��Fz��,\Z�!n�X\"�)�U$��ݢ!͖\Zo\'��a(Z*�����1\\8���˞����~�#Ɔ\'q�x�MvK�:�cء��4M���fm�q�!��Y<�\n5KO������RnI�9���x�L����15�����I�?��0�h�I�����7ڔ�o>��?�������gz����a�_���H|���f�'),
(17,'6__0_0_0_0',1765036588,'x��XK��6�+��F�m٫=I��=�9�DɄ%Q%�x�����(�=�@�,��r8��G�d��e�ɶi�\"A�zVD,K��Y))�\"%i:\r�m��W	J�V���(:� �l���5U�X���#+\n��}�U�k��6�!�ˢ��J���ʢ8�%����r��F�,����\\�N1G=Z�`���i���y��&mՓ�bwy��3j��#��jKދ����V&�@�qX��rX0��eBE����Z}����x\0�r�E�QW�j��!�Ľ��ZA�	���N7ht���`�������ξxq�@����|�?}������>�q���9�GH`ޫ0\'9o���78p�����:�Lцt���.�-��׍	8T�zƬ��s�aA�YW(?�KG�Ѐ�\n���\n��H$�k�\"T���*rU�����}~q`���/Y�j@���a%(���.�s���*�^\0\"� 5��i@�3ģx����Ave��|��_gcga����d�/�=MDEU�� �\00%O����/�-=i���+}��H�����W�*���\0ǒ�C+CU��O�p�z!]t��/�>\'�ɕ���W`0�S2�*��ׅ�70(�,Lb]f�s6��G�}R\r�<%5ڵ8/+�J�@�d)���\\�[�\\C�M���[ڒì�뾠�\0KʯV��}k���5?{wcs�G��������Nl�[��\Z׬=M���h��ky�5fz���ԙ)������[�7.�&�.\'��W=�d�L�]#�d�֛�\Zj�*������\rW�7@�PJ_��fD�q<x����0��xc��|��C拯3�*5�k�|�nm4��K�E��ũf>?.�&��Ƶ�����5�Af�s;ƨ��nV9hR��s��sB2hX�pLbs+��Za>�\r��l���n2��������R0�0���9�i�����%�~Vf����D;X�Mv#�:�l�RpҔ7\r4+h��3Ί˙5��������o>+di$G��;�����|� ��O������OB�-��I \Z��$���Jꢥ��3o����ވ�����>D?������{$��\rϐ��'),
(18,'3__0_0_0_0',1765036588,'x��VK��6�+��A#��՞�&H\n9�=�DɄ%Q%�x����9$EY>�R�Ar�|C\r��\ri�/��i��/�X�ȫ��G+\r(e m�D+M���m���z��RVT��&ͮH*�2ͬ�ϞxU��EV�ּc��X_�ȾHjF\Z)F�^Y��	TBj�7��&ˍn]$R\\>0UJ>h.�/h�U\\��<{�x�����oF�0₷:���ҞT�^/`%FY�������\\�mV�������$I�`���DD����_�������PC&;EF��TL��6��K�l\'d�|t����ň8���GQ]�%P�:����~���˧�|���*}����u\\�R�\ZrNj):9Y����aSC�YG2H.$���7�ec]��	��<8�De6*��:0�\Zp[C��ZA+����}�vl<�;\"x:��5o\\�MfOђ1���̖P�<`��@�#�ҫ���=C�\'q��SE)��7<t6�CW�#����A3�T6LG��z�F�mr����LuY���k�y\\]���#fZ�Ҡ�M�	@Ũ,O������z�R.��a��dӣҒ�\Z��\Z�1�$�+<��5ЛpELcI!t<N��i�\Z�\ZoK�f���u~�&:���%���|��U����0Y��vV�r��e;V�e�p)w�C�ъ=�m$H-�V\\�w�i��P\"�%�;�ymjڋ���%-���KD������;KU�i�}�\Z����0���F�IWRYի	{�����K�o��vu�m�k���6�j�����;X|�tk6_�K���4�(��F�nX-r3:w�xb�:��Xv\\�YG;,�4ʷɢq\"�6�B�QrUE��-\Z�l���v�D�h�@3(E��)]�s���e�������Q\n��E$/9f����{\'�K�M�i������q(.9k��W�f��W>����[����E8���NS3(��C>	כ��I�C6��uMY��O�V=�o>��?�������Gzf���a������H|�޵f�'),
(19,'5__0_0_0_0',1765036588,'x��WK��6�+��A+ɶ�՞��h��\r��Z\ZɄ%Q%�x�����(ɇZ As�|C��o��y���<y��>�_e�ɣ���#�w�Fꭔ��呒����Y�M���j\nQR3M��}�ЀsJl��YYB7y��\n�X#��AW��!�* ��^/�$���n�\\(��zc��[�m	~���W��UO�(�jxqOM�5�&IC�z�5g���Mw��:��%D�ߗ�#���d簒Uո�¯QG�$�<��\"˃�|Ax��x�r�2��������E�$�1�3ٌ�au~��F7�;>د�t�̱8�ݷ/o�$T�:��?�����_?��g�\\1����M*�[�	�i�����yLAK{��S��Fm���0��^k{x�	n�����u�ad_�0>����\'�J�]�I�9F�l�:rT��ʹh��__��9_�{�\0�އ��\Z�R�@d3��7>\'^����S�N�!:��{��|\n,g�fz8-7�d��`:�E\0&֩T�{��e�;4�s�X㟺�Fg :iCb��uh�6�	T��1*H��0�/p�rQJ�n��:��I*Ae4�\nmJG�`��\\���.`��0��0�|<�i�4\\K�4ɡ#EU��1�N���g��r�?�-���( \r���9:��\r9º�Jp��\n�npp�Z�KF�T�i�տ�0�Uq�����Û�ڧ�XAҰ�2��׫��\'�s¬5�jڍq��L�����I�:.�puh:�\n*J�z�f�`2k����7��p���ak4�UtF��_�˾��w�3�\0}�DK�O�k%����%�A�s3ƨ�ʮV9h��u����d�0-���<�Vr^�²�Ի�H.V�:�D�E�H��X)(���u�.m�2�p(y4+�5�J�l��-,��*��?b6CG)�i�7\r�h�M5Ί�5���`Q����\'��fi$�$�:�W���a}�!+��ej�{�gs��s�nw��w0 �����(4���Mفx����qR�v��q�1�{�a�mχ!�?�į��3ikN'),
(20,'2__0_0_1_1',1765451357,'x��WK��6�+��Ab��՞�&hE�AO-Q2aITI*^c���CIQ��h��8�P�~P4�����4������d�e�����R=R)P�<�JӶ��~�e�t�]!��%�,�w���I�\Z�����yY��yR�ּe��XW��!O*Fj)P��4OV	^TBj����љn�D��G�\n�{����\"X�u#�����5�HC�z�5#�y�M��HO%��Vb�E�/]yX�8���a%�*`�B�$�	FA��3IDd�ʃW5�Q��\\�p9d�UdPL��4F nc:U:~`�u��G�m���G�辝Dy��u��H��p|���/����c�Yg��D�!�Š���sRIђ�8�R+`��r�Zړ^r!��%X��w[p��Lx۳���:J��Pqѷ��Ѐ�\Z���\nJ雐wT�P\'x��������x��n\"{�A.DG����`S�[\0l����4�\"P>��p�!�*\nAG��`��q@�*n5��MSY3a��e�ȩ�_{��e$�cׯ��M0um�*Ό�n�}X�co��(Feq���: ���pa7�u�\\tS3Q��MOJKZh�I:h��y�@���]�g���\"�1�%��q;�\n$\"�ag�r���I)�:|Et��2K|���l;g���4�Y��rVXr�wE3��E��R&����%{��H�J4���c\'g�����X���/hC\Z�]�JD�Pm>�^�\0�U�m�}�\Z����0���B��WPY֫q{�����[��|띝_�ͷ;l,��|Ωq�V;��¸Oގ��vmtv�j�Y���⎱�hŴ�U�T��Fz��,\Z�!n�X\"�)�U$��ݢ!͖\Zo\'��a(Z*�����1\\8���˞����~�#Ɔ\'q�x�MvK�:�cء��4M���fm�q�!��Y<�\n5KO������RnI�9���x�L����15�����I�?��0�h�I�����7ڔ�o>��?�������gz����a�_���H|���f�'),
(21,'6__0_0_1_1',1765451363,'x��XK��6�+��F�m٫=I��=�9�DɄ%Q%�x�����(�=�@�,��r8��G�d��e�ɶi�\"A�zVD,K��Y))�\"%i:\r�m��W	J�V���(:� �l���5U�X���#+\n��}�U�k��6�!�ˢ��J���ʢ8�%����r��F�,����\\�N1G=Z�`���i���y��&mՓ�bwy��3j��#��jKދ����V&�@�qX��rX0��eBE����Z}����x\0�r�E�QW�j��!�Ľ��ZA�	���N7ht���`�������ξxq�@����|�?}������>�q���9�GH`ޫ0\'9o���78p�����:�Lцt���.�-��׍	8T�zƬ��s�aA�YW(?�KG�Ѐ�\n���\n��H$�k�\"T���*rU�����}~q`���/Y�j@���a%(���.�s���*�^\0\"� 5��i@�3ģx����Ave��|��_gcga����d�/�=MDEU�� �\00%O����/�-=i���+}��H�����W�*���\0ǒ�C+CU��O�p�z!]t��/�>\'�ɕ���W`0�S2�*��ׅ�70(�,Lb]f�s6��G�}R\r�<%5ڵ8/+�J�@�d)���\\�[�\\C�M���[ڒì�뾠�\0KʯV��}k���5?{wcs�G��������Nl�[��\Z׬=M���h��ky�5fz���ԙ)������[�7.�&�.\'��W=�d�L�]#�d�֛�\Zj�*������\rW�7@�PJ_��fD�q<x����0��xc��|��C拯3�*5�k�|�nm4��K�E��ũf>?.�&��Ƶ�����5�Af�s;ƨ��nV9hR��s��sB2hX�pLbs+��Za>�\r��l���n2��������R0�0���9�i�����%�~Vf����D;X�Mv#�:�l�RpҔ7\r4+h��3Ί˙5��������o>+di$G��;�����|� ��O������O��f�}O���\')KB뻯�.Z*�>�fx.��%�F����!��߇��#����7���');
/*!40000 ALTER TABLE `cache_rootline` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cache_rootline_tags`
--

DROP TABLE IF EXISTS `cache_rootline_tags`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `cache_rootline_tags` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `identifier` varchar(250) NOT NULL DEFAULT '',
  `tag` varchar(250) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `cache_id` (`identifier`(191)),
  KEY `cache_tag` (`tag`(191))
) ENGINE=InnoDB AUTO_INCREMENT=41 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache_rootline_tags`
--

LOCK TABLES `cache_rootline_tags` WRITE;
/*!40000 ALTER TABLE `cache_rootline_tags` DISABLE KEYS */;
INSERT INTO `cache_rootline_tags` VALUES
(25,'1__0_0_1_1','pageId_1'),
(26,'1__0_0_0_0','pageId_1'),
(27,'2__0_0_0_0','pageId_1'),
(28,'2__0_0_0_0','pageId_2'),
(29,'6__0_0_0_0','pageId_1'),
(30,'6__0_0_0_0','pageId_2'),
(31,'6__0_0_0_0','pageId_6'),
(32,'3__0_0_0_0','pageId_1'),
(33,'3__0_0_0_0','pageId_3'),
(34,'5__0_0_0_0','pageId_1'),
(35,'5__0_0_0_0','pageId_5'),
(36,'2__0_0_1_1','pageId_1'),
(37,'2__0_0_1_1','pageId_2'),
(38,'6__0_0_1_1','pageId_1'),
(39,'6__0_0_1_1','pageId_2'),
(40,'6__0_0_1_1','pageId_6');
/*!40000 ALTER TABLE `cache_rootline_tags` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fe_groups`
--

DROP TABLE IF EXISTS `fe_groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `fe_groups` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `description` text DEFAULT NULL,
  `title` varchar(50) NOT NULL DEFAULT '',
  `subgroup` varchar(255) DEFAULT '',
  `felogin_redirectPid` longtext DEFAULT NULL,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`,`hidden`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fe_groups`
--

LOCK TABLES `fe_groups` WRITE;
/*!40000 ALTER TABLE `fe_groups` DISABLE KEYS */;
/*!40000 ALTER TABLE `fe_groups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fe_sessions`
--

DROP TABLE IF EXISTS `fe_sessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `fe_sessions` (
  `ses_id` varchar(190) NOT NULL DEFAULT '',
  `ses_iplock` varchar(39) NOT NULL DEFAULT '',
  `ses_userid` int(10) unsigned NOT NULL DEFAULT 0,
  `ses_tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `ses_data` mediumblob DEFAULT NULL,
  `ses_permanent` smallint(5) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`ses_id`),
  KEY `ses_tstamp` (`ses_tstamp`,`ses_userid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fe_sessions`
--

LOCK TABLES `fe_sessions` WRITE;
/*!40000 ALTER TABLE `fe_sessions` DISABLE KEYS */;
/*!40000 ALTER TABLE `fe_sessions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fe_users`
--

DROP TABLE IF EXISTS `fe_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `fe_users` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `disable` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `description` text DEFAULT NULL,
  `tx_extbase_type` varchar(255) NOT NULL DEFAULT '0',
  `uc` blob DEFAULT NULL,
  `is_online` int(10) unsigned NOT NULL DEFAULT 0,
  `mfa` mediumblob DEFAULT NULL,
  `felogin_forgotHash` varchar(80) DEFAULT '',
  `username` varchar(255) NOT NULL DEFAULT '',
  `password` varchar(255) NOT NULL DEFAULT '',
  `usergroup` varchar(512) DEFAULT '',
  `name` varchar(160) NOT NULL DEFAULT '',
  `first_name` varchar(50) NOT NULL DEFAULT '',
  `middle_name` varchar(50) NOT NULL DEFAULT '',
  `last_name` varchar(50) NOT NULL DEFAULT '',
  `address` longtext DEFAULT NULL,
  `telephone` varchar(30) NOT NULL DEFAULT '',
  `fax` varchar(30) NOT NULL DEFAULT '',
  `email` varchar(255) NOT NULL DEFAULT '',
  `title` varchar(40) NOT NULL DEFAULT '',
  `zip` varchar(10) NOT NULL DEFAULT '',
  `city` varchar(50) NOT NULL DEFAULT '',
  `country` varchar(40) NOT NULL DEFAULT '',
  `www` varchar(80) NOT NULL DEFAULT '',
  `company` varchar(80) NOT NULL DEFAULT '',
  `image` int(10) unsigned NOT NULL DEFAULT 0,
  `lastlogin` bigint(20) NOT NULL DEFAULT 0,
  `felogin_redirectPid` longtext DEFAULT NULL,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`username`(100)),
  KEY `username` (`username`(100)),
  KEY `is_online` (`is_online`),
  KEY `felogin_forgotHash` (`felogin_forgotHash`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fe_users`
--

LOCK TABLES `fe_users` WRITE;
/*!40000 ALTER TABLE `fe_users` DISABLE KEYS */;
/*!40000 ALTER TABLE `fe_users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pages`
--

DROP TABLE IF EXISTS `pages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `pages` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `fe_group` varchar(255) NOT NULL DEFAULT '0',
  `sorting` int(11) NOT NULL DEFAULT 0,
  `rowDescription` text DEFAULT NULL,
  `editlock` smallint(5) unsigned NOT NULL DEFAULT 0,
  `sys_language_uid` int(11) NOT NULL DEFAULT 0,
  `l10n_parent` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_source` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_state` text DEFAULT NULL,
  `l10n_diffsource` mediumblob DEFAULT NULL,
  `t3ver_oid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_wsid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `perms_userid` int(10) unsigned NOT NULL DEFAULT 0,
  `perms_groupid` int(10) unsigned NOT NULL DEFAULT 0,
  `perms_user` smallint(5) unsigned NOT NULL DEFAULT 0,
  `perms_group` smallint(5) unsigned NOT NULL DEFAULT 0,
  `perms_everybody` smallint(5) unsigned NOT NULL DEFAULT 0,
  `SYS_LASTCHANGED` int(10) unsigned NOT NULL DEFAULT 0,
  `shortcut` int(10) unsigned NOT NULL DEFAULT 0,
  `content_from_pid` int(10) unsigned NOT NULL DEFAULT 0,
  `mount_pid` int(10) unsigned NOT NULL DEFAULT 0,
  `sitemap_priority` decimal(2,1) NOT NULL DEFAULT 0.5,
  `tx_impexp_origuid` int(11) NOT NULL DEFAULT 0,
  `doktype` int(10) unsigned NOT NULL DEFAULT 0,
  `title` varchar(255) NOT NULL DEFAULT '',
  `slug` text DEFAULT NULL,
  `TSconfig` longtext DEFAULT NULL,
  `php_tree_stop` smallint(5) unsigned NOT NULL DEFAULT 0,
  `categories` int(10) unsigned NOT NULL DEFAULT 0,
  `layout` int(10) unsigned NOT NULL DEFAULT 0,
  `extendToSubpages` smallint(5) unsigned NOT NULL DEFAULT 0,
  `nav_title` varchar(255) NOT NULL DEFAULT '',
  `nav_hide` smallint(5) unsigned NOT NULL DEFAULT 0,
  `subtitle` varchar(255) NOT NULL DEFAULT '',
  `target` varchar(80) NOT NULL DEFAULT '',
  `url` varchar(255) NOT NULL DEFAULT '',
  `lastUpdated` bigint(20) NOT NULL DEFAULT 0,
  `newUntil` bigint(20) NOT NULL DEFAULT 0,
  `cache_timeout` int(10) unsigned NOT NULL DEFAULT 0,
  `cache_tags` varchar(255) NOT NULL DEFAULT '',
  `no_search` smallint(5) unsigned NOT NULL DEFAULT 0,
  `shortcut_mode` int(10) unsigned NOT NULL DEFAULT 0,
  `keywords` longtext DEFAULT NULL,
  `description` longtext DEFAULT NULL,
  `abstract` longtext DEFAULT NULL,
  `author` varchar(255) NOT NULL DEFAULT '',
  `author_email` varchar(255) NOT NULL DEFAULT '',
  `media` int(10) unsigned NOT NULL DEFAULT 0,
  `is_siteroot` smallint(5) unsigned NOT NULL DEFAULT 0,
  `mount_pid_ol` smallint(6) NOT NULL DEFAULT 0,
  `module` varchar(255) NOT NULL DEFAULT '',
  `l18n_cfg` smallint(5) unsigned NOT NULL DEFAULT 0,
  `backend_layout` varchar(64) NOT NULL DEFAULT '',
  `backend_layout_next_level` varchar(64) NOT NULL DEFAULT '',
  `tsconfig_includes` varchar(255) DEFAULT '',
  `seo_title` varchar(255) NOT NULL DEFAULT '',
  `no_index` smallint(5) unsigned NOT NULL DEFAULT 0,
  `no_follow` smallint(5) unsigned NOT NULL DEFAULT 0,
  `sitemap_changefreq` varchar(10) NOT NULL DEFAULT '',
  `canonical_link` text NOT NULL DEFAULT '',
  `og_title` varchar(255) NOT NULL DEFAULT '',
  `og_description` longtext DEFAULT NULL,
  `og_image` int(10) unsigned NOT NULL DEFAULT 0,
  `twitter_title` varchar(255) NOT NULL DEFAULT '',
  `twitter_description` longtext DEFAULT NULL,
  `twitter_image` int(10) unsigned NOT NULL DEFAULT 0,
  `twitter_card` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`uid`),
  KEY `determineSiteRoot` (`is_siteroot`),
  KEY `language_identifier` (`l10n_parent`,`sys_language_uid`),
  KEY `slug` (`slug`(127)),
  KEY `parent` (`pid`,`deleted`,`hidden`),
  KEY `translation_source` (`l10n_source`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pages`
--

LOCK TABLES `pages` WRITE;
/*!40000 ALTER TABLE `pages` DISABLE KEYS */;
INSERT INTO `pages` VALUES
(1,0,1762273638,1762268438,0,0,0,0,'',256,NULL,0,0,0,0,NULL,'{\"TSconfig\":\"\",\"abstract\":\"\",\"author\":\"\",\"author_email\":\"\",\"backend_layout\":\"\",\"backend_layout_next_level\":\"\",\"cache_tags\":\"\",\"cache_timeout\":\"\",\"canonical_link\":\"\",\"categories\":\"\",\"content_from_pid\":\"\",\"description\":\"\",\"doktype\":\"\",\"editlock\":\"\",\"endtime\":\"\",\"extendToSubpages\":\"\",\"fe_group\":\"\",\"hidden\":\"\",\"is_siteroot\":\"\",\"keywords\":\"\",\"l18n_cfg\":\"\",\"lastUpdated\":\"\",\"layout\":\"\",\"media\":\"\",\"module\":\"\",\"nav_hide\":\"\",\"nav_title\":\"\",\"newUntil\":\"\",\"no_follow\":\"\",\"no_index\":\"\",\"no_search\":\"\",\"og_description\":\"\",\"og_image\":\"\",\"og_title\":\"\",\"php_tree_stop\":\"\",\"rowDescription\":\"\",\"seo_title\":\"\",\"sitemap_changefreq\":\"\",\"sitemap_priority\":\"\",\"slug\":\"\",\"starttime\":\"\",\"subtitle\":\"\",\"target\":\"\",\"title\":\"\",\"tsconfig_includes\":\"\",\"twitter_card\":\"\",\"twitter_description\":\"\",\"twitter_image\":\"\",\"twitter_title\":\"\"}',0,0,0,0,1,0,31,27,0,1762444587,0,0,0,0.5,0,1,'Raffael Waldner Home','/',NULL,0,0,0,0,'',0,'','','',0,0,0,'',0,0,NULL,NULL,NULL,'','',0,1,0,'',0,'','','','',0,0,'','','',NULL,0,'',NULL,0,''),
(2,1,1762271450,1762271436,0,0,0,0,'0',256,NULL,0,0,0,0,NULL,'{\"hidden\":\"\"}',0,0,0,0,1,0,31,27,0,1762443238,0,0,0,0.5,0,1,'Work','/work',NULL,0,0,0,0,'',0,'','','',0,0,0,'',0,0,NULL,NULL,NULL,'','',0,0,0,'',0,'','',NULL,'',0,0,'','','',NULL,0,'',NULL,0,''),
(3,1,1762271448,1762271440,0,0,0,0,'0',512,NULL,0,0,0,0,NULL,'{\"hidden\":\"\"}',0,0,0,0,1,0,31,27,0,1762442309,0,0,0,0.5,0,1,'Info','/info',NULL,0,0,0,0,'',0,'','','',0,0,0,'',0,0,NULL,NULL,NULL,'','',0,0,0,'',0,'','',NULL,'',0,0,'','','',NULL,0,'',NULL,0,''),
(4,1,1762416828,1762416826,0,0,0,0,'0',768,NULL,0,0,0,0,NULL,'{\"hidden\":\"\"}',0,0,0,0,1,0,31,27,0,0,0,0,0,0.5,0,254,'Footer','/footer',NULL,0,0,0,0,'',0,'','','',0,0,0,'',0,0,NULL,NULL,NULL,'','',0,0,0,'',0,'','',NULL,'',0,0,'','','',NULL,0,'',NULL,0,''),
(5,1,1762419035,1762419030,0,0,0,0,'0',640,NULL,0,0,0,0,NULL,'{\"nav_hide\":\"\"}',0,0,0,0,1,0,31,27,0,1762419035,0,0,0,0.5,0,1,'Newsletter','/newsletter',NULL,0,0,0,0,'',1,'','','',0,0,0,'',0,0,NULL,NULL,NULL,'','',0,0,0,'',0,'','',NULL,'',0,0,'','','',NULL,0,'',NULL,0,''),
(6,2,1762432124,1762432121,0,0,0,0,'0',256,NULL,0,0,0,0,NULL,'{\"hidden\":\"\"}',0,0,0,0,1,0,31,27,0,1762432949,0,0,0,0.5,0,1,'Case nr1','/work/case-nr1',NULL,0,0,0,0,'',0,'','','',0,0,0,'',0,0,NULL,NULL,NULL,'','',0,0,0,'',0,'','','','',0,0,'','','',NULL,0,'',NULL,0,'');
/*!40000 ALTER TABLE `pages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_be_shortcuts`
--

DROP TABLE IF EXISTS `sys_be_shortcuts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_be_shortcuts` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `userid` int(10) unsigned NOT NULL DEFAULT 0,
  `route` varchar(255) NOT NULL DEFAULT '',
  `arguments` text DEFAULT NULL,
  `description` varchar(255) NOT NULL DEFAULT '',
  `sorting` int(11) NOT NULL DEFAULT 0,
  `sc_group` smallint(6) NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `event` (`userid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_be_shortcuts`
--

LOCK TABLES `sys_be_shortcuts` WRITE;
/*!40000 ALTER TABLE `sys_be_shortcuts` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_be_shortcuts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_category`
--

DROP TABLE IF EXISTS `sys_category`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_category` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `sorting` int(11) NOT NULL DEFAULT 0,
  `description` text DEFAULT NULL,
  `sys_language_uid` int(11) NOT NULL DEFAULT 0,
  `l10n_parent` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_state` text DEFAULT NULL,
  `l10n_diffsource` mediumblob DEFAULT NULL,
  `t3ver_oid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_wsid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `items` int(11) NOT NULL DEFAULT 0,
  `images` int(10) unsigned DEFAULT 0,
  `single_pid` int(10) unsigned NOT NULL DEFAULT 0,
  `shortcut` int(11) NOT NULL DEFAULT 0,
  `import_id` varchar(100) NOT NULL DEFAULT '',
  `import_source` varchar(100) NOT NULL DEFAULT '',
  `seo_title` varchar(255) NOT NULL DEFAULT '',
  `seo_description` text DEFAULT NULL,
  `seo_headline` varchar(255) NOT NULL DEFAULT '',
  `seo_text` text DEFAULT NULL,
  `slug` varchar(2048) DEFAULT NULL,
  `title` varchar(255) NOT NULL DEFAULT '',
  `parent` int(10) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `category_parent` (`parent`),
  KEY `category_list` (`pid`,`deleted`,`sys_language_uid`),
  KEY `import` (`import_id`,`import_source`),
  KEY `parent` (`pid`,`deleted`,`hidden`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_category`
--

LOCK TABLES `sys_category` WRITE;
/*!40000 ALTER TABLE `sys_category` DISABLE KEYS */;
INSERT INTO `sys_category` VALUES
(1,2,1762435256,1762435256,0,0,0,0,256,'',0,0,NULL,'',0,0,0,0,0,0,0,0,'','','',NULL,'',NULL,NULL,'Alle',0),
(2,2,1762435299,1762435264,0,0,0,0,512,'',0,0,NULL,'{\"description\":\"\",\"endtime\":\"\",\"hidden\":\"\",\"items\":\"\",\"parent\":\"\",\"starttime\":\"\",\"title\":\"\"}',0,0,0,0,0,0,0,0,'','','',NULL,'',NULL,NULL,'Architektur',0),
(3,2,1762443420,1762435305,0,0,0,0,576,'',0,0,NULL,'',0,0,0,0,0,0,0,0,'','','',NULL,'',NULL,NULL,'Stories',0),
(4,2,1762443398,1762435308,0,0,0,0,640,'',0,0,NULL,'',0,0,0,0,0,0,0,0,'','','',NULL,'',NULL,NULL,'Portraits',0);
/*!40000 ALTER TABLE `sys_category` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_category_record_mm`
--

DROP TABLE IF EXISTS `sys_category_record_mm`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_category_record_mm` (
  `uid_local` int(10) unsigned NOT NULL DEFAULT 0,
  `uid_foreign` int(10) unsigned NOT NULL DEFAULT 0,
  `sorting` int(10) unsigned NOT NULL DEFAULT 0,
  `sorting_foreign` int(10) unsigned NOT NULL DEFAULT 0,
  `tablenames` varchar(64) NOT NULL DEFAULT '',
  `fieldname` varchar(64) NOT NULL DEFAULT '',
  PRIMARY KEY (`uid_local`,`uid_foreign`,`tablenames`,`fieldname`),
  KEY `uid_local` (`uid_local`),
  KEY `uid_foreign` (`uid_foreign`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_category_record_mm`
--

LOCK TABLES `sys_category_record_mm` WRITE;
/*!40000 ALTER TABLE `sys_category_record_mm` DISABLE KEYS */;
INSERT INTO `sys_category_record_mm` VALUES
(2,1,0,1,'tx_mask_all_cases','tx_mask_catgeory'),
(2,2,0,1,'tx_mask_all_cases','tx_mask_catgeory'),
(2,5,0,1,'tx_mask_all_cases','tx_mask_catgeory'),
(2,6,0,1,'tx_mask_all_cases','tx_mask_catgeory'),
(3,4,0,1,'tx_mask_all_cases','tx_mask_catgeory'),
(4,3,0,1,'tx_mask_all_cases','tx_mask_catgeory');
/*!40000 ALTER TABLE `sys_category_record_mm` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_csp_resolution`
--

DROP TABLE IF EXISTS `sys_csp_resolution`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_csp_resolution` (
  `summary` varchar(40) NOT NULL,
  `created` int(10) unsigned NOT NULL,
  `scope` varchar(264) NOT NULL,
  `mutation_identifier` text DEFAULT NULL,
  `mutation_collection` mediumtext DEFAULT NULL,
  `meta` mediumtext DEFAULT NULL,
  PRIMARY KEY (`summary`),
  KEY `created` (`created`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_csp_resolution`
--

LOCK TABLES `sys_csp_resolution` WRITE;
/*!40000 ALTER TABLE `sys_csp_resolution` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_csp_resolution` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_file`
--

DROP TABLE IF EXISTS `sys_file`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_file` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `last_indexed` int(11) NOT NULL DEFAULT 0,
  `identifier` text DEFAULT NULL,
  `identifier_hash` varchar(40) NOT NULL DEFAULT '',
  `folder_hash` varchar(40) NOT NULL DEFAULT '',
  `extension` varchar(255) NOT NULL DEFAULT '',
  `name` tinytext DEFAULT NULL,
  `sha1` varchar(40) NOT NULL DEFAULT '',
  `creation_date` int(11) NOT NULL DEFAULT 0,
  `modification_date` int(11) NOT NULL DEFAULT 0,
  `size` bigint(20) NOT NULL DEFAULT 0,
  `storage` int(10) unsigned NOT NULL DEFAULT 0,
  `type` int(10) unsigned NOT NULL DEFAULT 0,
  `mime_type` varchar(255) NOT NULL DEFAULT '',
  `missing` smallint(5) unsigned NOT NULL DEFAULT 0,
  `metadata` int(10) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `sel01` (`storage`,`identifier_hash`),
  KEY `folder` (`storage`,`folder_hash`),
  KEY `tstamp` (`tstamp`),
  KEY `lastindex` (`last_indexed`),
  KEY `sha1` (`sha1`),
  KEY `parent` (`pid`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_file`
--

LOCK TABLES `sys_file` WRITE;
/*!40000 ALTER TABLE `sys_file` DISABLE KEYS */;
INSERT INTO `sys_file` VALUES
(1,0,1762272117,1762272117,'/user_upload/index.html','c25533f303185517ca3e1e24b215d53aa74076d2','19669f1e02c2f16705ec7587044c66443be70725','html','index.html','da39a3ee5e6b4b0d3255bfef95601890afd80709',1762268411,1762268411,0,1,5,'application/x-empty',0,0),
(2,0,1762272167,1762272167,'/user_upload/elo.jpg','2594eff349100c838e1410b212a84e97d2064a34','19669f1e02c2f16705ec7587044c66443be70725','jpg','elo.jpg','7de09ccfb1b175afb763726bf8eea19ae027725e',1762272167,1762272167,1056288,1,2,'image/jpeg',0,0),
(3,0,1762423380,1762423380,'/user_upload/test.jpg','7fedef9fd45f90f3edc351cae604b59903a15d0e','19669f1e02c2f16705ec7587044c66443be70725','jpg','test.jpg','38db952d35f8452b856ea451ea93e687c99f306d',1762423380,1762423380,4000079,1,2,'image/jpeg',0,0),
(4,0,1762432234,1762432234,'/user_upload/Cases/Case_nr1/R-1.png','fc6cde36cc95a9b3e1841597d777aa5b89c868a1','3b87cb433cc0b4eb0443bd94e21237de46333510','png','R-1.png','697a98157921968ac5021762818e76116c06971e',1762432234,1762432234,2399901,1,2,'image/png',0,0),
(5,0,1762432234,1762432234,'/user_upload/Cases/Case_nr1/R-2.png','9dc144806c2ad54f6e7d25a6c9aca0c601b6c44c','3b87cb433cc0b4eb0443bd94e21237de46333510','png','R-2.png','77c7103376d0a29bd37eed6168f2835c7a455347',1762432234,1762432234,2168122,1,2,'image/png',0,0),
(6,0,1762432234,1762432234,'/user_upload/Cases/Case_nr1/R-3.png','bb5ebd5208a154cba671b0df271a4dd0b481c683','3b87cb433cc0b4eb0443bd94e21237de46333510','png','R-3.png','b60a6aeb8cc0bcfbc89c3cc75906a3d08de3d972',1762432234,1762432234,1526770,1,2,'image/png',0,0),
(7,0,1762432234,1762432234,'/user_upload/Cases/Case_nr1/R0004824.png','246c46837ac6d18c443fb4a624e9b9741f18edc1','3b87cb433cc0b4eb0443bd94e21237de46333510','png','R0004824.png','5e8fcc15c75b9d2207db5799461addf69ce723d9',1762432234,1762432234,2559091,1,2,'image/png',0,0),
(8,0,1762432234,1762432234,'/user_upload/Cases/Case_nr1/R0005129.png','2dc0721ab4a19d16807ba0832fdd9840ac01f3a8','3b87cb433cc0b4eb0443bd94e21237de46333510','png','R0005129.png','c8ed934897d73dfe8ab317402f4429d9e0e3cbd3',1762432234,1762432234,1228059,1,2,'image/png',0,0),
(9,0,1762441917,1762441917,'/user_upload/Cases/Case_nr1/Bildschirmfoto_2025-11-06_um_16.11.46.png','5eae4d5bc6f3c150b072106ca37fff16280f7ea1','3b87cb433cc0b4eb0443bd94e21237de46333510','png','Bildschirmfoto_2025-11-06_um_16.11.46.png','e0294291b19ccb85674a6a3184515dc18b8149cf',1762441917,1762441917,4880516,1,2,'image/png',0,0),
(10,0,1762442717,1762442717,'/user_upload/ada77224d526a050ce627d29a78c8596.jpg','37c676d2dd08f7c240e4e4b37c8830bb21d8e542','19669f1e02c2f16705ec7587044c66443be70725','jpg','ada77224d526a050ce627d29a78c8596.jpg','43391f0a84f37246e85a338cdae59af00c4be1cc',1762442717,1762442717,161762,1,2,'image/jpeg',0,0),
(11,0,1762442743,1762442743,'/user_upload/82062406_Mood2_47cfd87f-954d-4f12-ba9e-cd7f7cf44187.webp','88cd66057f21209832cf5918f90d1973c9251716','19669f1e02c2f16705ec7587044c66443be70725','webp','82062406_Mood2_47cfd87f-954d-4f12-ba9e-cd7f7cf44187.webp','a3f3942fcd1eae59fb4d7f794a5bb1bfdeba0c72',1762442743,1762442743,252406,1,2,'image/webp',0,0),
(12,0,1762442860,1762442860,'/user_upload/d25f377994b383efcf8332f56d0a61b1.jpg','6373e269ef4a7dcb5474f95daa612edf0e57a36e','19669f1e02c2f16705ec7587044c66443be70725','jpg','d25f377994b383efcf8332f56d0a61b1.jpg','b1b58bcee2900e744dd279eaa2405044695b07f0',1762442860,1762442860,53525,1,2,'image/jpeg',0,0),
(13,0,1762444507,1762444507,'/user_upload/Bildschirmfoto_2025-11-06_um_16.54.31.png','35499f594139486e4eddea16e142ab16bc21760a','19669f1e02c2f16705ec7587044c66443be70725','png','Bildschirmfoto_2025-11-06_um_16.54.31.png','3ce8fe2d716cb406ce4a6f898c7d3bf73e39a05e',1762444507,1762444507,8192428,1,2,'image/png',0,0),
(14,0,1762444586,1762444586,'/user_upload/Bildschirmfoto_2025-11-06_um_16.56.14.png','5200c5c9a98f805cad99c7d5e12d0ef5fd3e0ffd','19669f1e02c2f16705ec7587044c66443be70725','png','Bildschirmfoto_2025-11-06_um_16.56.14.png','7679ba32854456c8572a16f2ef0822cb8f9553a9',1762444586,1762444586,8098337,1,2,'image/png',0,0);
/*!40000 ALTER TABLE `sys_file` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_file_collection`
--

DROP TABLE IF EXISTS `sys_file_collection`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_file_collection` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `description` text DEFAULT NULL,
  `sys_language_uid` int(11) NOT NULL DEFAULT 0,
  `l10n_parent` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_state` text DEFAULT NULL,
  `l10n_diffsource` mediumblob DEFAULT NULL,
  `t3ver_oid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_wsid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `title` tinytext DEFAULT NULL,
  `type` varchar(30) NOT NULL DEFAULT 'static',
  `files` int(10) unsigned NOT NULL DEFAULT 0,
  `folder_identifier` longtext DEFAULT NULL,
  `recursive` smallint(5) unsigned NOT NULL DEFAULT 0,
  `category` int(10) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`,`hidden`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_file_collection`
--

LOCK TABLES `sys_file_collection` WRITE;
/*!40000 ALTER TABLE `sys_file_collection` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_file_collection` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_file_metadata`
--

DROP TABLE IF EXISTS `sys_file_metadata`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_file_metadata` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `sys_language_uid` int(11) NOT NULL DEFAULT 0,
  `l10n_parent` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_state` text DEFAULT NULL,
  `l10n_diffsource` mediumblob DEFAULT NULL,
  `t3ver_oid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_wsid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `title` tinytext DEFAULT NULL,
  `alternative` text DEFAULT NULL,
  `status` varchar(24) DEFAULT '',
  `latitude` decimal(24,14) DEFAULT 0.00000000000000,
  `longitude` decimal(24,14) DEFAULT 0.00000000000000,
  `pages` int(10) unsigned DEFAULT 0,
  `categories` int(10) unsigned NOT NULL DEFAULT 0,
  `file` int(10) unsigned NOT NULL DEFAULT 0,
  `description` longtext DEFAULT NULL,
  `width` int(11) NOT NULL DEFAULT 0,
  `height` int(11) NOT NULL DEFAULT 0,
  `visible` smallint(5) unsigned NOT NULL DEFAULT 1,
  `keywords` longtext DEFAULT NULL,
  `caption` longtext DEFAULT NULL,
  `creator_tool` varchar(255) NOT NULL DEFAULT '',
  `download_name` varchar(255) NOT NULL DEFAULT '',
  `creator` varchar(255) NOT NULL DEFAULT '',
  `publisher` varchar(120) NOT NULL DEFAULT '',
  `source` varchar(255) NOT NULL DEFAULT '',
  `copyright` longtext DEFAULT NULL,
  `location_country` varchar(45) NOT NULL DEFAULT '',
  `location_region` varchar(45) NOT NULL DEFAULT '',
  `location_city` varchar(45) NOT NULL DEFAULT '',
  `ranking` int(10) unsigned NOT NULL DEFAULT 0,
  `content_creation_date` bigint(20) NOT NULL DEFAULT 0,
  `content_modification_date` bigint(20) NOT NULL DEFAULT 0,
  `note` longtext DEFAULT NULL,
  `unit` varchar(3) NOT NULL DEFAULT '',
  `duration` int(11) NOT NULL DEFAULT 0,
  `color_space` varchar(4) NOT NULL DEFAULT '',
  `language` varchar(45) NOT NULL DEFAULT '',
  `fe_groups` longtext DEFAULT NULL,
  PRIMARY KEY (`uid`),
  KEY `file` (`file`),
  KEY `fal_filelist` (`l10n_parent`,`sys_language_uid`),
  KEY `parent` (`pid`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_file_metadata`
--

LOCK TABLES `sys_file_metadata` WRITE;
/*!40000 ALTER TABLE `sys_file_metadata` DISABLE KEYS */;
INSERT INTO `sys_file_metadata` VALUES
(1,0,1762272117,1762272117,0,0,NULL,'',0,0,0,0,NULL,NULL,'',0.00000000000000,0.00000000000000,0,0,1,NULL,0,0,1,NULL,NULL,'','','','','',NULL,'','','',0,0,0,NULL,'',0,'','',NULL),
(2,0,1762272167,1762272167,0,0,NULL,'',0,0,0,0,NULL,NULL,'',0.00000000000000,0.00000000000000,0,0,2,NULL,1920,1273,1,NULL,NULL,'','','','','',NULL,'','','',0,0,0,NULL,'',0,'','',NULL),
(3,0,1762423380,1762423380,0,0,NULL,'',0,0,0,0,NULL,NULL,'',0.00000000000000,0.00000000000000,0,0,3,NULL,1920,1309,1,NULL,NULL,'','','','','',NULL,'','','',0,0,0,NULL,'',0,'','',NULL),
(4,0,1762432234,1762432234,0,0,NULL,'',0,0,0,0,NULL,NULL,'',0.00000000000000,0.00000000000000,0,0,4,NULL,1403,983,1,NULL,NULL,'','','','','',NULL,'','','',0,0,0,NULL,'',0,'','',NULL),
(5,0,1762432234,1762432234,0,0,NULL,'',0,0,0,0,NULL,NULL,'',0.00000000000000,0.00000000000000,0,0,5,NULL,887,1230,1,NULL,NULL,'','','','','',NULL,'','','',0,0,0,NULL,'',0,'','',NULL),
(6,0,1762432234,1762432234,0,0,NULL,'',0,0,0,0,NULL,NULL,'',0.00000000000000,0.00000000000000,0,0,6,NULL,887,1230,1,NULL,NULL,'','','','','',NULL,'','','',0,0,0,NULL,'',0,'','',NULL),
(7,0,1762432234,1762432234,0,0,NULL,'',0,0,0,0,NULL,NULL,'',0.00000000000000,0.00000000000000,0,0,7,NULL,1403,983,1,NULL,NULL,'','','','','',NULL,'','','',0,0,0,NULL,'',0,'','',NULL),
(8,0,1762432234,1762432234,0,0,NULL,'',0,0,0,0,NULL,NULL,'',0.00000000000000,0.00000000000000,0,0,8,NULL,887,1230,1,NULL,NULL,'','','','','',NULL,'','','',0,0,0,NULL,'',0,'','',NULL),
(9,0,1762441917,1762441917,0,0,NULL,'',0,0,0,0,NULL,NULL,'',0.00000000000000,0.00000000000000,0,0,9,NULL,1490,2074,1,NULL,NULL,'','','','','',NULL,'','','',0,0,0,NULL,'',0,'','',NULL),
(10,0,1762442717,1762442717,0,0,NULL,'',0,0,0,0,NULL,NULL,'',0.00000000000000,0.00000000000000,0,0,10,NULL,1199,1309,1,NULL,NULL,'','','','','',NULL,'','','',0,0,0,NULL,'',0,'','',NULL),
(11,0,1762442743,1762442743,0,0,NULL,'',0,0,0,0,NULL,NULL,'',0.00000000000000,0.00000000000000,0,0,11,NULL,1300,1734,1,NULL,NULL,'','','','','',NULL,'','','',0,0,0,NULL,'',0,'','',NULL),
(12,0,1762442860,1762442860,0,0,NULL,'',0,0,0,0,NULL,NULL,'',0.00000000000000,0.00000000000000,0,0,12,NULL,600,804,1,NULL,NULL,'','','','','',NULL,'','','',0,0,0,NULL,'',0,'','',NULL),
(13,0,1762444507,1762444507,0,0,NULL,'',0,0,0,0,NULL,NULL,'',0.00000000000000,0.00000000000000,0,0,13,NULL,3130,1928,1,NULL,NULL,'','','','','',NULL,'','','',0,0,0,NULL,'',0,'','',NULL),
(14,0,1762444586,1762444586,0,0,NULL,'',0,0,0,0,NULL,NULL,'',0.00000000000000,0.00000000000000,0,0,14,NULL,3116,1920,1,NULL,NULL,'','','','','',NULL,'','','',0,0,0,NULL,'',0,'','',NULL);
/*!40000 ALTER TABLE `sys_file_metadata` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_file_processedfile`
--

DROP TABLE IF EXISTS `sys_file_processedfile`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_file_processedfile` (
  `uid` int(11) NOT NULL AUTO_INCREMENT,
  `tstamp` int(11) NOT NULL DEFAULT 0,
  `crdate` int(11) NOT NULL DEFAULT 0,
  `storage` int(11) NOT NULL DEFAULT 0,
  `original` int(11) NOT NULL DEFAULT 0,
  `identifier` varchar(512) NOT NULL DEFAULT '',
  `name` tinytext DEFAULT NULL,
  `processing_url` text DEFAULT NULL,
  `configuration` blob DEFAULT NULL,
  `configurationsha1` varchar(40) NOT NULL DEFAULT '',
  `originalfilesha1` varchar(40) NOT NULL DEFAULT '',
  `task_type` varchar(200) NOT NULL DEFAULT '',
  `checksum` varchar(32) NOT NULL DEFAULT '',
  `width` int(11) DEFAULT 0,
  `height` int(11) DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `combined_1` (`original`,`task_type`(100),`configurationsha1`),
  KEY `identifier` (`storage`,`identifier`(180))
) ENGINE=InnoDB AUTO_INCREMENT=84 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_file_processedfile`
--

LOCK TABLES `sys_file_processedfile` WRITE;
/*!40000 ALTER TABLE `sys_file_processedfile` DISABLE KEYS */;
INSERT INTO `sys_file_processedfile` VALUES
(1,1762272167,1762272167,1,2,'/_processed_/5/4/csm_elo_6c9f0ba762.jpg','csm_elo_6c9f0ba762.jpg','','a:7:{s:5:\"width\";N;s:6:\"height\";N;s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";i:166;s:9:\"maxHeight\";i:115;s:4:\"crop\";N;}','42bbd46565440d020e85026168e5aeb9653d29fa','7de09ccfb1b175afb763726bf8eea19ae027725e','Image.CropScaleMask','6c9f0ba762',166,110),
(2,1762272168,1762272168,1,2,'/_processed_/5/4/csm_elo_ffa7a0cdfe.jpg','csm_elo_ffa7a0cdfe.jpg','','a:7:{s:5:\"width\";N;s:6:\"height\";N;s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";N;s:9:\"maxHeight\";i:150;s:4:\"crop\";N;}','cfe93cbb07d0cfbe7800b799777ad2e70305dbab','7de09ccfb1b175afb763726bf8eea19ae027725e','Image.CropScaleMask','ffa7a0cdfe',226,150),
(3,1762272168,1762272168,1,2,'/_processed_/5/4/csm_elo_ebf7bbc555.jpg','csm_elo_ebf7bbc555.jpg','','a:3:{s:8:\"maxWidth\";i:145;s:9:\"maxHeight\";i:45;s:6:\"height\";s:3:\"45m\";}','99641ee1e111db8018e526d3105ad5631f8f88a4','7de09ccfb1b175afb763726bf8eea19ae027725e','Image.CropScaleMask','ebf7bbc555',68,45),
(4,1762272171,1762272171,1,2,'/_processed_/5/4/csm_elo_3d5cdfea5d.jpg','csm_elo_3d5cdfea5d.jpg',NULL,'a:12:{s:5:\"width\";s:5:\"1280c\";s:6:\"height\";s:5:\"1280c\";s:13:\"fileExtension\";s:0:\"\";s:8:\"maxWidth\";i:0;s:9:\"maxHeight\";i:0;s:8:\"minWidth\";i:0;s:9:\"minHeight\";i:0;s:7:\"noScale\";s:0:\"\";s:6:\"sample\";b:0;s:20:\"additionalParameters\";s:0:\"\";s:5:\"frame\";i:0;s:4:\"crop\";N;}','4f02ca5a16d98c6a664848c7ba1653128aee6201','7de09ccfb1b175afb763726bf8eea19ae027725e','Image.CropScaleMask','3d5cdfea5d',1280,1280),
(5,1762272452,1762272452,1,2,'',NULL,'','a:7:{s:5:\"width\";N;s:6:\"height\";N;s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";N;s:9:\"maxHeight\";N;s:4:\"crop\";N;}','24f48d5b4de7d99b7144e6559156976855e74b5d','7de09ccfb1b175afb763726bf8eea19ae027725e','Image.CropScaleMask','8595a2a43d',0,0),
(6,1762273157,1762273157,1,2,'/_processed_/5/4/csm_elo_3b688d4a41.jpg','csm_elo_3b688d4a41.jpg','','a:2:{s:8:\"maxWidth\";i:64;s:9:\"maxHeight\";i:64;}','adce1dbae2e4683670473874bda4b4e3a0297998','7de09ccfb1b175afb763726bf8eea19ae027725e','Image.CropScaleMask','3b688d4a41',64,42),
(7,1762273160,1762273160,1,2,'',NULL,'','a:3:{s:5:\"width\";s:5:\"1920c\";s:6:\"height\";s:4:\"auto\";s:4:\"crop\";N;}','56c71d44ae63c73de68cf1aa44596b1051f7d5cb','7de09ccfb1b175afb763726bf8eea19ae027725e','Image.CropScaleMask','bca1ee229d',0,0),
(8,1762422679,1762422679,1,2,'/_processed_/5/4/csm_elo_a2578d624f.jpg','csm_elo_a2578d624f.jpg',NULL,'a:7:{s:5:\"width\";i:200;s:6:\"height\";N;s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";N;s:9:\"maxHeight\";N;s:4:\"crop\";N;}','ba6f3999daa64879a5c9fcc4ffddd553a4e200d5','7de09ccfb1b175afb763726bf8eea19ae027725e','Image.CropScaleMask','a2578d624f',200,133),
(9,1762422743,1762422743,1,2,'/_processed_/5/4/csm_elo_4e2b01691a.jpg','csm_elo_4e2b01691a.jpg',NULL,'a:7:{s:5:\"width\";s:5:\"1920c\";s:6:\"height\";s:5:\"1080c\";s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";N;s:9:\"maxHeight\";N;s:4:\"crop\";N;}','b5f8a0d9965982e5c525fdbd5a94e7cab4ce7f2d','7de09ccfb1b175afb763726bf8eea19ae027725e','Image.CropScaleMask','4e2b01691a',1920,1080),
(10,1762423381,1762423380,1,3,'/_processed_/0/4/csm_test_2d4239ce79.jpg','csm_test_2d4239ce79.jpg','','a:7:{s:5:\"width\";N;s:6:\"height\";N;s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";i:166;s:9:\"maxHeight\";i:115;s:4:\"crop\";N;}','42bbd46565440d020e85026168e5aeb9653d29fa','38db952d35f8452b856ea451ea93e687c99f306d','Image.CropScaleMask','2d4239ce79',166,113),
(11,1762423381,1762423381,1,3,'/_processed_/0/4/csm_test_434e2f6cc8.jpg','csm_test_434e2f6cc8.jpg','','a:7:{s:5:\"width\";N;s:6:\"height\";N;s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";N;s:9:\"maxHeight\";i:150;s:4:\"crop\";N;}','cfe93cbb07d0cfbe7800b799777ad2e70305dbab','38db952d35f8452b856ea451ea93e687c99f306d','Image.CropScaleMask','434e2f6cc8',220,150),
(12,1762423382,1762423381,1,3,'/_processed_/0/4/csm_test_039225073f.jpg','csm_test_039225073f.jpg','','a:3:{s:8:\"maxWidth\";i:145;s:9:\"maxHeight\";i:45;s:6:\"height\";s:3:\"45m\";}','99641ee1e111db8018e526d3105ad5631f8f88a4','38db952d35f8452b856ea451ea93e687c99f306d','Image.CropScaleMask','039225073f',66,45),
(13,1762423395,1762423395,1,3,'/_processed_/0/4/csm_test_7237a747b1.jpg','csm_test_7237a747b1.jpg',NULL,'a:7:{s:5:\"width\";s:5:\"1920c\";s:6:\"height\";s:5:\"1080c\";s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";N;s:9:\"maxHeight\";N;s:4:\"crop\";N;}','b5f8a0d9965982e5c525fdbd5a94e7cab4ce7f2d','38db952d35f8452b856ea451ea93e687c99f306d','Image.CropScaleMask','7237a747b1',1920,1080),
(14,1762425246,1762425246,1,2,'/_processed_/5/4/preview_elo_49e0bccd42.jpg','preview_elo_49e0bccd42.jpg','','a:2:{s:5:\"width\";i:150;s:6:\"height\";i:150;}','55d97d4e532f03dbc8a5053eac06a25a43ca2e20','7de09ccfb1b175afb763726bf8eea19ae027725e','Image.Preview','49e0bccd42',150,99),
(15,1762425262,1762425262,1,2,'/_processed_/5/4/csm_elo_116c805302.jpg','csm_elo_116c805302.jpg',NULL,'a:7:{s:5:\"width\";s:5:\"1000c\";s:6:\"height\";s:5:\"1370c\";s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";N;s:9:\"maxHeight\";N;s:4:\"crop\";N;}','246f41d8e6b81ff7df72a234b60c478eb56eabe0','7de09ccfb1b175afb763726bf8eea19ae027725e','Image.CropScaleMask','116c805302',1000,1370),
(16,1762432234,1762432234,1,4,'/_processed_/2/e/csm_R-1_d273213c06.png','csm_R-1_d273213c06.png','','a:7:{s:5:\"width\";N;s:6:\"height\";N;s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";i:166;s:9:\"maxHeight\";i:115;s:4:\"crop\";N;}','42bbd46565440d020e85026168e5aeb9653d29fa','697a98157921968ac5021762818e76116c06971e','Image.CropScaleMask','d273213c06',164,115),
(17,1762432234,1762432234,1,5,'/_processed_/7/6/csm_R-2_75f06bbc64.png','csm_R-2_75f06bbc64.png','','a:7:{s:5:\"width\";N;s:6:\"height\";N;s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";i:166;s:9:\"maxHeight\";i:115;s:4:\"crop\";N;}','42bbd46565440d020e85026168e5aeb9653d29fa','77c7103376d0a29bd37eed6168f2835c7a455347','Image.CropScaleMask','75f06bbc64',83,115),
(18,1762432234,1762432234,1,6,'/_processed_/6/8/csm_R-3_d95c474f4f.png','csm_R-3_d95c474f4f.png','','a:7:{s:5:\"width\";N;s:6:\"height\";N;s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";i:166;s:9:\"maxHeight\";i:115;s:4:\"crop\";N;}','42bbd46565440d020e85026168e5aeb9653d29fa','b60a6aeb8cc0bcfbc89c3cc75906a3d08de3d972','Image.CropScaleMask','d95c474f4f',83,115),
(19,1762432234,1762432234,1,7,'/_processed_/6/2/csm_R0004824_3b56adeed5.png','csm_R0004824_3b56adeed5.png','','a:7:{s:5:\"width\";N;s:6:\"height\";N;s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";i:166;s:9:\"maxHeight\";i:115;s:4:\"crop\";N;}','42bbd46565440d020e85026168e5aeb9653d29fa','5e8fcc15c75b9d2207db5799461addf69ce723d9','Image.CropScaleMask','3b56adeed5',164,115),
(20,1762432235,1762432234,1,8,'/_processed_/3/b/csm_R0005129_1d42867575.png','csm_R0005129_1d42867575.png','','a:7:{s:5:\"width\";N;s:6:\"height\";N;s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";i:166;s:9:\"maxHeight\";i:115;s:4:\"crop\";N;}','42bbd46565440d020e85026168e5aeb9653d29fa','c8ed934897d73dfe8ab317402f4429d9e0e3cbd3','Image.CropScaleMask','1d42867575',83,115),
(21,1762432242,1762432241,1,4,'/_processed_/2/e/csm_R-1_dcde9fad43.png','csm_R-1_dcde9fad43.png','','a:2:{s:8:\"maxWidth\";i:64;s:9:\"maxHeight\";i:64;}','adce1dbae2e4683670473874bda4b4e3a0297998','697a98157921968ac5021762818e76116c06971e','Image.CropScaleMask','dcde9fad43',64,45),
(22,1762432241,1762432241,1,5,'/_processed_/7/6/csm_R-2_b023b49cc5.png','csm_R-2_b023b49cc5.png','','a:2:{s:8:\"maxWidth\";i:64;s:9:\"maxHeight\";i:64;}','adce1dbae2e4683670473874bda4b4e3a0297998','77c7103376d0a29bd37eed6168f2835c7a455347','Image.CropScaleMask','b023b49cc5',46,64),
(23,1762432241,1762432241,1,6,'/_processed_/6/8/csm_R-3_4decebdc2a.png','csm_R-3_4decebdc2a.png','','a:2:{s:8:\"maxWidth\";i:64;s:9:\"maxHeight\";i:64;}','adce1dbae2e4683670473874bda4b4e3a0297998','b60a6aeb8cc0bcfbc89c3cc75906a3d08de3d972','Image.CropScaleMask','4decebdc2a',46,64),
(24,1762432241,1762432241,1,7,'/_processed_/6/2/csm_R0004824_cc0ecc646c.png','csm_R0004824_cc0ecc646c.png','','a:2:{s:8:\"maxWidth\";i:64;s:9:\"maxHeight\";i:64;}','adce1dbae2e4683670473874bda4b4e3a0297998','5e8fcc15c75b9d2207db5799461addf69ce723d9','Image.CropScaleMask','cc0ecc646c',64,45),
(25,1762432241,1762432241,1,8,'/_processed_/3/b/csm_R0005129_5cc0a49e4b.png','csm_R0005129_5cc0a49e4b.png','','a:2:{s:8:\"maxWidth\";i:64;s:9:\"maxHeight\";i:64;}','adce1dbae2e4683670473874bda4b4e3a0297998','c8ed934897d73dfe8ab317402f4429d9e0e3cbd3','Image.CropScaleMask','5cc0a49e4b',46,64),
(26,1762432246,1762432246,1,4,'/_processed_/2/e/csm_R-1_8f9b72eb4a.png','csm_R-1_8f9b72eb4a.png','','a:7:{s:5:\"width\";N;s:6:\"height\";N;s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";N;s:9:\"maxHeight\";i:150;s:4:\"crop\";N;}','cfe93cbb07d0cfbe7800b799777ad2e70305dbab','697a98157921968ac5021762818e76116c06971e','Image.CropScaleMask','8f9b72eb4a',214,150),
(27,1762432246,1762432246,1,4,'/_processed_/2/e/csm_R-1_0611cdbe81.png','csm_R-1_0611cdbe81.png','','a:3:{s:8:\"maxWidth\";i:145;s:9:\"maxHeight\";i:45;s:6:\"height\";s:3:\"45m\";}','99641ee1e111db8018e526d3105ad5631f8f88a4','697a98157921968ac5021762818e76116c06971e','Image.CropScaleMask','0611cdbe81',64,45),
(28,1762442720,1762432246,1,5,'/_processed_/7/6/csm_R-2_a3e67f280f.png','csm_R-2_a3e67f280f.png','','a:7:{s:5:\"width\";N;s:6:\"height\";N;s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";N;s:9:\"maxHeight\";i:150;s:4:\"crop\";N;}','cfe93cbb07d0cfbe7800b799777ad2e70305dbab','77c7103376d0a29bd37eed6168f2835c7a455347','Image.CropScaleMask','a3e67f280f',108,150),
(29,1762432247,1762432246,1,5,'/_processed_/7/6/csm_R-2_4d50c48c4f.png','csm_R-2_4d50c48c4f.png','','a:3:{s:8:\"maxWidth\";i:145;s:9:\"maxHeight\";i:45;s:6:\"height\";s:3:\"45m\";}','99641ee1e111db8018e526d3105ad5631f8f88a4','77c7103376d0a29bd37eed6168f2835c7a455347','Image.CropScaleMask','4d50c48c4f',32,45),
(30,1762437759,1762432246,1,6,'/_processed_/6/8/csm_R-3_345e4eed00.png','csm_R-3_345e4eed00.png','','a:7:{s:5:\"width\";N;s:6:\"height\";N;s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";N;s:9:\"maxHeight\";i:150;s:4:\"crop\";N;}','cfe93cbb07d0cfbe7800b799777ad2e70305dbab','b60a6aeb8cc0bcfbc89c3cc75906a3d08de3d972','Image.CropScaleMask','345e4eed00',108,150),
(31,1762432248,1762432246,1,6,'/_processed_/6/8/csm_R-3_8d91528df0.png','csm_R-3_8d91528df0.png','','a:3:{s:8:\"maxWidth\";i:145;s:9:\"maxHeight\";i:45;s:6:\"height\";s:3:\"45m\";}','99641ee1e111db8018e526d3105ad5631f8f88a4','b60a6aeb8cc0bcfbc89c3cc75906a3d08de3d972','Image.CropScaleMask','8d91528df0',32,45),
(32,1762440482,1762432246,1,7,'/_processed_/6/2/csm_R0004824_4a55121e31.png','csm_R0004824_4a55121e31.png','','a:7:{s:5:\"width\";N;s:6:\"height\";N;s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";N;s:9:\"maxHeight\";i:150;s:4:\"crop\";N;}','cfe93cbb07d0cfbe7800b799777ad2e70305dbab','5e8fcc15c75b9d2207db5799461addf69ce723d9','Image.CropScaleMask','4a55121e31',214,150),
(33,1762432248,1762432246,1,7,'/_processed_/6/2/csm_R0004824_a3a2ead85d.png','csm_R0004824_a3a2ead85d.png','','a:3:{s:8:\"maxWidth\";i:145;s:9:\"maxHeight\";i:45;s:6:\"height\";s:3:\"45m\";}','99641ee1e111db8018e526d3105ad5631f8f88a4','5e8fcc15c75b9d2207db5799461addf69ce723d9','Image.CropScaleMask','a3a2ead85d',64,45),
(34,1762435196,1762432246,1,8,'/_processed_/3/b/csm_R0005129_1114496e84.png','csm_R0005129_1114496e84.png','','a:7:{s:5:\"width\";N;s:6:\"height\";N;s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";N;s:9:\"maxHeight\";i:150;s:4:\"crop\";N;}','cfe93cbb07d0cfbe7800b799777ad2e70305dbab','c8ed934897d73dfe8ab317402f4429d9e0e3cbd3','Image.CropScaleMask','1114496e84',108,150),
(35,1762432249,1762432246,1,8,'/_processed_/3/b/csm_R0005129_75fc8780dd.png','csm_R0005129_75fc8780dd.png','','a:3:{s:8:\"maxWidth\";i:145;s:9:\"maxHeight\";i:45;s:6:\"height\";s:3:\"45m\";}','99641ee1e111db8018e526d3105ad5631f8f88a4','c8ed934897d73dfe8ab317402f4429d9e0e3cbd3','Image.CropScaleMask','75fc8780dd',32,45),
(36,1762432255,1762432255,1,4,'/_processed_/2/e/csm_R-1_235ac2d3e6.png','csm_R-1_235ac2d3e6.png',NULL,'a:7:{s:5:\"width\";i:200;s:6:\"height\";N;s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";N;s:9:\"maxHeight\";N;s:4:\"crop\";N;}','ba6f3999daa64879a5c9fcc4ffddd553a4e200d5','697a98157921968ac5021762818e76116c06971e','Image.CropScaleMask','235ac2d3e6',200,140),
(37,1762432255,1762432255,1,5,'/_processed_/7/6/csm_R-2_f5b52e9278.png','csm_R-2_f5b52e9278.png',NULL,'a:7:{s:5:\"width\";i:200;s:6:\"height\";N;s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";N;s:9:\"maxHeight\";N;s:4:\"crop\";N;}','ba6f3999daa64879a5c9fcc4ffddd553a4e200d5','77c7103376d0a29bd37eed6168f2835c7a455347','Image.CropScaleMask','f5b52e9278',200,277),
(38,1762432255,1762432255,1,6,'/_processed_/6/8/csm_R-3_a19f9c6ffd.png','csm_R-3_a19f9c6ffd.png',NULL,'a:7:{s:5:\"width\";i:200;s:6:\"height\";N;s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";N;s:9:\"maxHeight\";N;s:4:\"crop\";N;}','ba6f3999daa64879a5c9fcc4ffddd553a4e200d5','b60a6aeb8cc0bcfbc89c3cc75906a3d08de3d972','Image.CropScaleMask','a19f9c6ffd',200,277),
(39,1762432255,1762432255,1,7,'/_processed_/6/2/csm_R0004824_2af495f674.png','csm_R0004824_2af495f674.png',NULL,'a:7:{s:5:\"width\";i:200;s:6:\"height\";N;s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";N;s:9:\"maxHeight\";N;s:4:\"crop\";N;}','ba6f3999daa64879a5c9fcc4ffddd553a4e200d5','5e8fcc15c75b9d2207db5799461addf69ce723d9','Image.CropScaleMask','2af495f674',200,140),
(40,1762432255,1762432255,1,8,'/_processed_/3/b/csm_R0005129_c42c6efb1a.png','csm_R0005129_c42c6efb1a.png',NULL,'a:7:{s:5:\"width\";i:200;s:6:\"height\";N;s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";N;s:9:\"maxHeight\";N;s:4:\"crop\";N;}','ba6f3999daa64879a5c9fcc4ffddd553a4e200d5','c8ed934897d73dfe8ab317402f4429d9e0e3cbd3','Image.CropScaleMask','c42c6efb1a',200,277),
(41,1762432796,1762432796,1,4,'',NULL,'','a:7:{s:5:\"width\";N;s:6:\"height\";N;s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";i:1920;s:9:\"maxHeight\";i:1920;s:4:\"crop\";N;}','b4ad301ef9ebf3977b3797a6a960e1b06885c0f8','697a98157921968ac5021762818e76116c06971e','Image.CropScaleMask','f4d9492d4a',0,0),
(42,1762432796,1762432796,1,5,'',NULL,'','a:7:{s:5:\"width\";N;s:6:\"height\";N;s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";i:1920;s:9:\"maxHeight\";i:1920;s:4:\"crop\";N;}','b4ad301ef9ebf3977b3797a6a960e1b06885c0f8','77c7103376d0a29bd37eed6168f2835c7a455347','Image.CropScaleMask','2f5fc9d456',0,0),
(43,1762432796,1762432796,1,6,'',NULL,'','a:7:{s:5:\"width\";N;s:6:\"height\";N;s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";i:1920;s:9:\"maxHeight\";i:1920;s:4:\"crop\";N;}','b4ad301ef9ebf3977b3797a6a960e1b06885c0f8','b60a6aeb8cc0bcfbc89c3cc75906a3d08de3d972','Image.CropScaleMask','a98415f062',0,0),
(44,1762432796,1762432796,1,7,'',NULL,'','a:7:{s:5:\"width\";N;s:6:\"height\";N;s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";i:1920;s:9:\"maxHeight\";i:1920;s:4:\"crop\";N;}','b4ad301ef9ebf3977b3797a6a960e1b06885c0f8','5e8fcc15c75b9d2207db5799461addf69ce723d9','Image.CropScaleMask','fd10cb0f3e',0,0),
(45,1762432796,1762432796,1,8,'',NULL,'','a:7:{s:5:\"width\";N;s:6:\"height\";N;s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";i:1920;s:9:\"maxHeight\";i:1920;s:4:\"crop\";N;}','b4ad301ef9ebf3977b3797a6a960e1b06885c0f8','c8ed934897d73dfe8ab317402f4429d9e0e3cbd3','Image.CropScaleMask','84e78be70d',0,0),
(46,1762435228,1762435228,1,8,'/_processed_/3/b/csm_R0005129_8837b9cb75.png','csm_R0005129_8837b9cb75.png',NULL,'a:7:{s:5:\"width\";s:5:\"1000c\";s:6:\"height\";s:5:\"1370c\";s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";N;s:9:\"maxHeight\";N;s:4:\"crop\";N;}','246f41d8e6b81ff7df72a234b60c478eb56eabe0','c8ed934897d73dfe8ab317402f4429d9e0e3cbd3','Image.CropScaleMask','8837b9cb75',1000,1370),
(47,1762437322,1762437322,1,5,'/_processed_/7/6/csm_R-2_85e1702a4e.png','csm_R-2_85e1702a4e.png',NULL,'a:7:{s:5:\"width\";s:5:\"1000c\";s:6:\"height\";s:5:\"1370c\";s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";N;s:9:\"maxHeight\";N;s:4:\"crop\";N;}','246f41d8e6b81ff7df72a234b60c478eb56eabe0','77c7103376d0a29bd37eed6168f2835c7a455347','Image.CropScaleMask','85e1702a4e',1000,1370),
(48,1762437356,1762437356,1,6,'/_processed_/6/8/csm_R-3_d7f5e55f51.png','csm_R-3_d7f5e55f51.png',NULL,'a:7:{s:5:\"width\";s:5:\"1000c\";s:6:\"height\";s:5:\"1370c\";s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";N;s:9:\"maxHeight\";N;s:4:\"crop\";N;}','246f41d8e6b81ff7df72a234b60c478eb56eabe0','b60a6aeb8cc0bcfbc89c3cc75906a3d08de3d972','Image.CropScaleMask','d7f5e55f51',1000,1370),
(49,1762437773,1762437773,1,7,'/_processed_/6/2/csm_R0004824_68dc068fa6.png','csm_R0004824_68dc068fa6.png',NULL,'a:7:{s:5:\"width\";s:5:\"1000c\";s:6:\"height\";s:5:\"1370c\";s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";N;s:9:\"maxHeight\";N;s:4:\"crop\";N;}','246f41d8e6b81ff7df72a234b60c478eb56eabe0','5e8fcc15c75b9d2207db5799461addf69ce723d9','Image.CropScaleMask','68dc068fa6',1000,1370),
(50,1762441917,1762441917,1,9,'/_processed_/7/0/csm_Bildschirmfoto_2025-11-06_um_16.11.46_d90772cae1.png','csm_Bildschirmfoto_2025-11-06_um_16.11.46_d90772cae1.png','','a:2:{s:8:\"maxWidth\";i:64;s:9:\"maxHeight\";i:64;}','adce1dbae2e4683670473874bda4b4e3a0297998','e0294291b19ccb85674a6a3184515dc18b8149cf','Image.CropScaleMask','d90772cae1',46,64),
(51,1762441919,1762441918,1,9,'/_processed_/7/0/csm_Bildschirmfoto_2025-11-06_um_16.11.46_5023ca7bb0.png','csm_Bildschirmfoto_2025-11-06_um_16.11.46_5023ca7bb0.png','','a:7:{s:5:\"width\";N;s:6:\"height\";N;s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";N;s:9:\"maxHeight\";i:150;s:4:\"crop\";N;}','cfe93cbb07d0cfbe7800b799777ad2e70305dbab','e0294291b19ccb85674a6a3184515dc18b8149cf','Image.CropScaleMask','5023ca7bb0',108,150),
(52,1762441919,1762441918,1,9,'/_processed_/7/0/csm_Bildschirmfoto_2025-11-06_um_16.11.46_5a29865433.png','csm_Bildschirmfoto_2025-11-06_um_16.11.46_5a29865433.png','','a:3:{s:8:\"maxWidth\";i:145;s:9:\"maxHeight\";i:45;s:6:\"height\";s:3:\"45m\";}','99641ee1e111db8018e526d3105ad5631f8f88a4','e0294291b19ccb85674a6a3184515dc18b8149cf','Image.CropScaleMask','5a29865433',32,45),
(53,1762441927,1762441927,1,9,'/_processed_/7/0/csm_Bildschirmfoto_2025-11-06_um_16.11.46_192528e667.png','csm_Bildschirmfoto_2025-11-06_um_16.11.46_192528e667.png',NULL,'a:7:{s:5:\"width\";i:200;s:6:\"height\";N;s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";N;s:9:\"maxHeight\";N;s:4:\"crop\";N;}','ba6f3999daa64879a5c9fcc4ffddd553a4e200d5','e0294291b19ccb85674a6a3184515dc18b8149cf','Image.CropScaleMask','192528e667',200,278),
(54,1762442103,1762442103,1,9,'',NULL,'','a:7:{s:5:\"width\";N;s:6:\"height\";N;s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";i:1800;s:9:\"maxHeight\";N;s:4:\"crop\";N;}','8f7d5a0a84a566f385979631ee5142b5752deba9','e0294291b19ccb85674a6a3184515dc18b8149cf','Image.CropScaleMask','3a7724e7d0',0,0),
(55,1762442508,1762442508,1,9,'/_processed_/7/0/csm_Bildschirmfoto_2025-11-06_um_16.11.46_a0cac95b8f.png','csm_Bildschirmfoto_2025-11-06_um_16.11.46_a0cac95b8f.png',NULL,'a:7:{s:5:\"width\";s:5:\"1000c\";s:6:\"height\";s:5:\"1370c\";s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";N;s:9:\"maxHeight\";N;s:4:\"crop\";N;}','246f41d8e6b81ff7df72a234b60c478eb56eabe0','e0294291b19ccb85674a6a3184515dc18b8149cf','Image.CropScaleMask','a0cac95b8f',1000,1370),
(56,1762442658,1762442658,1,3,'/_processed_/0/4/csm_test_4e6357c49d.jpg','csm_test_4e6357c49d.jpg','','a:2:{s:8:\"maxWidth\";i:64;s:9:\"maxHeight\";i:64;}','adce1dbae2e4683670473874bda4b4e3a0297998','38db952d35f8452b856ea451ea93e687c99f306d','Image.CropScaleMask','4e6357c49d',64,44),
(57,1762442717,1762442717,1,10,'/_processed_/f/a/preview_ada77224d526a050ce627d29a78c8596_f4e933fff3.jpg','preview_ada77224d526a050ce627d29a78c8596_f4e933fff3.jpg','','a:2:{s:5:\"width\";i:64;s:6:\"height\";i:64;}','551dfa8957f1a04693c61acf34bc959a1ca971c4','43391f0a84f37246e85a338cdae59af00c4be1cc','Image.Preview','f4e933fff3',59,64),
(58,1762442717,1762442717,1,10,'/_processed_/f/a/csm_ada77224d526a050ce627d29a78c8596_051889892b.jpg','csm_ada77224d526a050ce627d29a78c8596_051889892b.jpg','','a:7:{s:5:\"width\";N;s:6:\"height\";N;s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";N;s:9:\"maxHeight\";i:150;s:4:\"crop\";N;}','cfe93cbb07d0cfbe7800b799777ad2e70305dbab','43391f0a84f37246e85a338cdae59af00c4be1cc','Image.CropScaleMask','051889892b',137,150),
(59,1762442717,1762442717,1,10,'/_processed_/f/a/csm_ada77224d526a050ce627d29a78c8596_0f8a3df635.jpg','csm_ada77224d526a050ce627d29a78c8596_0f8a3df635.jpg','','a:3:{s:8:\"maxWidth\";i:145;s:9:\"maxHeight\";i:45;s:6:\"height\";s:3:\"45m\";}','99641ee1e111db8018e526d3105ad5631f8f88a4','43391f0a84f37246e85a338cdae59af00c4be1cc','Image.CropScaleMask','0f8a3df635',41,45),
(60,1762442743,1762442743,1,11,'/_processed_/7/a/preview_82062406_Mood2_47cfd87f-954d-4f12-ba9e-cd7f7cf44187_e7935f36fc.webp','preview_82062406_Mood2_47cfd87f-954d-4f12-ba9e-cd7f7cf44187_e7935f36fc.webp','','a:2:{s:5:\"width\";i:64;s:6:\"height\";i:64;}','551dfa8957f1a04693c61acf34bc959a1ca971c4','a3f3942fcd1eae59fb4d7f794a5bb1bfdeba0c72','Image.Preview','e7935f36fc',48,64),
(61,1762442743,1762442743,1,11,'/_processed_/7/a/csm_82062406_Mood2_47cfd87f-954d-4f12-ba9e-cd7f7cf44187_6ee207cf94.webp','csm_82062406_Mood2_47cfd87f-954d-4f12-ba9e-cd7f7cf44187_6ee207cf94.webp','','a:7:{s:5:\"width\";N;s:6:\"height\";N;s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";N;s:9:\"maxHeight\";i:150;s:4:\"crop\";N;}','cfe93cbb07d0cfbe7800b799777ad2e70305dbab','a3f3942fcd1eae59fb4d7f794a5bb1bfdeba0c72','Image.CropScaleMask','6ee207cf94',112,150),
(62,1762442743,1762442743,1,11,'/_processed_/7/a/csm_82062406_Mood2_47cfd87f-954d-4f12-ba9e-cd7f7cf44187_13317fadd8.webp','csm_82062406_Mood2_47cfd87f-954d-4f12-ba9e-cd7f7cf44187_13317fadd8.webp','','a:3:{s:8:\"maxWidth\";i:145;s:9:\"maxHeight\";i:45;s:6:\"height\";s:3:\"45m\";}','99641ee1e111db8018e526d3105ad5631f8f88a4','a3f3942fcd1eae59fb4d7f794a5bb1bfdeba0c72','Image.CropScaleMask','13317fadd8',34,45),
(63,1762442746,1762442746,1,10,'/_processed_/f/a/csm_ada77224d526a050ce627d29a78c8596_4fd7ab1bee.jpg','csm_ada77224d526a050ce627d29a78c8596_4fd7ab1bee.jpg',NULL,'a:7:{s:5:\"width\";s:5:\"1000c\";s:6:\"height\";s:5:\"1370c\";s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";N;s:9:\"maxHeight\";N;s:4:\"crop\";N;}','246f41d8e6b81ff7df72a234b60c478eb56eabe0','43391f0a84f37246e85a338cdae59af00c4be1cc','Image.CropScaleMask','4fd7ab1bee',1000,1370),
(64,1762442746,1762442746,1,11,'/_processed_/7/a/csm_82062406_Mood2_47cfd87f-954d-4f12-ba9e-cd7f7cf44187_9da7368d3b.webp','csm_82062406_Mood2_47cfd87f-954d-4f12-ba9e-cd7f7cf44187_9da7368d3b.webp',NULL,'a:7:{s:5:\"width\";s:5:\"1000c\";s:6:\"height\";s:5:\"1370c\";s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";N;s:9:\"maxHeight\";N;s:4:\"crop\";N;}','246f41d8e6b81ff7df72a234b60c478eb56eabe0','a3f3942fcd1eae59fb4d7f794a5bb1bfdeba0c72','Image.CropScaleMask','9da7368d3b',1000,1370),
(65,1762442854,1762442854,1,11,'/_processed_/7/a/csm_82062406_Mood2_47cfd87f-954d-4f12-ba9e-cd7f7cf44187_00b969608f.webp','csm_82062406_Mood2_47cfd87f-954d-4f12-ba9e-cd7f7cf44187_00b969608f.webp','','a:2:{s:8:\"maxWidth\";i:64;s:9:\"maxHeight\";i:64;}','adce1dbae2e4683670473874bda4b4e3a0297998','a3f3942fcd1eae59fb4d7f794a5bb1bfdeba0c72','Image.CropScaleMask','00b969608f',48,64),
(66,1762442854,1762442854,1,10,'/_processed_/f/a/csm_ada77224d526a050ce627d29a78c8596_92f5a513af.jpg','csm_ada77224d526a050ce627d29a78c8596_92f5a513af.jpg','','a:2:{s:8:\"maxWidth\";i:64;s:9:\"maxHeight\";i:64;}','adce1dbae2e4683670473874bda4b4e3a0297998','43391f0a84f37246e85a338cdae59af00c4be1cc','Image.CropScaleMask','92f5a513af',59,64),
(67,1762442861,1762442860,1,12,'/_processed_/5/c/csm_d25f377994b383efcf8332f56d0a61b1_e2fbdb3b27.jpg','csm_d25f377994b383efcf8332f56d0a61b1_e2fbdb3b27.jpg','','a:2:{s:8:\"maxWidth\";i:64;s:9:\"maxHeight\";i:64;}','adce1dbae2e4683670473874bda4b4e3a0297998','b1b58bcee2900e744dd279eaa2405044695b07f0','Image.CropScaleMask','e2fbdb3b27',48,64),
(68,1762443555,1762442863,1,12,'/_processed_/5/c/csm_d25f377994b383efcf8332f56d0a61b1_a9d95789cf.jpg','csm_d25f377994b383efcf8332f56d0a61b1_a9d95789cf.jpg','','a:7:{s:5:\"width\";N;s:6:\"height\";N;s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";N;s:9:\"maxHeight\";i:150;s:4:\"crop\";N;}','cfe93cbb07d0cfbe7800b799777ad2e70305dbab','b1b58bcee2900e744dd279eaa2405044695b07f0','Image.CropScaleMask','a9d95789cf',112,150),
(69,1762442863,1762442863,1,12,'/_processed_/5/c/csm_d25f377994b383efcf8332f56d0a61b1_6b374b257d.jpg','csm_d25f377994b383efcf8332f56d0a61b1_6b374b257d.jpg','','a:3:{s:8:\"maxWidth\";i:145;s:9:\"maxHeight\";i:45;s:6:\"height\";s:3:\"45m\";}','99641ee1e111db8018e526d3105ad5631f8f88a4','b1b58bcee2900e744dd279eaa2405044695b07f0','Image.CropScaleMask','6b374b257d',34,45),
(70,1762442868,1762442868,1,12,'/_processed_/5/c/csm_d25f377994b383efcf8332f56d0a61b1_0d83eb1833.jpg','csm_d25f377994b383efcf8332f56d0a61b1_0d83eb1833.jpg',NULL,'a:7:{s:5:\"width\";s:5:\"1000c\";s:6:\"height\";s:5:\"1370c\";s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";N;s:9:\"maxHeight\";N;s:4:\"crop\";N;}','246f41d8e6b81ff7df72a234b60c478eb56eabe0','b1b58bcee2900e744dd279eaa2405044695b07f0','Image.CropScaleMask','0d83eb1833',1000,1370),
(71,1762444507,1762444507,1,13,'/_processed_/b/a/preview_Bildschirmfoto_2025-11-06_um_16.54.31_fa27e4bb2f.png','preview_Bildschirmfoto_2025-11-06_um_16.54.31_fa27e4bb2f.png','','a:2:{s:5:\"width\";i:64;s:6:\"height\";i:64;}','551dfa8957f1a04693c61acf34bc959a1ca971c4','3ce8fe2d716cb406ce4a6f898c7d3bf73e39a05e','Image.Preview','fa27e4bb2f',64,39),
(72,1762444508,1762444507,1,13,'/_processed_/b/a/csm_Bildschirmfoto_2025-11-06_um_16.54.31_a8a9663120.png','csm_Bildschirmfoto_2025-11-06_um_16.54.31_a8a9663120.png','','a:7:{s:5:\"width\";N;s:6:\"height\";N;s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";N;s:9:\"maxHeight\";i:150;s:4:\"crop\";N;}','cfe93cbb07d0cfbe7800b799777ad2e70305dbab','3ce8fe2d716cb406ce4a6f898c7d3bf73e39a05e','Image.CropScaleMask','a8a9663120',244,150),
(73,1762444508,1762444507,1,13,'/_processed_/b/a/csm_Bildschirmfoto_2025-11-06_um_16.54.31_a72e23327c.png','csm_Bildschirmfoto_2025-11-06_um_16.54.31_a72e23327c.png','','a:3:{s:8:\"maxWidth\";i:145;s:9:\"maxHeight\";i:45;s:6:\"height\";s:3:\"45m\";}','99641ee1e111db8018e526d3105ad5631f8f88a4','3ce8fe2d716cb406ce4a6f898c7d3bf73e39a05e','Image.CropScaleMask','a72e23327c',73,45),
(74,1762444510,1762444510,1,13,'/_processed_/b/a/csm_Bildschirmfoto_2025-11-06_um_16.54.31_6aa761bd99.png','csm_Bildschirmfoto_2025-11-06_um_16.54.31_6aa761bd99.png',NULL,'a:7:{s:5:\"width\";s:5:\"1920c\";s:6:\"height\";s:5:\"1080c\";s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";N;s:9:\"maxHeight\";N;s:4:\"crop\";N;}','b5f8a0d9965982e5c525fdbd5a94e7cab4ce7f2d','3ce8fe2d716cb406ce4a6f898c7d3bf73e39a05e','Image.CropScaleMask','6aa761bd99',1920,1080),
(75,1762444581,1762444580,1,13,'/_processed_/b/a/csm_Bildschirmfoto_2025-11-06_um_16.54.31_4c4aa9bcbe.png','csm_Bildschirmfoto_2025-11-06_um_16.54.31_4c4aa9bcbe.png','','a:2:{s:8:\"maxWidth\";i:64;s:9:\"maxHeight\";i:64;}','adce1dbae2e4683670473874bda4b4e3a0297998','3ce8fe2d716cb406ce4a6f898c7d3bf73e39a05e','Image.CropScaleMask','4c4aa9bcbe',64,39),
(76,1762444586,1762444586,1,14,'/_processed_/4/7/preview_Bildschirmfoto_2025-11-06_um_16.56.14_f02d4504fb.png','preview_Bildschirmfoto_2025-11-06_um_16.56.14_f02d4504fb.png','','a:2:{s:5:\"width\";i:64;s:6:\"height\";i:64;}','551dfa8957f1a04693c61acf34bc959a1ca971c4','7679ba32854456c8572a16f2ef0822cb8f9553a9','Image.Preview','f02d4504fb',64,39),
(77,1762444586,1762444586,1,14,'/_processed_/4/7/csm_Bildschirmfoto_2025-11-06_um_16.56.14_0f941df539.png','csm_Bildschirmfoto_2025-11-06_um_16.56.14_0f941df539.png','','a:7:{s:5:\"width\";N;s:6:\"height\";N;s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";N;s:9:\"maxHeight\";i:150;s:4:\"crop\";N;}','cfe93cbb07d0cfbe7800b799777ad2e70305dbab','7679ba32854456c8572a16f2ef0822cb8f9553a9','Image.CropScaleMask','0f941df539',243,150),
(78,1762444586,1762444586,1,14,'/_processed_/4/7/csm_Bildschirmfoto_2025-11-06_um_16.56.14_9da8b82d05.png','csm_Bildschirmfoto_2025-11-06_um_16.56.14_9da8b82d05.png','','a:3:{s:8:\"maxWidth\";i:145;s:9:\"maxHeight\";i:45;s:6:\"height\";s:3:\"45m\";}','99641ee1e111db8018e526d3105ad5631f8f88a4','7679ba32854456c8572a16f2ef0822cb8f9553a9','Image.CropScaleMask','9da8b82d05',73,45),
(79,1762444588,1762444588,1,14,'/_processed_/4/7/csm_Bildschirmfoto_2025-11-06_um_16.56.14_6760ea57da.png','csm_Bildschirmfoto_2025-11-06_um_16.56.14_6760ea57da.png',NULL,'a:7:{s:5:\"width\";s:5:\"1920c\";s:6:\"height\";s:5:\"1080c\";s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";N;s:9:\"maxHeight\";N;s:4:\"crop\";N;}','b5f8a0d9965982e5c525fdbd5a94e7cab4ce7f2d','7679ba32854456c8572a16f2ef0822cb8f9553a9','Image.CropScaleMask','6760ea57da',1920,1080),
(80,1762849975,1762849975,1,14,'/_processed_/4/7/csm_Bildschirmfoto_2025-11-06_um_16.56.14_5a2fdf988a.png','csm_Bildschirmfoto_2025-11-06_um_16.56.14_5a2fdf988a.png',NULL,'a:7:{s:5:\"width\";s:5:\"1080c\";s:6:\"height\";s:5:\"1350c\";s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";N;s:9:\"maxHeight\";N;s:4:\"crop\";N;}','2c49a9035fe066d5778049247b41f343d1ccd106','7679ba32854456c8572a16f2ef0822cb8f9553a9','Image.CropScaleMask','5a2fdf988a',1080,1350),
(81,1762849975,1762849975,1,3,'/_processed_/0/4/csm_test_911e5d3b99.jpg','csm_test_911e5d3b99.jpg',NULL,'a:7:{s:5:\"width\";s:5:\"1080c\";s:6:\"height\";s:5:\"1350c\";s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";N;s:9:\"maxHeight\";N;s:4:\"crop\";N;}','2c49a9035fe066d5778049247b41f343d1ccd106','38db952d35f8452b856ea451ea93e687c99f306d','Image.CropScaleMask','911e5d3b99',1080,1350),
(82,1762856116,1762856116,1,14,'/_processed_/4/7/csm_Bildschirmfoto_2025-11-06_um_16.56.14_7a92026148.png','csm_Bildschirmfoto_2025-11-06_um_16.56.14_7a92026148.png',NULL,'a:7:{s:5:\"width\";s:5:\"1920c\";s:6:\"height\";s:5:\"1280c\";s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";N;s:9:\"maxHeight\";N;s:4:\"crop\";N;}','c85056709b36a5dba556244a70b46d10e87d1d03','7679ba32854456c8572a16f2ef0822cb8f9553a9','Image.CropScaleMask','7a92026148',1920,1280),
(83,1762856116,1762856116,1,3,'/_processed_/0/4/csm_test_258c725d56.jpg','csm_test_258c725d56.jpg',NULL,'a:7:{s:5:\"width\";s:5:\"1920c\";s:6:\"height\";s:5:\"1280c\";s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";N;s:9:\"maxHeight\";N;s:4:\"crop\";N;}','c85056709b36a5dba556244a70b46d10e87d1d03','38db952d35f8452b856ea451ea93e687c99f306d','Image.CropScaleMask','258c725d56',1920,1280);
/*!40000 ALTER TABLE `sys_file_processedfile` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_file_reference`
--

DROP TABLE IF EXISTS `sys_file_reference`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_file_reference` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `sys_language_uid` int(11) NOT NULL DEFAULT 0,
  `l10n_parent` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_state` text DEFAULT NULL,
  `l10n_diffsource` mediumblob DEFAULT NULL,
  `t3ver_oid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_wsid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `uid_local` int(11) NOT NULL DEFAULT 0,
  `title` tinytext DEFAULT NULL,
  `alternative` text DEFAULT NULL,
  `showinpreview` smallint(6) NOT NULL DEFAULT 0,
  `uid_foreign` int(11) NOT NULL DEFAULT 0,
  `tablenames` varchar(64) NOT NULL DEFAULT '',
  `fieldname` varchar(64) NOT NULL DEFAULT '',
  `sorting_foreign` int(11) NOT NULL DEFAULT 0,
  `link` text NOT NULL DEFAULT '',
  `description` longtext DEFAULT NULL,
  `crop` longtext DEFAULT NULL,
  `autoplay` smallint(5) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `tablenames_fieldname` (`tablenames`(32),`fieldname`(12)),
  KEY `deleted` (`deleted`),
  KEY `uid_local` (`uid_local`),
  KEY `uid_foreign` (`uid_foreign`),
  KEY `combined_1` (`l10n_parent`,`t3ver_oid`,`t3ver_wsid`,`t3ver_state`,`deleted`),
  KEY `parent` (`pid`,`deleted`,`hidden`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`)
) ENGINE=InnoDB AUTO_INCREMENT=26 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_file_reference`
--

LOCK TABLES `sys_file_reference` WRITE;
/*!40000 ALTER TABLE `sys_file_reference` DISABLE KEYS */;
INSERT INTO `sys_file_reference` VALUES
(1,1,1762273638,1762272170,1,0,0,0,NULL,'{\"alternative\":\"\",\"crop\":\"\",\"description\":\"\",\"hidden\":\"\",\"link\":\"\",\"title\":\"\",\"uid_local\":\"\"}',0,0,0,0,2,NULL,NULL,0,1,'pages','media',1,'',NULL,'{\"default\":{\"cropArea\":{\"x\":0,\"y\":0,\"width\":1,\"height\":1},\"selectedRatio\":\"NaN\",\"focusArea\":null}}',0),
(2,1,1762422672,1762273125,1,0,0,0,NULL,'{\"hidden\":\"\"}',0,0,0,0,2,NULL,NULL,0,1,'tt_content','image',1,'',NULL,'{\"default\":{\"cropArea\":{\"x\":0,\"y\":0,\"width\":1,\"height\":1},\"selectedRatio\":\"NaN\",\"focusArea\":null}}',0),
(3,1,1762444509,1762422668,1,0,0,0,NULL,'',0,0,0,0,2,NULL,NULL,0,3,'tt_content','tx_mask_home_image',1,'',NULL,'{\"default\":{\"cropArea\":{\"x\":0,\"y\":0,\"width\":1,\"height\":1},\"selectedRatio\":\"NaN\",\"focusArea\":null}}',0),
(4,1,1762423393,1762423246,1,0,0,0,NULL,'',0,0,0,0,2,NULL,NULL,0,4,'tt_content','tx_mask_home_image',1,'',NULL,'{\"default\":{\"cropArea\":{\"x\":0,\"y\":0,\"width\":1,\"height\":1},\"selectedRatio\":\"NaN\",\"focusArea\":null}}',0),
(5,1,1762423393,1762423393,0,0,0,0,NULL,'',0,0,0,0,3,NULL,NULL,0,4,'tt_content','tx_mask_home_image',1,'',NULL,'{\"default\":{\"cropArea\":{\"x\":0,\"y\":0,\"width\":1,\"height\":1},\"selectedRatio\":\"NaN\",\"focusArea\":null}}',0),
(6,1,1762423420,1762423420,0,0,0,0,NULL,'',0,0,0,0,3,NULL,NULL,0,5,'tt_content','tx_mask_home_image',1,'',NULL,'{\"default\":{\"cropArea\":{\"x\":0,\"y\":0,\"width\":1,\"height\":1},\"selectedRatio\":\"NaN\",\"focusArea\":null}}',0),
(7,1,1762423422,1762423422,0,0,0,0,NULL,'',0,0,0,0,3,NULL,NULL,0,6,'tt_content','tx_mask_home_image',1,'',NULL,'{\"default\":{\"cropArea\":{\"x\":0,\"y\":0,\"width\":1,\"height\":1},\"selectedRatio\":\"NaN\",\"focusArea\":null}}',0),
(8,6,1762432949,1762432251,0,0,0,0,NULL,'{\"hidden\":\"\"}',0,0,0,0,4,NULL,NULL,0,8,'tt_content','tx_mask_images_for_this_case',1,'',NULL,'{\"default\":{\"cropArea\":{\"x\":0,\"y\":0,\"width\":1,\"height\":1},\"selectedRatio\":\"NaN\",\"focusArea\":null}}',0),
(9,6,1762432949,1762432251,0,0,0,0,NULL,'{\"hidden\":\"\"}',0,0,0,0,5,NULL,NULL,0,8,'tt_content','tx_mask_images_for_this_case',2,'',NULL,'{\"default\":{\"cropArea\":{\"x\":0,\"y\":0,\"width\":1,\"height\":1},\"selectedRatio\":\"NaN\",\"focusArea\":null}}',0),
(10,6,1762432949,1762432251,0,0,0,0,NULL,'{\"hidden\":\"\"}',0,0,0,0,6,NULL,NULL,0,8,'tt_content','tx_mask_images_for_this_case',3,'',NULL,'{\"default\":{\"cropArea\":{\"x\":0,\"y\":0,\"width\":1,\"height\":1},\"selectedRatio\":\"NaN\",\"focusArea\":null}}',0),
(11,6,1762432949,1762432251,0,0,0,0,NULL,'{\"hidden\":\"\"}',0,0,0,0,7,NULL,NULL,0,8,'tt_content','tx_mask_images_for_this_case',4,'',NULL,'{\"default\":{\"cropArea\":{\"x\":0,\"y\":0,\"width\":1,\"height\":1},\"selectedRatio\":\"NaN\",\"focusArea\":null}}',0),
(12,6,1762432949,1762432251,0,0,0,0,NULL,'{\"hidden\":\"\"}',0,0,0,0,8,NULL,NULL,0,8,'tt_content','tx_mask_images_for_this_case',5,'',NULL,'{\"default\":{\"cropArea\":{\"x\":0,\"y\":0,\"width\":1,\"height\":1},\"selectedRatio\":\"NaN\",\"focusArea\":null}}',0),
(13,2,1762442745,1762434972,1,0,0,0,NULL,'{\"hidden\":\"\"}',0,0,0,0,8,NULL,NULL,0,1,'tx_mask_all_cases','tx_mask_photo_case',1,'',NULL,'{\"default\":{\"cropArea\":{\"x\":0,\"y\":0,\"width\":1,\"height\":1},\"selectedRatio\":\"NaN\",\"focusArea\":null}}',0),
(14,2,1762442745,1762437321,1,0,0,0,NULL,'{\"alternative\":\"\",\"crop\":\"\",\"description\":\"\",\"hidden\":\"\",\"link\":\"\",\"title\":\"\",\"uid_local\":\"\"}',0,0,0,0,5,NULL,NULL,0,2,'tx_mask_all_cases','tx_mask_photo_case',1,'',NULL,'{\"default\":{\"cropArea\":{\"x\":0,\"y\":0,\"width\":1,\"height\":1},\"selectedRatio\":\"NaN\",\"focusArea\":null}}',0),
(15,2,1762442865,1762437355,1,0,0,0,NULL,'{\"alternative\":\"\",\"crop\":\"\",\"description\":\"\",\"hidden\":\"\",\"link\":\"\",\"title\":\"\",\"uid_local\":\"\"}',0,0,0,0,6,NULL,NULL,0,3,'tx_mask_all_cases','tx_mask_photo_case',1,'',NULL,'{\"default\":{\"cropArea\":{\"x\":0,\"y\":0,\"width\":1,\"height\":1},\"selectedRatio\":\"NaN\",\"focusArea\":null}}',0),
(16,2,1762442507,1762437772,0,0,0,0,NULL,'{\"alternative\":\"\",\"crop\":\"\",\"description\":\"\",\"hidden\":\"\",\"link\":\"\",\"title\":\"\",\"uid_local\":\"\"}',0,0,0,0,7,NULL,NULL,0,4,'tx_mask_all_cases','tx_mask_photo_case',1,'',NULL,'{\"default\":{\"cropArea\":{\"x\":0,\"y\":0,\"width\":1,\"height\":1},\"selectedRatio\":\"NaN\",\"focusArea\":null}}',0),
(17,2,1762442507,1762439342,1,0,0,0,NULL,'{\"alternative\":\"\",\"crop\":\"\",\"description\":\"\",\"hidden\":\"\",\"link\":\"\",\"title\":\"\",\"uid_local\":\"\"}',0,0,0,0,7,NULL,NULL,0,5,'tx_mask_all_cases','tx_mask_photo_case',1,'',NULL,'{\"default\":{\"cropArea\":{\"x\":0,\"y\":0,\"width\":1,\"height\":1},\"selectedRatio\":\"NaN\",\"focusArea\":null}}',0),
(18,3,1762442309,1762441921,0,0,0,0,NULL,'{\"hidden\":\"\"}',0,0,0,0,9,NULL,NULL,0,9,'tt_content','tx_mask_photo_info',1,'',NULL,'{\"default\":{\"cropArea\":{\"x\":0,\"y\":0,\"width\":1,\"height\":1},\"selectedRatio\":\"NaN\",\"focusArea\":null}}',0),
(19,2,1762443238,1762442507,0,0,0,0,NULL,'{\"alternative\":\"\",\"crop\":\"\",\"description\":\"\",\"hidden\":\"\",\"link\":\"\",\"title\":\"\",\"uid_local\":\"\"}',0,0,0,0,9,NULL,NULL,0,5,'tx_mask_all_cases','tx_mask_photo_case',1,'',NULL,'{\"default\":{\"cropArea\":{\"x\":0,\"y\":0,\"width\":1,\"height\":1},\"selectedRatio\":\"NaN\",\"focusArea\":null}}',0),
(20,2,1762443238,1762442661,0,0,0,0,NULL,'{\"alternative\":\"\",\"crop\":\"\",\"description\":\"\",\"hidden\":\"\",\"link\":\"\",\"title\":\"\",\"uid_local\":\"\"}',0,0,0,0,2,NULL,NULL,0,6,'tx_mask_all_cases','tx_mask_photo_case',1,'',NULL,'{\"default\":{\"cropArea\":{\"x\":0,\"y\":0,\"width\":1,\"height\":1},\"selectedRatio\":\"NaN\",\"focusArea\":null}}',0),
(21,2,1762443238,1762442745,0,0,0,0,NULL,'{\"alternative\":\"\",\"crop\":\"\",\"description\":\"\",\"hidden\":\"\",\"link\":\"\",\"title\":\"\",\"uid_local\":\"\"}',0,0,0,0,10,NULL,NULL,0,1,'tx_mask_all_cases','tx_mask_photo_case',1,'',NULL,'{\"default\":{\"cropArea\":{\"x\":0,\"y\":0,\"width\":1,\"height\":1},\"selectedRatio\":\"NaN\",\"focusArea\":null}}',0),
(22,2,1762442865,1762442745,0,0,0,0,NULL,'{\"alternative\":\"\",\"crop\":\"\",\"description\":\"\",\"hidden\":\"\",\"link\":\"\",\"title\":\"\",\"uid_local\":\"\"}',0,0,0,0,11,NULL,NULL,0,2,'tx_mask_all_cases','tx_mask_photo_case',1,'',NULL,'{\"default\":{\"cropArea\":{\"x\":0,\"y\":0,\"width\":1,\"height\":1},\"selectedRatio\":\"NaN\",\"focusArea\":null}}',0),
(23,2,1762443238,1762442865,0,0,0,0,NULL,'{\"alternative\":\"\",\"crop\":\"\",\"description\":\"\",\"hidden\":\"\",\"link\":\"\",\"title\":\"\",\"uid_local\":\"\"}',0,0,0,0,12,NULL,NULL,0,3,'tx_mask_all_cases','tx_mask_photo_case',1,'',NULL,'{\"default\":{\"cropArea\":{\"x\":0,\"y\":0,\"width\":1,\"height\":1},\"selectedRatio\":\"NaN\",\"focusArea\":null}}',0),
(24,1,1762444587,1762444509,1,0,0,0,NULL,'',0,0,0,0,13,NULL,NULL,0,3,'tt_content','tx_mask_home_image',1,'',NULL,'{\"default\":{\"cropArea\":{\"x\":0,\"y\":0,\"width\":1,\"height\":1},\"selectedRatio\":\"NaN\",\"focusArea\":null}}',0),
(25,1,1762444587,1762444587,0,0,0,0,NULL,'',0,0,0,0,14,NULL,NULL,0,3,'tt_content','tx_mask_home_image',1,'',NULL,'{\"default\":{\"cropArea\":{\"x\":0,\"y\":0,\"width\":1,\"height\":1},\"selectedRatio\":\"NaN\",\"focusArea\":null}}',0);
/*!40000 ALTER TABLE `sys_file_reference` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_file_storage`
--

DROP TABLE IF EXISTS `sys_file_storage`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_file_storage` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `description` text DEFAULT NULL,
  `is_public` smallint(6) NOT NULL DEFAULT 0,
  `processingfolder` tinytext DEFAULT NULL,
  `name` varchar(255) NOT NULL DEFAULT '',
  `is_browsable` smallint(5) unsigned NOT NULL DEFAULT 1,
  `is_default` smallint(5) unsigned NOT NULL DEFAULT 0,
  `is_writable` smallint(5) unsigned NOT NULL DEFAULT 1,
  `is_online` smallint(5) unsigned NOT NULL DEFAULT 1,
  `auto_extract_metadata` smallint(5) unsigned NOT NULL DEFAULT 1,
  `driver` varchar(255) NOT NULL DEFAULT '',
  `configuration` longtext DEFAULT NULL,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_file_storage`
--

LOCK TABLES `sys_file_storage` WRITE;
/*!40000 ALTER TABLE `sys_file_storage` DISABLE KEYS */;
INSERT INTO `sys_file_storage` VALUES
(1,0,1762268441,1762268441,0,'This is the local fileadmin/ directory. This storage mount has been created automatically by TYPO3.',1,NULL,'fileadmin',1,1,1,1,1,'Local','<?xml version=\"1.0\" encoding=\"utf-8\" standalone=\"yes\" ?>\n<T3FlexForms>\n    <data>\n        <sheet index=\"sDEF\">\n            <language index=\"lDEF\">\n                <field index=\"basePath\">\n                    <value index=\"vDEF\">fileadmin/</value>\n                </field>\n                <field index=\"pathType\">\n                    <value index=\"vDEF\">relative</value>\n                </field>\n                <field index=\"caseSensitive\">\n                    <value index=\"vDEF\">1</value>\n                </field>\n            </language>\n        </sheet>\n    </data>\n</T3FlexForms>');
/*!40000 ALTER TABLE `sys_file_storage` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_filemounts`
--

DROP TABLE IF EXISTS `sys_filemounts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_filemounts` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `sorting` int(11) NOT NULL DEFAULT 0,
  `description` text DEFAULT NULL,
  `title` varchar(255) NOT NULL DEFAULT '',
  `identifier` longtext DEFAULT NULL,
  `read_only` smallint(5) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`,`hidden`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_filemounts`
--

LOCK TABLES `sys_filemounts` WRITE;
/*!40000 ALTER TABLE `sys_filemounts` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_filemounts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_history`
--

DROP TABLE IF EXISTS `sys_history`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_history` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `actiontype` smallint(6) NOT NULL DEFAULT 0,
  `usertype` varchar(2) NOT NULL DEFAULT 'BE',
  `userid` int(10) unsigned DEFAULT NULL,
  `originaluserid` int(10) unsigned DEFAULT NULL,
  `recuid` int(11) NOT NULL DEFAULT 0,
  `tablename` varchar(255) NOT NULL DEFAULT '',
  `history_data` mediumtext DEFAULT NULL,
  `workspace` int(11) DEFAULT 0,
  `correlation_id` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`uid`),
  KEY `recordident_1` (`tablename`(100),`recuid`),
  KEY `recordident_2` (`tablename`(100),`tstamp`)
) ENGINE=InnoDB AUTO_INCREMENT=132 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_history`
--

LOCK TABLES `sys_history` WRITE;
/*!40000 ALTER TABLE `sys_history` DISABLE KEYS */;
INSERT INTO `sys_history` VALUES
(1,1762268438,1,'BE',1,0,1,'pages','{\"doktype\":\"1\",\"slug\":\"\\/\",\"categories\":\"0\",\"layout\":\"0\",\"lastUpdated\":0,\"newUntil\":0,\"cache_timeout\":\"0\",\"shortcut\":0,\"shortcut_mode\":\"0\",\"content_from_pid\":0,\"mount_pid\":0,\"module\":\"\",\"hidden\":1,\"starttime\":0,\"endtime\":0,\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"sitemap_priority\":\"0.5\",\"twitter_card\":\"\",\"pid\":0,\"sorting\":256,\"perms_userid\":1,\"perms_groupid\":0,\"perms_user\":31,\"perms_group\":27,\"perms_everybody\":0,\"title\":\"Raffael Waldner Home\",\"crdate\":1762268438,\"t3ver_stage\":0,\"tstamp\":1762268438,\"uid\":1}',0,'0400$d1eddf0a7908ab07bdf420cecfd81a0f:e175f7045d7ccbfb26ffcf279422c2e5'),
(2,1762268438,2,'BE',1,0,1,'pages','{\"oldRecord\":{\"l10n_diffsource\":\"\"},\"newRecord\":{\"l10n_diffsource\":\"{\\\"slug\\\":\\\"\\\"}\"}}',0,'0400$42a5d2d552c36b90caa85e806f46f0ad:e175f7045d7ccbfb26ffcf279422c2e5'),
(3,1762268470,2,'BE',1,0,1,'pages','{\"oldRecord\":{\"is_siteroot\":0,\"tsconfig_includes\":null,\"hidden\":1,\"fe_group\":\"0\",\"l10n_diffsource\":\"{\\\"slug\\\":\\\"\\\"}\"},\"newRecord\":{\"is_siteroot\":\"1\",\"tsconfig_includes\":\"EXT:site_package\\/Configuration\\/TsConfig\\/Page\\/All.tsconfig\",\"hidden\":\"0\",\"fe_group\":\"\",\"l10n_diffsource\":\"{\\\"TSconfig\\\":\\\"\\\",\\\"abstract\\\":\\\"\\\",\\\"author\\\":\\\"\\\",\\\"author_email\\\":\\\"\\\",\\\"backend_layout\\\":\\\"\\\",\\\"backend_layout_next_level\\\":\\\"\\\",\\\"cache_tags\\\":\\\"\\\",\\\"cache_timeout\\\":\\\"\\\",\\\"canonical_link\\\":\\\"\\\",\\\"categories\\\":\\\"\\\",\\\"content_from_pid\\\":\\\"\\\",\\\"description\\\":\\\"\\\",\\\"doktype\\\":\\\"\\\",\\\"editlock\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"extendToSubpages\\\":\\\"\\\",\\\"fe_group\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"is_siteroot\\\":\\\"\\\",\\\"keywords\\\":\\\"\\\",\\\"l18n_cfg\\\":\\\"\\\",\\\"lastUpdated\\\":\\\"\\\",\\\"layout\\\":\\\"\\\",\\\"media\\\":\\\"\\\",\\\"module\\\":\\\"\\\",\\\"nav_hide\\\":\\\"\\\",\\\"nav_title\\\":\\\"\\\",\\\"newUntil\\\":\\\"\\\",\\\"no_follow\\\":\\\"\\\",\\\"no_index\\\":\\\"\\\",\\\"no_search\\\":\\\"\\\",\\\"og_description\\\":\\\"\\\",\\\"og_image\\\":\\\"\\\",\\\"og_title\\\":\\\"\\\",\\\"php_tree_stop\\\":\\\"\\\",\\\"rowDescription\\\":\\\"\\\",\\\"seo_title\\\":\\\"\\\",\\\"sitemap_changefreq\\\":\\\"\\\",\\\"sitemap_priority\\\":\\\"\\\",\\\"slug\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"subtitle\\\":\\\"\\\",\\\"target\\\":\\\"\\\",\\\"title\\\":\\\"\\\",\\\"tsconfig_includes\\\":\\\"\\\",\\\"twitter_card\\\":\\\"\\\",\\\"twitter_description\\\":\\\"\\\",\\\"twitter_image\\\":\\\"\\\",\\\"twitter_title\\\":\\\"\\\"}\"}}',0,'0400$eda0cc4042a6fef89330e0ea90ae3d2e:e175f7045d7ccbfb26ffcf279422c2e5'),
(4,1762271436,1,'BE',1,0,2,'pages','{\"doktype\":\"1\",\"slug\":\"\\/work\",\"categories\":\"0\",\"layout\":\"0\",\"lastUpdated\":0,\"newUntil\":0,\"cache_timeout\":\"0\",\"shortcut\":0,\"shortcut_mode\":\"0\",\"content_from_pid\":0,\"mount_pid\":0,\"module\":\"\",\"hidden\":1,\"starttime\":0,\"endtime\":0,\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"sitemap_priority\":\"0.5\",\"twitter_card\":\"\",\"pid\":1,\"sorting\":256,\"perms_userid\":1,\"perms_groupid\":0,\"perms_user\":31,\"perms_group\":27,\"perms_everybody\":0,\"title\":\"Work\",\"sys_language_uid\":0,\"crdate\":1762271436,\"t3ver_stage\":0,\"tstamp\":1762271436,\"uid\":2}',0,'0400$dcf5bbc2a1de76ecd6ce63008406ee26:f11830df10b4b0bca2db34810c2241b3'),
(5,1762271440,1,'BE',1,0,3,'pages','{\"doktype\":\"1\",\"slug\":\"\\/info\",\"categories\":\"0\",\"layout\":\"0\",\"lastUpdated\":0,\"newUntil\":0,\"cache_timeout\":\"0\",\"shortcut\":0,\"shortcut_mode\":\"0\",\"content_from_pid\":0,\"mount_pid\":0,\"module\":\"\",\"hidden\":1,\"starttime\":0,\"endtime\":0,\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"sitemap_priority\":\"0.5\",\"twitter_card\":\"\",\"pid\":1,\"sorting\":128,\"perms_userid\":1,\"perms_groupid\":0,\"perms_user\":31,\"perms_group\":27,\"perms_everybody\":0,\"title\":\"Info\",\"sys_language_uid\":0,\"crdate\":1762271440,\"t3ver_stage\":0,\"tstamp\":1762271440,\"uid\":3}',0,'0400$43325ff52c3c450cd0067802b355a8fb:fe15eeb7d49e64e2cea91ab53fcf0db1'),
(6,1762271444,3,'BE',1,0,3,'pages','{\"oldData\":{\"pid\":1,\"tstamp\":1762271440,\"sorting\":128},\"newData\":{\"tstamp\":1762271444,\"sorting\":512,\"pid\":1}}',0,'0400$32742cf709dc0e57e74c8ac7f80f8949:fe15eeb7d49e64e2cea91ab53fcf0db1'),
(7,1762271448,2,'BE',1,0,3,'pages','{\"oldRecord\":{\"hidden\":1,\"l10n_diffsource\":\"\"},\"newRecord\":{\"hidden\":\"0\",\"l10n_diffsource\":\"{\\\"hidden\\\":\\\"\\\"}\"}}',0,'0400$e5800a4394424e909d48a225d05a2727:fe15eeb7d49e64e2cea91ab53fcf0db1'),
(8,1762271450,2,'BE',1,0,2,'pages','{\"oldRecord\":{\"hidden\":1,\"l10n_diffsource\":\"\"},\"newRecord\":{\"hidden\":\"0\",\"l10n_diffsource\":\"{\\\"hidden\\\":\\\"\\\"}\"}}',0,'0400$9b554904ba4544705089e8414564b57a:f11830df10b4b0bca2db34810c2241b3'),
(9,1762272170,2,'BE',1,0,1,'pages','{\"oldRecord\":{\"tsconfig_includes\":\"EXT:site_package\\/Configuration\\/TsConfig\\/Page\\/All.tsconfig\"},\"newRecord\":{\"tsconfig_includes\":\"\"}}',0,'0400$cf93b3180c744a32dd53b7e6207d40ae:e175f7045d7ccbfb26ffcf279422c2e5'),
(10,1762272170,1,'BE',1,0,1,'sys_file_reference','{\"sorting_foreign\":0,\"title\":null,\"description\":null,\"alternative\":null,\"autoplay\":0,\"hidden\":\"0\",\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"pid\":1,\"link\":\"\",\"crop\":\"{\\\"default\\\":{\\\"cropArea\\\":{\\\"x\\\":0,\\\"y\\\":0,\\\"width\\\":1,\\\"height\\\":1},\\\"selectedRatio\\\":\\\"NaN\\\",\\\"focusArea\\\":null}}\",\"uid_local\":\"2\",\"sys_language_uid\":0,\"crdate\":1762272170,\"t3ver_stage\":0,\"tstamp\":1762272170,\"uid\":1}',0,'0400$cf93b3180c744a32dd53b7e6207d40ae:4cf496f597e7b095ce8b755e6cec3c0c'),
(11,1762272170,2,'BE',1,0,1,'pages','{\"oldRecord\":{\"tsconfig_includes\":\"EXT:site_package\\/Configuration\\/TsConfig\\/Page\\/All.tsconfig\"},\"newRecord\":{\"tsconfig_includes\":\"\"}}',0,'0400$cf93b3180c744a32dd53b7e6207d40ae:e175f7045d7ccbfb26ffcf279422c2e5'),
(12,1762272179,2,'BE',1,0,1,'sys_file_reference','{\"oldRecord\":{\"l10n_diffsource\":\"\"},\"newRecord\":{\"l10n_diffsource\":\"{\\\"alternative\\\":\\\"\\\",\\\"crop\\\":\\\"\\\",\\\"description\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"link\\\":\\\"\\\",\\\"title\\\":\\\"\\\",\\\"uid_local\\\":\\\"\\\"}\"}}',0,'0400$36b179a1a71d068aa95cfba826f7bb3e:4cf496f597e7b095ce8b755e6cec3c0c'),
(13,1762273125,1,'BE',1,0,1,'tt_content','{\"CType\":\"image\",\"categories\":\"0\",\"layout\":\"0\",\"frame_class\":\"default\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"colPos\":\"0\",\"date\":0,\"header_layout\":\"0\",\"header_position\":\"\",\"imagewidth\":0,\"imageheight\":0,\"imageorient\":\"0\",\"imagecols\":\"2\",\"recursive\":\"0\",\"list_type\":\"\",\"sectionIndex\":\"1\",\"hidden\":\"0\",\"starttime\":0,\"endtime\":0,\"sys_language_uid\":0,\"l18n_parent\":0,\"l18n_diffsource\":\"\",\"bullets_type\":\"0\",\"cols\":\"0\",\"table_class\":\"\",\"table_delimiter\":\"124\",\"table_enclosure\":\"0\",\"table_header_position\":\"0\",\"table_tfoot\":0,\"target\":\"\",\"uploads_description\":0,\"uploads_type\":\"0\",\"pid\":1,\"sorting\":256,\"header\":\"\",\"header_link\":\"\",\"subheader\":\"\",\"imageborder\":\"0\",\"image_zoom\":\"0\",\"linkToTop\":\"0\",\"fe_group\":\"\",\"editlock\":\"0\",\"rowDescription\":\"\",\"crdate\":1762273125,\"t3ver_stage\":0,\"tstamp\":1762273125,\"uid\":1}',0,'0400$11fd1e909b2ef03066de4f2e61e6535d:7fa2c035f26826fe83eeecaaeddc4d40'),
(14,1762273125,1,'BE',1,0,2,'sys_file_reference','{\"sorting_foreign\":0,\"title\":null,\"description\":null,\"alternative\":null,\"autoplay\":0,\"hidden\":\"0\",\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"pid\":1,\"link\":\"\",\"crop\":\"{\\\"default\\\":{\\\"cropArea\\\":{\\\"x\\\":0,\\\"y\\\":0,\\\"width\\\":1,\\\"height\\\":1},\\\"selectedRatio\\\":\\\"NaN\\\",\\\"focusArea\\\":null}}\",\"uid_local\":\"2\",\"sys_language_uid\":0,\"crdate\":1762273125,\"t3ver_stage\":0,\"tstamp\":1762273125,\"uid\":2}',0,'0400$11fd1e909b2ef03066de4f2e61e6535d:814fc0f720dfab882655a795e23a5b66'),
(15,1762273157,2,'BE',1,0,1,'tt_content','{\"oldRecord\":{\"l18n_diffsource\":\"\"},\"newRecord\":{\"l18n_diffsource\":\"{\\\"CType\\\":\\\"\\\",\\\"categories\\\":\\\"\\\",\\\"colPos\\\":\\\"\\\",\\\"date\\\":\\\"\\\",\\\"editlock\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"fe_group\\\":\\\"\\\",\\\"frame_class\\\":\\\"\\\",\\\"header\\\":\\\"\\\",\\\"header_layout\\\":\\\"\\\",\\\"header_link\\\":\\\"\\\",\\\"header_position\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"image\\\":\\\"\\\",\\\"image_zoom\\\":\\\"\\\",\\\"imageborder\\\":\\\"\\\",\\\"imagecols\\\":\\\"\\\",\\\"imageheight\\\":\\\"\\\",\\\"imageorient\\\":\\\"\\\",\\\"imagewidth\\\":\\\"\\\",\\\"layout\\\":\\\"\\\",\\\"linkToTop\\\":\\\"\\\",\\\"rowDescription\\\":\\\"\\\",\\\"sectionIndex\\\":\\\"\\\",\\\"space_after_class\\\":\\\"\\\",\\\"space_before_class\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"subheader\\\":\\\"\\\"}\"}}',0,'0400$86d29d3bbba3aeae865fbcadc6f5c468:7fa2c035f26826fe83eeecaaeddc4d40'),
(16,1762273157,2,'BE',1,0,2,'sys_file_reference','{\"oldRecord\":{\"l10n_diffsource\":\"\"},\"newRecord\":{\"l10n_diffsource\":\"{\\\"hidden\\\":\\\"\\\"}\"}}',0,'0400$86d29d3bbba3aeae865fbcadc6f5c468:814fc0f720dfab882655a795e23a5b66'),
(17,1762273638,2,'BE',1,0,1,'pages','{\"oldRecord\":{\"media\":1},\"newRecord\":{\"media\":0}}',0,'0400$ae3b63a193195900f7d0a16f803289b7:e175f7045d7ccbfb26ffcf279422c2e5'),
(18,1762273638,4,'BE',1,0,1,'sys_file_reference',NULL,0,'0400$ae3b63a193195900f7d0a16f803289b7:4cf496f597e7b095ce8b755e6cec3c0c'),
(19,1762416826,1,'BE',1,0,4,'pages','{\"doktype\":\"254\",\"slug\":\"\\/footer\",\"categories\":\"0\",\"layout\":\"0\",\"lastUpdated\":0,\"newUntil\":0,\"cache_timeout\":\"0\",\"shortcut\":0,\"shortcut_mode\":\"0\",\"content_from_pid\":0,\"mount_pid\":0,\"module\":\"\",\"hidden\":1,\"starttime\":0,\"endtime\":0,\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"sitemap_priority\":\"0.5\",\"twitter_card\":\"\",\"pid\":1,\"sorting\":768,\"perms_userid\":1,\"perms_groupid\":0,\"perms_user\":31,\"perms_group\":27,\"perms_everybody\":0,\"title\":\"Footer\",\"sys_language_uid\":0,\"crdate\":1762416826,\"t3ver_stage\":0,\"tstamp\":1762416826,\"uid\":4}',0,'0400$3964f60d6eba7fa1d89bcb9d814522c6:412add0b3eb6ec8f1cb6710aea92e21e'),
(20,1762416828,2,'BE',1,0,4,'pages','{\"oldRecord\":{\"hidden\":1,\"l10n_diffsource\":\"\"},\"newRecord\":{\"hidden\":\"0\",\"l10n_diffsource\":\"{\\\"hidden\\\":\\\"\\\"}\"}}',0,'0400$577b26c37e7a88be91ec8699db028d6e:412add0b3eb6ec8f1cb6710aea92e21e'),
(21,1762416979,1,'BE',1,0,2,'tt_content','{\"CType\":\"text\",\"categories\":\"0\",\"layout\":\"0\",\"frame_class\":\"default\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"colPos\":\"0\",\"date\":0,\"header_layout\":\"0\",\"header_position\":\"\",\"imagewidth\":0,\"imageheight\":0,\"imageorient\":\"0\",\"imagecols\":\"2\",\"recursive\":\"0\",\"list_type\":\"\",\"sectionIndex\":\"1\",\"hidden\":\"0\",\"starttime\":0,\"endtime\":0,\"sys_language_uid\":0,\"l18n_parent\":0,\"l18n_diffsource\":\"\",\"bullets_type\":\"0\",\"cols\":\"0\",\"table_class\":\"\",\"table_delimiter\":\"124\",\"table_enclosure\":\"0\",\"table_header_position\":\"0\",\"table_tfoot\":0,\"target\":\"\",\"uploads_description\":0,\"uploads_type\":\"0\",\"pid\":4,\"sorting\":256,\"header\":\"\",\"header_link\":\"\",\"subheader\":\"\",\"bodytext\":\"<p>Raffael Waldner Fotografie<br \\/><a href=\\\"https:\\/\\/maps.app.goo.gl\\/7nodM6A4MA3crJyk8\\\">Aarbergergasse 40 \\u2013 Bern<\\/a><br \\/><a href=\\\"tel:+41786011099\\\">+41 78 601 10 99<\\/a><br \\/><a href=\\\"mailto:hello@raffaelwaldner.com\\\">hello@raffaelwaldner.com<\\/a><\\/p>\",\"linkToTop\":\"0\",\"fe_group\":\"\",\"editlock\":\"0\",\"rowDescription\":\"\",\"crdate\":1762416979,\"t3ver_stage\":0,\"tstamp\":1762416979,\"uid\":2}',0,'0400$45927bc9001c52b190a32b241dd05679:01dbc21fdb1263685b9147b3b1596ea8'),
(22,1762419030,1,'BE',1,0,5,'pages','{\"doktype\":\"1\",\"slug\":\"\\/newsletter\",\"categories\":\"0\",\"layout\":\"0\",\"lastUpdated\":0,\"newUntil\":0,\"cache_timeout\":\"0\",\"shortcut\":0,\"shortcut_mode\":\"0\",\"content_from_pid\":0,\"mount_pid\":0,\"module\":\"\",\"hidden\":1,\"starttime\":0,\"endtime\":0,\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"sitemap_priority\":\"0.5\",\"twitter_card\":\"\",\"pid\":1,\"sorting\":640,\"perms_userid\":1,\"perms_groupid\":0,\"perms_user\":31,\"perms_group\":27,\"perms_everybody\":0,\"title\":\"Newsletter\",\"sys_language_uid\":0,\"crdate\":1762419030,\"t3ver_stage\":0,\"tstamp\":1762419030,\"uid\":5}',0,'0400$a1ff437e7e8fd5c63d86bd0222666aa1:7ef5a4e3e11db8ac3fea4d7a75468161'),
(23,1762419032,2,'BE',1,0,5,'pages','{\"oldRecord\":{\"hidden\":1,\"l10n_diffsource\":\"\"},\"newRecord\":{\"hidden\":\"0\",\"l10n_diffsource\":\"{\\\"hidden\\\":\\\"\\\"}\"}}',0,'0400$daf902280de40f78bb0fc90490a14400:7ef5a4e3e11db8ac3fea4d7a75468161'),
(24,1762419035,2,'BE',1,0,5,'pages','{\"oldRecord\":{\"nav_hide\":0,\"l10n_diffsource\":\"{\\\"hidden\\\":\\\"\\\"}\"},\"newRecord\":{\"nav_hide\":\"1\",\"l10n_diffsource\":\"{\\\"nav_hide\\\":\\\"\\\"}\"}}',0,'0400$4939bfd68c68510e6a7e0f0057bd043c:7ef5a4e3e11db8ac3fea4d7a75468161'),
(25,1762422668,1,'BE',1,0,3,'tt_content','{\"CType\":\"mask_case_home\",\"categories\":\"0\",\"layout\":\"0\",\"frame_class\":\"default\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"colPos\":\"0\",\"date\":0,\"header_layout\":\"0\",\"header_position\":\"\",\"imagewidth\":0,\"imageheight\":0,\"imageorient\":\"0\",\"imagecols\":\"2\",\"recursive\":\"0\",\"list_type\":\"\",\"sectionIndex\":\"1\",\"hidden\":\"0\",\"starttime\":0,\"endtime\":0,\"sys_language_uid\":0,\"l18n_parent\":0,\"l18n_diffsource\":\"\",\"bullets_type\":\"0\",\"cols\":\"0\",\"table_class\":\"\",\"table_delimiter\":\"124\",\"table_enclosure\":\"0\",\"table_header_position\":\"0\",\"table_tfoot\":0,\"target\":\"\",\"uploads_description\":0,\"uploads_type\":\"0\",\"pid\":1,\"sorting\":128,\"header\":\"Only for orientation purposes\",\"tx_mask_small_text_on_image\":\"<p>Lorem ipsum dolorem,&nbsp;<br \\/>Zurich, Switzerland<\\/p>\",\"tx_mask_chose_link\":\"t3:\\/\\/page?uid=2\",\"linkToTop\":\"0\",\"fe_group\":\"\",\"editlock\":\"0\",\"rowDescription\":\"\",\"crdate\":1762422668,\"t3ver_stage\":0,\"tstamp\":1762422668,\"uid\":3}',0,'0400$d5b736b20690bc4a4a3d677c7026215c:b92300cfb5d1d3645c9cb212a7f56c1f'),
(26,1762422668,1,'BE',1,0,3,'sys_file_reference','{\"sorting_foreign\":0,\"title\":null,\"description\":null,\"alternative\":null,\"autoplay\":0,\"hidden\":\"0\",\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"pid\":1,\"link\":\"\",\"crop\":\"{\\\"default\\\":{\\\"cropArea\\\":{\\\"x\\\":0,\\\"y\\\":0,\\\"width\\\":1,\\\"height\\\":1},\\\"selectedRatio\\\":\\\"NaN\\\",\\\"focusArea\\\":null}}\",\"uid_local\":\"2\",\"sys_language_uid\":0,\"crdate\":1762422668,\"t3ver_stage\":0,\"tstamp\":1762422668,\"uid\":3}',0,'0400$d5b736b20690bc4a4a3d677c7026215c:d2c609347a4764200256b39b9425159a'),
(27,1762422672,4,'BE',1,0,2,'sys_file_reference',NULL,0,'0400$38fe2abf3c7585ed94f0f991eacd5845:814fc0f720dfab882655a795e23a5b66'),
(28,1762422672,4,'BE',1,0,1,'tt_content',NULL,0,'0400$38fe2abf3c7585ed94f0f991eacd5845:7fa2c035f26826fe83eeecaaeddc4d40'),
(29,1762423246,1,'BE',1,0,4,'sys_file_reference','{\"pid\":1,\"tstamp\":1762423246,\"crdate\":1762423246,\"deleted\":0,\"hidden\":0,\"sys_language_uid\":0,\"l10n_parent\":0,\"l10n_state\":null,\"l10n_diffsource\":\"\",\"t3ver_oid\":0,\"t3ver_wsid\":0,\"t3ver_state\":0,\"t3ver_stage\":0,\"uid_local\":\"2\",\"title\":null,\"alternative\":null,\"showinpreview\":0,\"uid_foreign\":3,\"tablenames\":\"tt_content\",\"fieldname\":\"tx_mask_home_image\",\"sorting_foreign\":1,\"link\":\"\",\"description\":null,\"crop\":\"{\\\"default\\\":{\\\"cropArea\\\":{\\\"x\\\":0,\\\"y\\\":0,\\\"width\\\":1,\\\"height\\\":1},\\\"selectedRatio\\\":\\\"NaN\\\",\\\"focusArea\\\":null}}\",\"autoplay\":0,\"uid\":4}',0,'0400$6e83abf21c18d46c5edef108b2102c87:cea5fcd7b97871880cfe3717d6b52ef4'),
(30,1762423246,1,'BE',1,0,4,'tt_content','{\"CType\":\"mask_case_home\",\"categories\":\"0\",\"layout\":\"0\",\"frame_class\":\"default\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"colPos\":\"0\",\"date\":0,\"header_layout\":\"0\",\"header_position\":\"\",\"imagewidth\":0,\"imageheight\":0,\"imageorient\":\"0\",\"imagecols\":\"2\",\"recursive\":\"0\",\"list_type\":\"\",\"sectionIndex\":1,\"hidden\":1,\"starttime\":0,\"endtime\":0,\"l18n_parent\":0,\"l18n_diffsource\":\"\",\"bullets_type\":\"0\",\"cols\":\"0\",\"table_class\":\"\",\"table_delimiter\":\"124\",\"table_enclosure\":\"0\",\"table_header_position\":\"0\",\"table_tfoot\":0,\"target\":\"\",\"uploads_description\":0,\"uploads_type\":\"0\",\"pid\":1,\"sorting\":384,\"fe_group\":\"\",\"rowDescription\":\"\",\"editlock\":0,\"sys_language_uid\":0,\"l10n_source\":0,\"l10n_state\":null,\"table_caption\":null,\"tx_impexp_origuid\":0,\"header\":\"Only for orientation purposes\",\"header_link\":\"\",\"subheader\":\"\",\"bodytext\":null,\"imageborder\":0,\"image_zoom\":0,\"pages\":\"\",\"records\":\"\",\"linkToTop\":0,\"pi_flexform\":null,\"selected_categories\":0,\"category_field\":\"\",\"file_collections\":\"\",\"filelink_size\":0,\"filelink_sorting\":\"\",\"filelink_sorting_direction\":\"\",\"tx_mask_small_text_on_image\":\"<p>Lorem ipsum dolorem,&nbsp;<br \\/>Zurich, Switzerland<\\/p>\",\"tx_mask_chose_link\":\"t3:\\/\\/page?uid=2\",\"crdate\":1762423246,\"t3ver_stage\":0,\"tstamp\":1762423246,\"uid\":4}',0,'0400$f0bce43624aab4ee350a39c99614d59c:4d391f5ef79b8d5d10dffa8a07ca167d'),
(31,1762423246,2,'BE',1,0,4,'tt_content','{\"oldRecord\":{\"l18n_diffsource\":\"\"},\"newRecord\":{\"l18n_diffsource\":\"{\\\"colPos\\\":\\\"\\\"}\"}}',0,'0400$15019b07a82e4c8a10c7aedd59ac6b7c:4d391f5ef79b8d5d10dffa8a07ca167d'),
(32,1762423271,2,'BE',1,0,4,'tt_content','{\"oldRecord\":{\"hidden\":1,\"l18n_diffsource\":\"{\\\"colPos\\\":\\\"\\\"}\"},\"newRecord\":{\"hidden\":\"0\",\"l18n_diffsource\":\"{\\\"hidden\\\":\\\"\\\"}\"}}',0,'0400$40bec4d81cc712cfbcd3c868108cde6e:4d391f5ef79b8d5d10dffa8a07ca167d'),
(33,1762423393,2,'BE',1,0,4,'tt_content','{\"oldRecord\":{\"l18n_diffsource\":\"{\\\"hidden\\\":\\\"\\\"}\"},\"newRecord\":{\"l18n_diffsource\":\"{\\\"CType\\\":\\\"\\\",\\\"categories\\\":\\\"\\\",\\\"colPos\\\":\\\"\\\",\\\"editlock\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"fe_group\\\":\\\"\\\",\\\"frame_class\\\":\\\"\\\",\\\"header\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"layout\\\":\\\"\\\",\\\"linkToTop\\\":\\\"\\\",\\\"rowDescription\\\":\\\"\\\",\\\"sectionIndex\\\":\\\"\\\",\\\"space_after_class\\\":\\\"\\\",\\\"space_before_class\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"tx_mask_chose_link\\\":\\\"\\\",\\\"tx_mask_home_image\\\":\\\"\\\",\\\"tx_mask_small_text_on_image\\\":\\\"\\\"}\"}}',0,'0400$8c335933a61340d06f0f9c17c4a880f9:4d391f5ef79b8d5d10dffa8a07ca167d'),
(34,1762423393,1,'BE',1,0,5,'sys_file_reference','{\"sorting_foreign\":0,\"title\":null,\"description\":null,\"alternative\":null,\"autoplay\":0,\"hidden\":\"0\",\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"pid\":1,\"link\":\"\",\"crop\":\"{\\\"default\\\":{\\\"cropArea\\\":{\\\"x\\\":0,\\\"y\\\":0,\\\"width\\\":1,\\\"height\\\":1},\\\"selectedRatio\\\":\\\"NaN\\\",\\\"focusArea\\\":null}}\",\"uid_local\":\"3\",\"sys_language_uid\":0,\"crdate\":1762423393,\"t3ver_stage\":0,\"tstamp\":1762423393,\"uid\":5}',0,'0400$8c335933a61340d06f0f9c17c4a880f9:5f15a1453f67b933ed3314381f5d67e4'),
(35,1762423393,2,'BE',1,0,4,'tt_content','{\"oldRecord\":{\"l18n_diffsource\":\"{\\\"hidden\\\":\\\"\\\"}\"},\"newRecord\":{\"l18n_diffsource\":\"{\\\"CType\\\":\\\"\\\",\\\"categories\\\":\\\"\\\",\\\"colPos\\\":\\\"\\\",\\\"editlock\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"fe_group\\\":\\\"\\\",\\\"frame_class\\\":\\\"\\\",\\\"header\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"layout\\\":\\\"\\\",\\\"linkToTop\\\":\\\"\\\",\\\"rowDescription\\\":\\\"\\\",\\\"sectionIndex\\\":\\\"\\\",\\\"space_after_class\\\":\\\"\\\",\\\"space_before_class\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"tx_mask_chose_link\\\":\\\"\\\",\\\"tx_mask_home_image\\\":\\\"\\\",\\\"tx_mask_small_text_on_image\\\":\\\"\\\"}\"}}',0,'0400$8c335933a61340d06f0f9c17c4a880f9:4d391f5ef79b8d5d10dffa8a07ca167d'),
(36,1762423393,4,'BE',1,0,4,'sys_file_reference',NULL,0,'0400$8c335933a61340d06f0f9c17c4a880f9:cea5fcd7b97871880cfe3717d6b52ef4'),
(37,1762423420,1,'BE',1,0,6,'sys_file_reference','{\"pid\":1,\"tstamp\":1762423420,\"crdate\":1762423420,\"deleted\":0,\"hidden\":0,\"sys_language_uid\":0,\"l10n_parent\":0,\"l10n_state\":null,\"l10n_diffsource\":\"\",\"t3ver_oid\":0,\"t3ver_wsid\":0,\"t3ver_state\":0,\"t3ver_stage\":0,\"uid_local\":\"3\",\"title\":null,\"alternative\":null,\"showinpreview\":0,\"uid_foreign\":4,\"tablenames\":\"tt_content\",\"fieldname\":\"tx_mask_home_image\",\"sorting_foreign\":1,\"link\":\"\",\"description\":null,\"crop\":\"{\\\"default\\\":{\\\"cropArea\\\":{\\\"x\\\":0,\\\"y\\\":0,\\\"width\\\":1,\\\"height\\\":1},\\\"selectedRatio\\\":\\\"NaN\\\",\\\"focusArea\\\":null}}\",\"autoplay\":0,\"uid\":6}',0,'0400$d73a94509b37a1631172b16f5e2228cf:768f9cd4e98812f969df7ebe17f11b50'),
(38,1762423420,1,'BE',1,0,5,'tt_content','{\"CType\":\"mask_case_home\",\"categories\":\"0\",\"layout\":\"0\",\"frame_class\":\"default\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"colPos\":\"0\",\"date\":0,\"header_layout\":\"0\",\"header_position\":\"\",\"imagewidth\":0,\"imageheight\":0,\"imageorient\":\"0\",\"imagecols\":\"2\",\"recursive\":\"0\",\"list_type\":\"\",\"sectionIndex\":1,\"hidden\":1,\"starttime\":0,\"endtime\":0,\"l18n_parent\":0,\"l18n_diffsource\":\"{\\\"CType\\\":\\\"\\\",\\\"categories\\\":\\\"\\\",\\\"colPos\\\":\\\"\\\",\\\"editlock\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"fe_group\\\":\\\"\\\",\\\"frame_class\\\":\\\"\\\",\\\"header\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"layout\\\":\\\"\\\",\\\"linkToTop\\\":\\\"\\\",\\\"rowDescription\\\":\\\"\\\",\\\"sectionIndex\\\":\\\"\\\",\\\"space_after_class\\\":\\\"\\\",\\\"space_before_class\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"tx_mask_chose_link\\\":\\\"\\\",\\\"tx_mask_home_image\\\":\\\"\\\",\\\"tx_mask_small_text_on_image\\\":\\\"\\\"}\",\"bullets_type\":\"0\",\"cols\":\"0\",\"table_class\":\"\",\"table_delimiter\":\"124\",\"table_enclosure\":\"0\",\"table_header_position\":\"0\",\"table_tfoot\":0,\"target\":\"\",\"uploads_description\":0,\"uploads_type\":\"0\",\"pid\":1,\"sorting\":640,\"fe_group\":\"\",\"rowDescription\":\"\",\"editlock\":0,\"sys_language_uid\":0,\"l10n_source\":0,\"l10n_state\":null,\"table_caption\":null,\"tx_impexp_origuid\":0,\"header\":\"Only for orientation purposes\",\"header_link\":\"\",\"subheader\":\"\",\"bodytext\":null,\"imageborder\":0,\"image_zoom\":0,\"pages\":\"\",\"records\":\"\",\"linkToTop\":0,\"pi_flexform\":null,\"selected_categories\":0,\"category_field\":\"\",\"file_collections\":\"\",\"filelink_size\":0,\"filelink_sorting\":\"\",\"filelink_sorting_direction\":\"\",\"tx_mask_small_text_on_image\":\"<p>Lorem ipsum dolorem,&nbsp;<br \\/>Zurich, Switzerland<\\/p>\",\"tx_mask_chose_link\":\"t3:\\/\\/page?uid=2\",\"crdate\":1762423420,\"t3ver_stage\":0,\"tstamp\":1762423420,\"uid\":5}',0,'0400$e4d637011b477f8eb2e0b7229280c2aa:c7626fc9bcba6f70beb6ebc085a400db'),
(39,1762423420,2,'BE',1,0,5,'tt_content','{\"oldRecord\":{\"l18n_diffsource\":\"{\\\"CType\\\":\\\"\\\",\\\"categories\\\":\\\"\\\",\\\"colPos\\\":\\\"\\\",\\\"editlock\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"fe_group\\\":\\\"\\\",\\\"frame_class\\\":\\\"\\\",\\\"header\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"layout\\\":\\\"\\\",\\\"linkToTop\\\":\\\"\\\",\\\"rowDescription\\\":\\\"\\\",\\\"sectionIndex\\\":\\\"\\\",\\\"space_after_class\\\":\\\"\\\",\\\"space_before_class\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"tx_mask_chose_link\\\":\\\"\\\",\\\"tx_mask_home_image\\\":\\\"\\\",\\\"tx_mask_small_text_on_image\\\":\\\"\\\"}\"},\"newRecord\":{\"l18n_diffsource\":\"{\\\"colPos\\\":\\\"\\\"}\"}}',0,'0400$349b480f4e6dafd1fa16ce6074b2d170:c7626fc9bcba6f70beb6ebc085a400db'),
(40,1762423422,1,'BE',1,0,7,'sys_file_reference','{\"pid\":1,\"tstamp\":1762423422,\"crdate\":1762423422,\"deleted\":0,\"hidden\":0,\"sys_language_uid\":0,\"l10n_parent\":0,\"l10n_state\":null,\"l10n_diffsource\":\"\",\"t3ver_oid\":0,\"t3ver_wsid\":0,\"t3ver_state\":0,\"t3ver_stage\":0,\"uid_local\":\"3\",\"title\":null,\"alternative\":null,\"showinpreview\":0,\"uid_foreign\":4,\"tablenames\":\"tt_content\",\"fieldname\":\"tx_mask_home_image\",\"sorting_foreign\":1,\"link\":\"\",\"description\":null,\"crop\":\"{\\\"default\\\":{\\\"cropArea\\\":{\\\"x\\\":0,\\\"y\\\":0,\\\"width\\\":1,\\\"height\\\":1},\\\"selectedRatio\\\":\\\"NaN\\\",\\\"focusArea\\\":null}}\",\"autoplay\":0,\"uid\":7}',0,'0400$50e0d1338b7f501b5cdcc80aff3f6042:117c97010b9af15cb554d115dba4e316'),
(41,1762423422,1,'BE',1,0,6,'tt_content','{\"CType\":\"mask_case_home\",\"categories\":\"0\",\"layout\":\"0\",\"frame_class\":\"default\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"colPos\":\"0\",\"date\":0,\"header_layout\":\"0\",\"header_position\":\"\",\"imagewidth\":0,\"imageheight\":0,\"imageorient\":\"0\",\"imagecols\":\"2\",\"recursive\":\"0\",\"list_type\":\"\",\"sectionIndex\":1,\"hidden\":1,\"starttime\":0,\"endtime\":0,\"l18n_parent\":0,\"l18n_diffsource\":\"{\\\"CType\\\":\\\"\\\",\\\"categories\\\":\\\"\\\",\\\"colPos\\\":\\\"\\\",\\\"editlock\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"fe_group\\\":\\\"\\\",\\\"frame_class\\\":\\\"\\\",\\\"header\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"layout\\\":\\\"\\\",\\\"linkToTop\\\":\\\"\\\",\\\"rowDescription\\\":\\\"\\\",\\\"sectionIndex\\\":\\\"\\\",\\\"space_after_class\\\":\\\"\\\",\\\"space_before_class\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"tx_mask_chose_link\\\":\\\"\\\",\\\"tx_mask_home_image\\\":\\\"\\\",\\\"tx_mask_small_text_on_image\\\":\\\"\\\"}\",\"bullets_type\":\"0\",\"cols\":\"0\",\"table_class\":\"\",\"table_delimiter\":\"124\",\"table_enclosure\":\"0\",\"table_header_position\":\"0\",\"table_tfoot\":0,\"target\":\"\",\"uploads_description\":0,\"uploads_type\":\"0\",\"pid\":1,\"sorting\":896,\"fe_group\":\"\",\"rowDescription\":\"\",\"editlock\":0,\"sys_language_uid\":0,\"l10n_source\":0,\"l10n_state\":null,\"table_caption\":null,\"tx_impexp_origuid\":0,\"header\":\"Only for orientation purposes\",\"header_link\":\"\",\"subheader\":\"\",\"bodytext\":null,\"imageborder\":0,\"image_zoom\":0,\"pages\":\"\",\"records\":\"\",\"linkToTop\":0,\"pi_flexform\":null,\"selected_categories\":0,\"category_field\":\"\",\"file_collections\":\"\",\"filelink_size\":0,\"filelink_sorting\":\"\",\"filelink_sorting_direction\":\"\",\"tx_mask_small_text_on_image\":\"<p>Lorem ipsum dolorem,&nbsp;<br \\/>Zurich, Switzerland<\\/p>\",\"tx_mask_chose_link\":\"t3:\\/\\/page?uid=2\",\"crdate\":1762423422,\"t3ver_stage\":0,\"tstamp\":1762423422,\"uid\":6}',0,'0400$bd9c356b8824582c12aa801148fb0a23:c0db6803ab1ec5f70c36e2a72187867b'),
(42,1762423422,2,'BE',1,0,6,'tt_content','{\"oldRecord\":{\"l18n_diffsource\":\"{\\\"CType\\\":\\\"\\\",\\\"categories\\\":\\\"\\\",\\\"colPos\\\":\\\"\\\",\\\"editlock\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"fe_group\\\":\\\"\\\",\\\"frame_class\\\":\\\"\\\",\\\"header\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"layout\\\":\\\"\\\",\\\"linkToTop\\\":\\\"\\\",\\\"rowDescription\\\":\\\"\\\",\\\"sectionIndex\\\":\\\"\\\",\\\"space_after_class\\\":\\\"\\\",\\\"space_before_class\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"tx_mask_chose_link\\\":\\\"\\\",\\\"tx_mask_home_image\\\":\\\"\\\",\\\"tx_mask_small_text_on_image\\\":\\\"\\\"}\"},\"newRecord\":{\"l18n_diffsource\":\"{\\\"colPos\\\":\\\"\\\"}\"}}',0,'0400$1a7aa04b3364a6205de9f97c61953430:c0db6803ab1ec5f70c36e2a72187867b'),
(43,1762423423,2,'BE',1,0,6,'tt_content','{\"oldRecord\":{\"hidden\":1,\"l18n_diffsource\":\"{\\\"colPos\\\":\\\"\\\"}\"},\"newRecord\":{\"hidden\":\"0\",\"l18n_diffsource\":\"{\\\"hidden\\\":\\\"\\\"}\"}}',0,'0400$033e12e08b3f1f58ecca09fefa0c2def:c0db6803ab1ec5f70c36e2a72187867b'),
(44,1762423425,2,'BE',1,0,5,'tt_content','{\"oldRecord\":{\"hidden\":1,\"l18n_diffsource\":\"{\\\"colPos\\\":\\\"\\\"}\"},\"newRecord\":{\"hidden\":\"0\",\"l18n_diffsource\":\"{\\\"hidden\\\":\\\"\\\"}\"}}',0,'0400$ad43cb9b80c2779082211d629c7db512:c7626fc9bcba6f70beb6ebc085a400db'),
(45,1762425054,1,'BE',1,0,7,'tt_content','{\"CType\":\"mask_work\",\"categories\":\"0\",\"layout\":\"0\",\"frame_class\":\"default\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"colPos\":\"0\",\"date\":0,\"header_layout\":\"0\",\"header_position\":\"\",\"imagewidth\":0,\"imageheight\":0,\"imageorient\":\"0\",\"imagecols\":\"2\",\"recursive\":\"0\",\"list_type\":\"\",\"sectionIndex\":\"1\",\"hidden\":\"0\",\"starttime\":0,\"endtime\":0,\"sys_language_uid\":0,\"l18n_parent\":0,\"l18n_diffsource\":\"\",\"bullets_type\":\"0\",\"cols\":\"0\",\"table_class\":\"\",\"table_delimiter\":\"124\",\"table_enclosure\":\"0\",\"table_header_position\":\"0\",\"table_tfoot\":0,\"target\":\"\",\"uploads_description\":0,\"uploads_type\":\"0\",\"pid\":2,\"sorting\":256,\"linkToTop\":\"0\",\"fe_group\":\"\",\"editlock\":\"0\",\"rowDescription\":\"\",\"crdate\":1762425054,\"t3ver_stage\":0,\"tstamp\":1762425054,\"uid\":7}',0,'0400$d7e15659baf70f531b963cc478307273:ea41b626baac59a1fe0716bc344af5d9'),
(46,1762432121,1,'BE',1,0,6,'pages','{\"doktype\":\"1\",\"slug\":\"\\/work\\/case-nr1\",\"categories\":\"0\",\"layout\":\"0\",\"lastUpdated\":0,\"newUntil\":0,\"cache_timeout\":\"0\",\"shortcut\":0,\"shortcut_mode\":\"0\",\"content_from_pid\":0,\"mount_pid\":0,\"module\":\"\",\"hidden\":1,\"starttime\":0,\"endtime\":0,\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"sitemap_priority\":\"0.5\",\"twitter_card\":\"\",\"pid\":2,\"sorting\":256,\"perms_userid\":1,\"perms_groupid\":0,\"perms_user\":31,\"perms_group\":27,\"perms_everybody\":0,\"title\":\"Case nr1\",\"sys_language_uid\":0,\"crdate\":1762432121,\"t3ver_stage\":0,\"tstamp\":1762432121,\"uid\":6}',0,'0400$4848fb2b9b678a9b9d3ad7d5c26f9232:c75354c439a48dbde16b03ac553a080d'),
(47,1762432124,2,'BE',1,0,6,'pages','{\"oldRecord\":{\"hidden\":1,\"l10n_diffsource\":\"\"},\"newRecord\":{\"hidden\":\"0\",\"l10n_diffsource\":\"{\\\"hidden\\\":\\\"\\\"}\"}}',0,'0400$7a60ce90e093df594ab8a3c233c386c1:c75354c439a48dbde16b03ac553a080d'),
(48,1762432251,1,'BE',1,0,8,'tt_content','{\"CType\":\"mask_detail\",\"categories\":\"0\",\"layout\":\"0\",\"frame_class\":\"default\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"colPos\":\"0\",\"date\":0,\"header_layout\":\"0\",\"header_position\":\"\",\"imagewidth\":0,\"imageheight\":0,\"imageorient\":\"0\",\"imagecols\":\"2\",\"recursive\":\"0\",\"list_type\":\"\",\"sectionIndex\":\"1\",\"hidden\":\"0\",\"starttime\":0,\"endtime\":0,\"sys_language_uid\":0,\"l18n_parent\":0,\"l18n_diffsource\":\"\",\"bullets_type\":\"0\",\"cols\":\"0\",\"table_class\":\"\",\"table_delimiter\":\"124\",\"table_enclosure\":\"0\",\"table_header_position\":\"0\",\"table_tfoot\":0,\"target\":\"\",\"uploads_description\":0,\"uploads_type\":\"0\",\"pid\":6,\"sorting\":256,\"header\":\"\",\"linkToTop\":\"0\",\"fe_group\":\"\",\"editlock\":\"0\",\"rowDescription\":\"\",\"crdate\":1762432251,\"t3ver_stage\":0,\"tstamp\":1762432251,\"uid\":8}',0,'0400$f117633a0757b61833a97b2eb8b3d3da:2097d84972a039cb6bfe093b17089287'),
(49,1762432251,1,'BE',1,0,8,'sys_file_reference','{\"sorting_foreign\":0,\"title\":null,\"description\":null,\"alternative\":null,\"autoplay\":0,\"hidden\":\"0\",\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"pid\":6,\"link\":\"\",\"crop\":\"{\\\"default\\\":{\\\"cropArea\\\":{\\\"x\\\":0,\\\"y\\\":0,\\\"width\\\":1,\\\"height\\\":1},\\\"selectedRatio\\\":\\\"NaN\\\",\\\"focusArea\\\":null}}\",\"uid_local\":\"4\",\"sys_language_uid\":0,\"crdate\":1762432251,\"t3ver_stage\":0,\"tstamp\":1762432251,\"uid\":8}',0,'0400$f117633a0757b61833a97b2eb8b3d3da:5ff44a4f59fb3bfbe13a2c3ed1d0bd8b'),
(50,1762432251,1,'BE',1,0,9,'sys_file_reference','{\"sorting_foreign\":0,\"title\":null,\"description\":null,\"alternative\":null,\"autoplay\":0,\"hidden\":\"0\",\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"pid\":6,\"link\":\"\",\"crop\":\"{\\\"default\\\":{\\\"cropArea\\\":{\\\"x\\\":0,\\\"y\\\":0,\\\"width\\\":1,\\\"height\\\":1},\\\"selectedRatio\\\":\\\"NaN\\\",\\\"focusArea\\\":null}}\",\"uid_local\":\"5\",\"sys_language_uid\":0,\"crdate\":1762432251,\"t3ver_stage\":0,\"tstamp\":1762432251,\"uid\":9}',0,'0400$f117633a0757b61833a97b2eb8b3d3da:729356755eb8ee035abf6b9b02e20c8f'),
(51,1762432251,1,'BE',1,0,10,'sys_file_reference','{\"sorting_foreign\":0,\"title\":null,\"description\":null,\"alternative\":null,\"autoplay\":0,\"hidden\":\"0\",\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"pid\":6,\"link\":\"\",\"crop\":\"{\\\"default\\\":{\\\"cropArea\\\":{\\\"x\\\":0,\\\"y\\\":0,\\\"width\\\":1,\\\"height\\\":1},\\\"selectedRatio\\\":\\\"NaN\\\",\\\"focusArea\\\":null}}\",\"uid_local\":\"6\",\"sys_language_uid\":0,\"crdate\":1762432251,\"t3ver_stage\":0,\"tstamp\":1762432251,\"uid\":10}',0,'0400$f117633a0757b61833a97b2eb8b3d3da:b34a074e38840d41041eaee66c42bb0d'),
(52,1762432251,1,'BE',1,0,11,'sys_file_reference','{\"sorting_foreign\":0,\"title\":null,\"description\":null,\"alternative\":null,\"autoplay\":0,\"hidden\":\"0\",\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"pid\":6,\"link\":\"\",\"crop\":\"{\\\"default\\\":{\\\"cropArea\\\":{\\\"x\\\":0,\\\"y\\\":0,\\\"width\\\":1,\\\"height\\\":1},\\\"selectedRatio\\\":\\\"NaN\\\",\\\"focusArea\\\":null}}\",\"uid_local\":\"7\",\"sys_language_uid\":0,\"crdate\":1762432251,\"t3ver_stage\":0,\"tstamp\":1762432251,\"uid\":11}',0,'0400$f117633a0757b61833a97b2eb8b3d3da:b70904b959c6d327947fc437df028f6f'),
(53,1762432251,1,'BE',1,0,12,'sys_file_reference','{\"sorting_foreign\":0,\"title\":null,\"description\":null,\"alternative\":null,\"autoplay\":0,\"hidden\":\"0\",\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"pid\":6,\"link\":\"\",\"crop\":\"{\\\"default\\\":{\\\"cropArea\\\":{\\\"x\\\":0,\\\"y\\\":0,\\\"width\\\":1,\\\"height\\\":1},\\\"selectedRatio\\\":\\\"NaN\\\",\\\"focusArea\\\":null}}\",\"uid_local\":\"8\",\"sys_language_uid\":0,\"crdate\":1762432251,\"t3ver_stage\":0,\"tstamp\":1762432251,\"uid\":12}',0,'0400$f117633a0757b61833a97b2eb8b3d3da:fef2cecc4ff45c64d73fc27195ee5748'),
(54,1762432859,2,'BE',1,0,8,'tt_content','{\"oldRecord\":{\"header\":\"\",\"l18n_diffsource\":\"\"},\"newRecord\":{\"header\":\"Sinisha L\\u00fcscher,  Zurich, Switzerland\",\"l18n_diffsource\":\"{\\\"CType\\\":\\\"\\\",\\\"categories\\\":\\\"\\\",\\\"colPos\\\":\\\"\\\",\\\"editlock\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"fe_group\\\":\\\"\\\",\\\"frame_class\\\":\\\"\\\",\\\"header\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"layout\\\":\\\"\\\",\\\"linkToTop\\\":\\\"\\\",\\\"rowDescription\\\":\\\"\\\",\\\"sectionIndex\\\":\\\"\\\",\\\"space_after_class\\\":\\\"\\\",\\\"space_before_class\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"tx_mask_images_for_this_case\\\":\\\"\\\"}\"}}',0,'0400$c55061463a4691135dee5badd9a855c7:2097d84972a039cb6bfe093b17089287'),
(55,1762432859,2,'BE',1,0,8,'sys_file_reference','{\"oldRecord\":{\"l10n_diffsource\":\"\"},\"newRecord\":{\"l10n_diffsource\":\"{\\\"hidden\\\":\\\"\\\"}\"}}',0,'0400$c55061463a4691135dee5badd9a855c7:5ff44a4f59fb3bfbe13a2c3ed1d0bd8b'),
(56,1762432859,2,'BE',1,0,9,'sys_file_reference','{\"oldRecord\":{\"l10n_diffsource\":\"\"},\"newRecord\":{\"l10n_diffsource\":\"{\\\"hidden\\\":\\\"\\\"}\"}}',0,'0400$c55061463a4691135dee5badd9a855c7:729356755eb8ee035abf6b9b02e20c8f'),
(57,1762432859,2,'BE',1,0,10,'sys_file_reference','{\"oldRecord\":{\"l10n_diffsource\":\"\"},\"newRecord\":{\"l10n_diffsource\":\"{\\\"hidden\\\":\\\"\\\"}\"}}',0,'0400$c55061463a4691135dee5badd9a855c7:b34a074e38840d41041eaee66c42bb0d'),
(58,1762432859,2,'BE',1,0,11,'sys_file_reference','{\"oldRecord\":{\"l10n_diffsource\":\"\"},\"newRecord\":{\"l10n_diffsource\":\"{\\\"hidden\\\":\\\"\\\"}\"}}',0,'0400$c55061463a4691135dee5badd9a855c7:b70904b959c6d327947fc437df028f6f'),
(59,1762432859,2,'BE',1,0,12,'sys_file_reference','{\"oldRecord\":{\"l10n_diffsource\":\"\"},\"newRecord\":{\"l10n_diffsource\":\"{\\\"hidden\\\":\\\"\\\"}\"}}',0,'0400$c55061463a4691135dee5badd9a855c7:fef2cecc4ff45c64d73fc27195ee5748'),
(60,1762432949,2,'BE',1,0,8,'tt_content','{\"oldRecord\":{\"header\":\"Sinisha L\\u00fcscher,  Zurich, Switzerland\",\"tx_mask_add_titiel_elo\":null,\"l18n_diffsource\":\"{\\\"CType\\\":\\\"\\\",\\\"categories\\\":\\\"\\\",\\\"colPos\\\":\\\"\\\",\\\"editlock\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"fe_group\\\":\\\"\\\",\\\"frame_class\\\":\\\"\\\",\\\"header\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"layout\\\":\\\"\\\",\\\"linkToTop\\\":\\\"\\\",\\\"rowDescription\\\":\\\"\\\",\\\"sectionIndex\\\":\\\"\\\",\\\"space_after_class\\\":\\\"\\\",\\\"space_before_class\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"tx_mask_images_for_this_case\\\":\\\"\\\"}\"},\"newRecord\":{\"header\":\"Sinisha L\\u00fcscher\",\"tx_mask_add_titiel_elo\":\"<p>Sinisha L\\u00fcscher, &nbsp;<br \\/>Zurich, Switzerland<\\/p>\",\"l18n_diffsource\":\"{\\\"CType\\\":\\\"\\\",\\\"categories\\\":\\\"\\\",\\\"colPos\\\":\\\"\\\",\\\"editlock\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"fe_group\\\":\\\"\\\",\\\"frame_class\\\":\\\"\\\",\\\"header\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"layout\\\":\\\"\\\",\\\"linkToTop\\\":\\\"\\\",\\\"rowDescription\\\":\\\"\\\",\\\"sectionIndex\\\":\\\"\\\",\\\"space_after_class\\\":\\\"\\\",\\\"space_before_class\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"tx_mask_add_titiel_elo\\\":\\\"\\\",\\\"tx_mask_images_for_this_case\\\":\\\"\\\"}\"}}',0,'0400$c9cc704f7c2e590dd1e6d06c1d74afc3:2097d84972a039cb6bfe093b17089287'),
(61,1762434972,2,'BE',1,0,7,'tt_content','{\"oldRecord\":{\"l18n_diffsource\":\"\"},\"newRecord\":{\"l18n_diffsource\":\"{\\\"CType\\\":\\\"\\\",\\\"categories\\\":\\\"\\\",\\\"colPos\\\":\\\"\\\",\\\"editlock\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"fe_group\\\":\\\"\\\",\\\"frame_class\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"layout\\\":\\\"\\\",\\\"linkToTop\\\":\\\"\\\",\\\"rowDescription\\\":\\\"\\\",\\\"sectionIndex\\\":\\\"\\\",\\\"space_after_class\\\":\\\"\\\",\\\"space_before_class\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"tx_mask_all_cases\\\":\\\"\\\"}\"}}',0,'0400$202c516274147b307f186a837f5844ac:ea41b626baac59a1fe0716bc344af5d9'),
(62,1762434972,1,'BE',1,0,1,'tx_mask_all_cases','{\"l10n_parent\":0,\"starttime\":0,\"endtime\":0,\"parentid\":0,\"tx_mask_catgeory\":\"0\",\"pid\":2,\"sorting\":256,\"tx_mask_text_on_image\":\"\",\"tx_mask_link_for_image\":\"\",\"sys_language_uid\":0,\"hidden\":\"0\",\"fe_group\":\"\",\"editlock\":\"0\",\"l10n_diffsource\":\"{\\\"editlock\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"fe_group\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"parentid\\\":\\\"\\\",\\\"sorting\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"tx_mask_catgeory\\\":\\\"\\\",\\\"tx_mask_link_for_image\\\":\\\"\\\",\\\"tx_mask_photo_case\\\":\\\"\\\",\\\"tx_mask_text_on_image\\\":\\\"\\\"}\",\"crdate\":1762434972,\"t3ver_stage\":0,\"tstamp\":1762434972,\"uid\":1}',0,'0400$202c516274147b307f186a837f5844ac:4fa71a4e6ba5191b078d49ee5e775d3a'),
(63,1762434972,1,'BE',1,0,13,'sys_file_reference','{\"sorting_foreign\":0,\"title\":null,\"description\":null,\"alternative\":null,\"autoplay\":0,\"hidden\":\"0\",\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"pid\":2,\"link\":\"\",\"crop\":\"{\\\"default\\\":{\\\"cropArea\\\":{\\\"x\\\":0,\\\"y\\\":0,\\\"width\\\":1,\\\"height\\\":1},\\\"selectedRatio\\\":\\\"NaN\\\",\\\"focusArea\\\":null}}\",\"uid_local\":\"8\",\"sys_language_uid\":0,\"crdate\":1762434972,\"t3ver_stage\":0,\"tstamp\":1762434972,\"uid\":13}',0,'0400$202c516274147b307f186a837f5844ac:5e1f4fea56ad8d21a419f2b59b059abf'),
(64,1762434972,2,'BE',1,0,7,'tt_content','{\"oldRecord\":{\"l18n_diffsource\":\"\"},\"newRecord\":{\"l18n_diffsource\":\"{\\\"CType\\\":\\\"\\\",\\\"categories\\\":\\\"\\\",\\\"colPos\\\":\\\"\\\",\\\"editlock\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"fe_group\\\":\\\"\\\",\\\"frame_class\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"layout\\\":\\\"\\\",\\\"linkToTop\\\":\\\"\\\",\\\"rowDescription\\\":\\\"\\\",\\\"sectionIndex\\\":\\\"\\\",\\\"space_after_class\\\":\\\"\\\",\\\"space_before_class\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"tx_mask_all_cases\\\":\\\"\\\"}\"}}',0,'0400$202c516274147b307f186a837f5844ac:ea41b626baac59a1fe0716bc344af5d9'),
(65,1762435002,2,'BE',1,0,1,'tx_mask_all_cases','{\"oldRecord\":{\"tx_mask_text_on_image\":\"\",\"l10n_diffsource\":\"{\\\"editlock\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"fe_group\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"parentid\\\":\\\"\\\",\\\"sorting\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"tx_mask_catgeory\\\":\\\"\\\",\\\"tx_mask_link_for_image\\\":\\\"\\\",\\\"tx_mask_photo_case\\\":\\\"\\\",\\\"tx_mask_text_on_image\\\":\\\"\\\"}\"},\"newRecord\":{\"tx_mask_text_on_image\":\"<p>Sinisha L\\u00fcscher, &nbsp;<br \\/>Zurich, Switzerland<\\/p>\",\"l10n_diffsource\":\"{\\\"editlock\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"fe_group\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"tx_mask_catgeory\\\":\\\"\\\",\\\"tx_mask_link_for_image\\\":\\\"\\\",\\\"tx_mask_photo_case\\\":\\\"\\\",\\\"tx_mask_text_on_image\\\":\\\"\\\"}\"}}',0,'0400$a2551a419b37f37df9e1027414f5c24d:4fa71a4e6ba5191b078d49ee5e775d3a'),
(66,1762435002,2,'BE',1,0,13,'sys_file_reference','{\"oldRecord\":{\"l10n_diffsource\":\"\"},\"newRecord\":{\"l10n_diffsource\":\"{\\\"alternative\\\":\\\"\\\",\\\"crop\\\":\\\"\\\",\\\"description\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"link\\\":\\\"\\\",\\\"title\\\":\\\"\\\",\\\"uid_local\\\":\\\"\\\"}\"}}',0,'0400$a2551a419b37f37df9e1027414f5c24d:5e1f4fea56ad8d21a419f2b59b059abf'),
(67,1762435207,2,'BE',1,0,1,'tx_mask_all_cases','{\"oldRecord\":{\"tx_mask_link_for_image\":\"\"},\"newRecord\":{\"tx_mask_link_for_image\":\"t3:\\/\\/page?uid=6\"}}',0,'0400$dcf7e048c459d4d95c1ec063486ce030:4fa71a4e6ba5191b078d49ee5e775d3a'),
(68,1762435256,1,'BE',1,0,1,'sys_category','{\"parent\":0,\"hidden\":\"0\",\"starttime\":0,\"endtime\":0,\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"pid\":2,\"sorting\":256,\"title\":\"Alle\",\"items\":\"0\",\"sys_language_uid\":0,\"description\":\"\",\"crdate\":1762435256,\"t3ver_stage\":0,\"tstamp\":1762435256,\"uid\":1}',0,'0400$2753e61f00a184cb292b56120cdfa57c:c6c8e24453121a7d668fe4b1031ebf88'),
(69,1762435264,1,'BE',1,0,2,'sys_category','{\"parent\":0,\"hidden\":\"0\",\"starttime\":0,\"endtime\":0,\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"pid\":2,\"sorting\":512,\"title\":\"Architektur\",\"items\":\"0\",\"sys_language_uid\":0,\"description\":\"\",\"crdate\":1762435264,\"t3ver_stage\":0,\"tstamp\":1762435264,\"uid\":2}',0,'0400$1fa062924ea4f45ae61ef30426197d90:497028e4af2a2cda8419e90cde34f71b'),
(70,1762435267,2,'BE',1,0,2,'sys_category','{\"oldRecord\":{\"title\":\"Architektur\",\"l10n_diffsource\":\"\"},\"newRecord\":{\"title\":\"Stories\",\"l10n_diffsource\":\"{\\\"description\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"items\\\":\\\"\\\",\\\"parent\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"title\\\":\\\"\\\"}\"}}',0,'0400$7cb8603ae5fcafd41a93092781a5b47f:497028e4af2a2cda8419e90cde34f71b'),
(71,1762435277,2,'BE',1,0,2,'sys_category','{\"oldRecord\":{\"title\":\"Stories\"},\"newRecord\":{\"title\":\"Portraits\"}}',0,'0400$39df8b92b163447bf98620e85e6d056c:497028e4af2a2cda8419e90cde34f71b'),
(72,1762435299,2,'BE',1,0,2,'sys_category','{\"oldRecord\":{\"title\":\"Portraits\"},\"newRecord\":{\"title\":\"Architektur\"}}',0,'0400$1f04937cf5eba2988d1d8514d1053ce1:497028e4af2a2cda8419e90cde34f71b'),
(73,1762435305,1,'BE',1,0,3,'sys_category','{\"parent\":0,\"hidden\":\"0\",\"starttime\":0,\"endtime\":0,\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"pid\":2,\"sorting\":768,\"title\":\"Stories\",\"items\":\"0\",\"sys_language_uid\":0,\"description\":\"\",\"crdate\":1762435305,\"t3ver_stage\":0,\"tstamp\":1762435305,\"uid\":3}',0,'0400$64e23c3fbfda28cf0d4af6f3037d0188:265912e2a2dda6b4b6be4e7069754d09'),
(74,1762435308,1,'BE',1,0,4,'sys_category','{\"parent\":0,\"hidden\":\"0\",\"starttime\":0,\"endtime\":0,\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"pid\":2,\"sorting\":1024,\"title\":\"Portraits\",\"items\":\"0\",\"sys_language_uid\":0,\"description\":\"\",\"crdate\":1762435308,\"t3ver_stage\":0,\"tstamp\":1762435308,\"uid\":4}',0,'0400$b846c4f4b1156ccb10cb46f64b24fcbb:a832991055f9726888b6b83414d05630'),
(75,1762435332,2,'BE',1,0,1,'tx_mask_all_cases','{\"oldRecord\":{\"tx_mask_catgeory\":\"\"},\"newRecord\":{\"tx_mask_catgeory\":\"2\"}}',0,'0400$6b60d045e1bab73a39b2b3b662d9119d:4fa71a4e6ba5191b078d49ee5e775d3a'),
(76,1762435332,2,'BE',1,0,13,'sys_file_reference','{\"oldRecord\":{\"l10n_diffsource\":\"{\\\"alternative\\\":\\\"\\\",\\\"crop\\\":\\\"\\\",\\\"description\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"link\\\":\\\"\\\",\\\"title\\\":\\\"\\\",\\\"uid_local\\\":\\\"\\\"}\"},\"newRecord\":{\"l10n_diffsource\":\"{\\\"hidden\\\":\\\"\\\"}\"}}',0,'0400$6b60d045e1bab73a39b2b3b662d9119d:5e1f4fea56ad8d21a419f2b59b059abf'),
(77,1762437321,1,'BE',1,0,2,'tx_mask_all_cases','{\"l10n_parent\":0,\"starttime\":0,\"endtime\":0,\"parentid\":0,\"tx_mask_catgeory\":\"1\",\"pid\":2,\"sorting\":0,\"tx_mask_text_on_image\":\"<p>Sinisha L\\u00fcscher, &nbsp;<br \\/>Zurich, Switzerland<\\/p>\",\"tx_mask_link_for_image\":\"t3:\\/\\/page?uid=6\",\"sys_language_uid\":0,\"hidden\":\"0\",\"fe_group\":\"\",\"editlock\":\"0\",\"l10n_diffsource\":\"{\\\"editlock\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"fe_group\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"parentid\\\":\\\"\\\",\\\"sorting\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"tx_mask_catgeory\\\":\\\"\\\",\\\"tx_mask_link_for_image\\\":\\\"\\\",\\\"tx_mask_photo_case\\\":\\\"\\\",\\\"tx_mask_text_on_image\\\":\\\"\\\"}\",\"crdate\":1762437321,\"t3ver_stage\":0,\"tstamp\":1762437321,\"uid\":2}',0,'0400$59a6111a6347e09bd49a53190ef2ac4a:5e4c21dcb0299f635533788b0d9698d2'),
(78,1762437321,1,'BE',1,0,14,'sys_file_reference','{\"sorting_foreign\":0,\"title\":null,\"description\":null,\"alternative\":null,\"autoplay\":0,\"hidden\":\"0\",\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"pid\":2,\"link\":\"\",\"crop\":\"{\\\"default\\\":{\\\"cropArea\\\":{\\\"x\\\":0,\\\"y\\\":0,\\\"width\\\":1,\\\"height\\\":1},\\\"selectedRatio\\\":\\\"NaN\\\",\\\"focusArea\\\":null}}\",\"uid_local\":\"5\",\"sys_language_uid\":0,\"crdate\":1762437321,\"t3ver_stage\":0,\"tstamp\":1762437321,\"uid\":14}',0,'0400$59a6111a6347e09bd49a53190ef2ac4a:2207c2b650522ebf0efd90eaad3962af'),
(79,1762437355,2,'BE',1,0,1,'tx_mask_all_cases','{\"oldRecord\":{\"l10n_diffsource\":\"{\\\"editlock\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"fe_group\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"tx_mask_catgeory\\\":\\\"\\\",\\\"tx_mask_link_for_image\\\":\\\"\\\",\\\"tx_mask_photo_case\\\":\\\"\\\",\\\"tx_mask_text_on_image\\\":\\\"\\\"}\"},\"newRecord\":{\"l10n_diffsource\":\"{\\\"hidden\\\":\\\"\\\"}\"}}',0,'0400$585d88356fee8ce3eab72d4907898353:4fa71a4e6ba5191b078d49ee5e775d3a'),
(80,1762437355,2,'BE',1,0,2,'tx_mask_all_cases','{\"oldRecord\":{\"l10n_diffsource\":\"{\\\"editlock\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"fe_group\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"parentid\\\":\\\"\\\",\\\"sorting\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"tx_mask_catgeory\\\":\\\"\\\",\\\"tx_mask_link_for_image\\\":\\\"\\\",\\\"tx_mask_photo_case\\\":\\\"\\\",\\\"tx_mask_text_on_image\\\":\\\"\\\"}\"},\"newRecord\":{\"l10n_diffsource\":\"{\\\"editlock\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"fe_group\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"tx_mask_catgeory\\\":\\\"\\\",\\\"tx_mask_link_for_image\\\":\\\"\\\",\\\"tx_mask_photo_case\\\":\\\"\\\",\\\"tx_mask_text_on_image\\\":\\\"\\\"}\"}}',0,'0400$585d88356fee8ce3eab72d4907898353:5e4c21dcb0299f635533788b0d9698d2'),
(81,1762437355,1,'BE',1,0,3,'tx_mask_all_cases','{\"l10n_parent\":0,\"starttime\":0,\"endtime\":0,\"parentid\":0,\"tx_mask_catgeory\":\"1\",\"pid\":2,\"sorting\":0,\"tx_mask_text_on_image\":\"<p>Sinisha L\\u00fcscher, &nbsp;<br \\/>Zurich, Switzerland<\\/p>\",\"tx_mask_link_for_image\":\"t3:\\/\\/page?uid=6\",\"sys_language_uid\":0,\"hidden\":\"0\",\"fe_group\":\"\",\"editlock\":\"0\",\"l10n_diffsource\":\"{\\\"editlock\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"fe_group\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"parentid\\\":\\\"\\\",\\\"sorting\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"tx_mask_catgeory\\\":\\\"\\\",\\\"tx_mask_link_for_image\\\":\\\"\\\",\\\"tx_mask_photo_case\\\":\\\"\\\",\\\"tx_mask_text_on_image\\\":\\\"\\\"}\",\"crdate\":1762437355,\"t3ver_stage\":0,\"tstamp\":1762437355,\"uid\":3}',0,'0400$585d88356fee8ce3eab72d4907898353:373afe1c25802cd9bcc3081fb735e1d1'),
(82,1762437355,2,'BE',1,0,14,'sys_file_reference','{\"oldRecord\":{\"l10n_diffsource\":\"\"},\"newRecord\":{\"l10n_diffsource\":\"{\\\"alternative\\\":\\\"\\\",\\\"crop\\\":\\\"\\\",\\\"description\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"link\\\":\\\"\\\",\\\"title\\\":\\\"\\\",\\\"uid_local\\\":\\\"\\\"}\"}}',0,'0400$585d88356fee8ce3eab72d4907898353:2207c2b650522ebf0efd90eaad3962af'),
(83,1762437355,1,'BE',1,0,15,'sys_file_reference','{\"sorting_foreign\":0,\"title\":null,\"description\":null,\"alternative\":null,\"autoplay\":0,\"hidden\":\"0\",\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"pid\":2,\"link\":\"\",\"crop\":\"{\\\"default\\\":{\\\"cropArea\\\":{\\\"x\\\":0,\\\"y\\\":0,\\\"width\\\":1,\\\"height\\\":1},\\\"selectedRatio\\\":\\\"NaN\\\",\\\"focusArea\\\":null}}\",\"uid_local\":\"6\",\"sys_language_uid\":0,\"crdate\":1762437355,\"t3ver_stage\":0,\"tstamp\":1762437355,\"uid\":15}',0,'0400$585d88356fee8ce3eab72d4907898353:53cbb769126fb106e07a09de5e196b60'),
(84,1762437772,2,'BE',1,0,2,'tx_mask_all_cases','{\"oldRecord\":{\"l10n_diffsource\":\"{\\\"editlock\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"fe_group\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"tx_mask_catgeory\\\":\\\"\\\",\\\"tx_mask_link_for_image\\\":\\\"\\\",\\\"tx_mask_photo_case\\\":\\\"\\\",\\\"tx_mask_text_on_image\\\":\\\"\\\"}\"},\"newRecord\":{\"l10n_diffsource\":\"{\\\"hidden\\\":\\\"\\\"}\"}}',0,'0400$0c2d73eeaf71bcc025dced8260b56195:5e4c21dcb0299f635533788b0d9698d2'),
(85,1762437772,2,'BE',1,0,3,'tx_mask_all_cases','{\"oldRecord\":{\"l10n_diffsource\":\"{\\\"editlock\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"fe_group\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"parentid\\\":\\\"\\\",\\\"sorting\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"tx_mask_catgeory\\\":\\\"\\\",\\\"tx_mask_link_for_image\\\":\\\"\\\",\\\"tx_mask_photo_case\\\":\\\"\\\",\\\"tx_mask_text_on_image\\\":\\\"\\\"}\"},\"newRecord\":{\"l10n_diffsource\":\"{\\\"editlock\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"fe_group\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"tx_mask_catgeory\\\":\\\"\\\",\\\"tx_mask_link_for_image\\\":\\\"\\\",\\\"tx_mask_photo_case\\\":\\\"\\\",\\\"tx_mask_text_on_image\\\":\\\"\\\"}\"}}',0,'0400$0c2d73eeaf71bcc025dced8260b56195:373afe1c25802cd9bcc3081fb735e1d1'),
(86,1762437772,1,'BE',1,0,4,'tx_mask_all_cases','{\"l10n_parent\":0,\"starttime\":0,\"endtime\":0,\"parentid\":0,\"tx_mask_catgeory\":\"1\",\"pid\":2,\"sorting\":0,\"tx_mask_text_on_image\":\"<p>Sinisha L\\u00fcscher, &nbsp;<br \\/>Zurich, Switzerland<\\/p>\",\"tx_mask_link_for_image\":\"t3:\\/\\/page?uid=6\",\"sys_language_uid\":0,\"hidden\":\"0\",\"fe_group\":\"\",\"editlock\":\"0\",\"l10n_diffsource\":\"{\\\"editlock\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"fe_group\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"parentid\\\":\\\"\\\",\\\"sorting\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"tx_mask_catgeory\\\":\\\"\\\",\\\"tx_mask_link_for_image\\\":\\\"\\\",\\\"tx_mask_photo_case\\\":\\\"\\\",\\\"tx_mask_text_on_image\\\":\\\"\\\"}\",\"crdate\":1762437772,\"t3ver_stage\":0,\"tstamp\":1762437772,\"uid\":4}',0,'0400$0c2d73eeaf71bcc025dced8260b56195:db32ed038695c68e1679a42c52e4d454'),
(87,1762437772,2,'BE',1,0,15,'sys_file_reference','{\"oldRecord\":{\"l10n_diffsource\":\"\"},\"newRecord\":{\"l10n_diffsource\":\"{\\\"alternative\\\":\\\"\\\",\\\"crop\\\":\\\"\\\",\\\"description\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"link\\\":\\\"\\\",\\\"title\\\":\\\"\\\",\\\"uid_local\\\":\\\"\\\"}\"}}',0,'0400$0c2d73eeaf71bcc025dced8260b56195:53cbb769126fb106e07a09de5e196b60'),
(88,1762437772,1,'BE',1,0,16,'sys_file_reference','{\"sorting_foreign\":0,\"title\":null,\"description\":null,\"alternative\":null,\"autoplay\":0,\"hidden\":\"0\",\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"pid\":2,\"link\":\"\",\"crop\":\"{\\\"default\\\":{\\\"cropArea\\\":{\\\"x\\\":0,\\\"y\\\":0,\\\"width\\\":1,\\\"height\\\":1},\\\"selectedRatio\\\":\\\"NaN\\\",\\\"focusArea\\\":null}}\",\"uid_local\":\"7\",\"sys_language_uid\":0,\"crdate\":1762437772,\"t3ver_stage\":0,\"tstamp\":1762437772,\"uid\":16}',0,'0400$0c2d73eeaf71bcc025dced8260b56195:5a9ade48273ee95d803333aed1c78820'),
(89,1762439342,2,'BE',1,0,4,'tx_mask_all_cases','{\"oldRecord\":{\"l10n_diffsource\":\"{\\\"editlock\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"fe_group\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"parentid\\\":\\\"\\\",\\\"sorting\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"tx_mask_catgeory\\\":\\\"\\\",\\\"tx_mask_link_for_image\\\":\\\"\\\",\\\"tx_mask_photo_case\\\":\\\"\\\",\\\"tx_mask_text_on_image\\\":\\\"\\\"}\"},\"newRecord\":{\"l10n_diffsource\":\"{\\\"editlock\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"fe_group\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"tx_mask_catgeory\\\":\\\"\\\",\\\"tx_mask_link_for_image\\\":\\\"\\\",\\\"tx_mask_photo_case\\\":\\\"\\\",\\\"tx_mask_text_on_image\\\":\\\"\\\"}\"}}',0,'0400$ce11da49bc6469cda4e14ec374234ed2:db32ed038695c68e1679a42c52e4d454'),
(90,1762439342,1,'BE',1,0,5,'tx_mask_all_cases','{\"l10n_parent\":0,\"starttime\":0,\"endtime\":0,\"parentid\":0,\"tx_mask_catgeory\":\"1\",\"pid\":2,\"sorting\":0,\"tx_mask_text_on_image\":\"<pre>Sinisha L\\u00fcscher,  <br>Zurich, Switzerland<\\/pre>\",\"tx_mask_link_for_image\":\"t3:\\/\\/page?uid=6\",\"sys_language_uid\":0,\"hidden\":\"0\",\"fe_group\":\"\",\"editlock\":\"0\",\"l10n_diffsource\":\"{\\\"editlock\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"fe_group\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"parentid\\\":\\\"\\\",\\\"sorting\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"tx_mask_catgeory\\\":\\\"\\\",\\\"tx_mask_link_for_image\\\":\\\"\\\",\\\"tx_mask_photo_case\\\":\\\"\\\",\\\"tx_mask_text_on_image\\\":\\\"\\\"}\",\"crdate\":1762439342,\"t3ver_stage\":0,\"tstamp\":1762439342,\"uid\":5}',0,'0400$ce11da49bc6469cda4e14ec374234ed2:5427a181333452b34b5611ea1907562c'),
(91,1762439342,2,'BE',1,0,16,'sys_file_reference','{\"oldRecord\":{\"l10n_diffsource\":\"\"},\"newRecord\":{\"l10n_diffsource\":\"{\\\"alternative\\\":\\\"\\\",\\\"crop\\\":\\\"\\\",\\\"description\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"link\\\":\\\"\\\",\\\"title\\\":\\\"\\\",\\\"uid_local\\\":\\\"\\\"}\"}}',0,'0400$ce11da49bc6469cda4e14ec374234ed2:5a9ade48273ee95d803333aed1c78820'),
(92,1762439342,1,'BE',1,0,17,'sys_file_reference','{\"sorting_foreign\":0,\"title\":null,\"description\":null,\"alternative\":null,\"autoplay\":0,\"hidden\":\"0\",\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"pid\":2,\"link\":\"\",\"crop\":\"{\\\"default\\\":{\\\"cropArea\\\":{\\\"x\\\":0,\\\"y\\\":0,\\\"width\\\":1,\\\"height\\\":1},\\\"selectedRatio\\\":\\\"NaN\\\",\\\"focusArea\\\":null}}\",\"uid_local\":\"7\",\"sys_language_uid\":0,\"crdate\":1762439342,\"t3ver_stage\":0,\"tstamp\":1762439342,\"uid\":17}',0,'0400$ce11da49bc6469cda4e14ec374234ed2:78ba90db28917b77e8d54ca398316d0e'),
(93,1762440507,2,'BE',1,0,5,'tx_mask_all_cases','{\"oldRecord\":{\"tx_mask_text_on_image\":\"<pre>Sinisha L\\u00fcscher,  <br>Zurich, Switzerland<\\/pre>\",\"l10n_diffsource\":\"{\\\"editlock\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"fe_group\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"parentid\\\":\\\"\\\",\\\"sorting\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"tx_mask_catgeory\\\":\\\"\\\",\\\"tx_mask_link_for_image\\\":\\\"\\\",\\\"tx_mask_photo_case\\\":\\\"\\\",\\\"tx_mask_text_on_image\\\":\\\"\\\"}\"},\"newRecord\":{\"tx_mask_text_on_image\":\"<p>Sinisha L\\u00fcscher,&nbsp;<br \\/>Zurich, Switzerland<\\/p>\",\"l10n_diffsource\":\"{\\\"editlock\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"fe_group\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"tx_mask_catgeory\\\":\\\"\\\",\\\"tx_mask_link_for_image\\\":\\\"\\\",\\\"tx_mask_photo_case\\\":\\\"\\\",\\\"tx_mask_text_on_image\\\":\\\"\\\"}\"}}',0,'0400$069b7290829d4c8d3975d8b4ec38cfdb:5427a181333452b34b5611ea1907562c'),
(94,1762440507,2,'BE',1,0,17,'sys_file_reference','{\"oldRecord\":{\"l10n_diffsource\":\"\"},\"newRecord\":{\"l10n_diffsource\":\"{\\\"alternative\\\":\\\"\\\",\\\"crop\\\":\\\"\\\",\\\"description\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"link\\\":\\\"\\\",\\\"title\\\":\\\"\\\",\\\"uid_local\\\":\\\"\\\"}\"}}',0,'0400$069b7290829d4c8d3975d8b4ec38cfdb:78ba90db28917b77e8d54ca398316d0e'),
(95,1762441921,1,'BE',1,0,9,'tt_content','{\"CType\":\"mask_info\",\"categories\":\"0\",\"layout\":\"0\",\"frame_class\":\"default\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"colPos\":\"0\",\"date\":0,\"header_layout\":\"0\",\"header_position\":\"\",\"imagewidth\":0,\"imageheight\":0,\"imageorient\":\"0\",\"imagecols\":\"2\",\"recursive\":\"0\",\"list_type\":\"\",\"sectionIndex\":\"1\",\"hidden\":\"0\",\"starttime\":0,\"endtime\":0,\"sys_language_uid\":0,\"l18n_parent\":0,\"l18n_diffsource\":\"\",\"bullets_type\":\"0\",\"cols\":\"0\",\"table_class\":\"\",\"table_delimiter\":\"124\",\"table_enclosure\":\"0\",\"table_header_position\":\"0\",\"table_tfoot\":0,\"target\":\"\",\"uploads_description\":0,\"uploads_type\":\"0\",\"pid\":3,\"sorting\":256,\"header\":\"Info \\u2013 nur informativ\",\"tx_mask_text_info\":\"<p>Raffael Waldner, geboren in Basel mit jenischen Wurzeln, studierte Fotografie in Leipzig und Z\\u00fcrich. Seine Arbeiten wurden weltweit in zahlreichen Ausstellungen gezeigt. Er war Teil des Projekts \\u00abRegeneration 50 Photographers of Tomorrow\\u00bb und hat mehrere B\\u00fccher ver\\u00f6ffentlicht. Fasziniert von der Fotografie an der Schnittstelle zwischen Kunst und Dokumentation, interessiert er sich f\\u00fcr die Untersuchung von Lebensbedingungen, Orten und Alltagsgegen- st\\u00e4nden und den Werten, die sie vermitteln. Er konzentriert sich auf seine pers\\u00f6nlichen Arbeiten und Auftr\\u00e4ge f\\u00fcr Unternehmens-, Industrie-, Redaktions- und Portr\\u00e4tkunden in der Schweiz und im Ausland und unterrichtet Fotografie an der HKB, Hochschule der K\\u00fcnste Bern und der F+F, Schule f\\u00fcr Kunst und Design Z\\u00fcrich. Raffael Waldner ist Mitinhaber der Agentur 13Photo in Z\\u00fcrich, heute die gr\\u00f6sste Foto- grafenagentur der Schweiz mit \\u00fcber 50 Mitgliedern.&nbsp;<\\/p>\\r\\n<p>Raffael Waldners Fotografie ist ein Dialog zwischen Distanz und N\\u00e4he. Waldner beobachtet mit k\\u00fchler Klarheit und zugleich feiner Empathie. Seine Portr\\u00e4ts, Architekturen und Stories sind nie zuf\\u00e4llig \\u2013 sie sind sorgf\\u00e4ltig komponierte Beobachtungen \\u00fcber Menschen, R\\u00e4ume und Strukturen. In seiner Bildwelt herrscht ein kontrolliertes Licht, eine klare Ordnung und eine sp\\u00fcrbare Ruhe. Doch unter dieser Oberfl\\u00e4che liegt Bewegung \\u2013 Ironie, Verletzlichkeit, Kraft. Waldner zeigt das Unspektakul\\u00e4re mit W\\u00fcrde, das Gew\\u00f6hnliche mit Bedeutung. Seine Arbeiten sind visuelle Analysen des Alltags, pr\\u00e4zise, eigenwillig und voller Haltung. Sie sprechen die Sprache von Authentizit\\u00e4t, Intelligenz und visueller Eleganz \\u2013 ohne Pathos, aber mit Tiefe. Analytisch. Still. Direkt. Fotografie als Spiegel gesell-schaftlicher Wirklichkeit \\u2013 reduziert, menschlich, zeitlos.<\\/p>\",\"tx_mask_clients_first_colum\":\"<p>ADACMagazin<br \\/>Annabelle<br \\/>Beobachter<br \\/>BeobachterNatur<br \\/>Bergwelten<br \\/>Bilanz<br \\/>Bloomberg<br \\/>Brigitte<br \\/>DasMagazin<br \\/>DU<br \\/>DieZeit<br \\/>Focus<br \\/>FreemansWorld<br \\/>FritzundFr\\u00e4nzi<br \\/>Handelszeitung<br \\/>Hochparterre<br \\/>Liberation<br \\/>MillionaireMagazin<br \\/>MMagazin<br \\/>NZZ<br \\/>NZZFolio<br \\/>NZZamSonntag<br \\/>NZZGeschichte<br \\/>Saisonk\\u00fcche<br \\/>SchweizerFamilie<br \\/>SISport<br \\/>SonntagsZeitung<br \\/>Spiegel<br \\/>Stern<br \\/>Tages-Anzeiger<br \\/>VIA<br \\/>Vivai<br \\/>Weltwoche<br \\/>ZeitMagazin<br \\/>Z-Magazin<\\/p>\",\"tx_mask_clienst_second_col\":\"<p>AVAAargauVerkehr<br \\/>AXA<br \\/>BernExpo<br \\/>BeyerChronometrie<br \\/>BernerFachhochschule<br \\/>Blausee<br \\/>Buhlergroup<br \\/>Bundesamtf\\u00fcrUmwelt<br \\/>Burgerspital<br \\/>Comet<br \\/>Crafft<br \\/>CreditSuisse<br \\/>Designsensor<br \\/>Dr.MeyerImmobilien<br \\/>E+AKaufmann<br \\/>Elektra<br \\/>GCAAltium<br \\/>Infel<br \\/>Isolutions<br \\/>Kitchener<br \\/>Marrazzi<br \\/>Metaphor<br \\/>Migros-Genossenschafts-<br \\/>Bund<br \\/>NewID<br \\/>NobelBiocare<br \\/>Primafila<br \\/>Republica<br \\/>Saurer<br \\/>SBB<br \\/>SGE<br \\/>Siegfried<br \\/>Spillmann\\/Felser\\/LeoBurnett<br \\/>Stoppani<br \\/>Sturm&amp;Br\\u00e4m<br \\/>Suva<br \\/>Swissbanking<br \\/>Unibasel<\\/p>\",\"linkToTop\":\"0\",\"fe_group\":\"\",\"editlock\":\"0\",\"rowDescription\":\"\",\"crdate\":1762441921,\"t3ver_stage\":0,\"tstamp\":1762441921,\"uid\":9}',0,'0400$6f4a147f63f096173c7f323f6b46aadb:367f4f227870d8e2a11496a182574aa3'),
(96,1762441921,1,'BE',1,0,18,'sys_file_reference','{\"sorting_foreign\":0,\"title\":null,\"description\":null,\"alternative\":null,\"autoplay\":0,\"hidden\":\"0\",\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"pid\":3,\"link\":\"\",\"crop\":\"{\\\"default\\\":{\\\"cropArea\\\":{\\\"x\\\":0,\\\"y\\\":0,\\\"width\\\":1,\\\"height\\\":1},\\\"selectedRatio\\\":\\\"NaN\\\",\\\"focusArea\\\":null}}\",\"uid_local\":\"9\",\"sys_language_uid\":0,\"crdate\":1762441921,\"t3ver_stage\":0,\"tstamp\":1762441921,\"uid\":18}',0,'0400$6f4a147f63f096173c7f323f6b46aadb:c9d27ac33ea45c5163a9ef7a25d8e7c7'),
(97,1762442309,2,'BE',1,0,9,'tt_content','{\"oldRecord\":{\"tx_mask_text_info\":\"<p>Raffael Waldner, geboren in Basel mit jenischen Wurzeln, studierte Fotografie in Leipzig und Z\\u00fcrich. Seine Arbeiten wurden weltweit in zahlreichen Ausstellungen gezeigt. Er war Teil des Projekts \\u00abRegeneration 50 Photographers of Tomorrow\\u00bb und hat mehrere B\\u00fccher ver\\u00f6ffentlicht. Fasziniert von der Fotografie an der Schnittstelle zwischen Kunst und Dokumentation, interessiert er sich f\\u00fcr die Untersuchung von Lebensbedingungen, Orten und Alltagsgegen- st\\u00e4nden und den Werten, die sie vermitteln. Er konzentriert sich auf seine pers\\u00f6nlichen Arbeiten und Auftr\\u00e4ge f\\u00fcr Unternehmens-, Industrie-, Redaktions- und Portr\\u00e4tkunden in der Schweiz und im Ausland und unterrichtet Fotografie an der HKB, Hochschule der K\\u00fcnste Bern und der F+F, Schule f\\u00fcr Kunst und Design Z\\u00fcrich. Raffael Waldner ist Mitinhaber der Agentur 13Photo in Z\\u00fcrich, heute die gr\\u00f6sste Foto- grafenagentur der Schweiz mit \\u00fcber 50 Mitgliedern.&nbsp;<\\/p>\\r\\n<p>Raffael Waldners Fotografie ist ein Dialog zwischen Distanz und N\\u00e4he. Waldner beobachtet mit k\\u00fchler Klarheit und zugleich feiner Empathie. Seine Portr\\u00e4ts, Architekturen und Stories sind nie zuf\\u00e4llig \\u2013 sie sind sorgf\\u00e4ltig komponierte Beobachtungen \\u00fcber Menschen, R\\u00e4ume und Strukturen. In seiner Bildwelt herrscht ein kontrolliertes Licht, eine klare Ordnung und eine sp\\u00fcrbare Ruhe. Doch unter dieser Oberfl\\u00e4che liegt Bewegung \\u2013 Ironie, Verletzlichkeit, Kraft. Waldner zeigt das Unspektakul\\u00e4re mit W\\u00fcrde, das Gew\\u00f6hnliche mit Bedeutung. Seine Arbeiten sind visuelle Analysen des Alltags, pr\\u00e4zise, eigenwillig und voller Haltung. Sie sprechen die Sprache von Authentizit\\u00e4t, Intelligenz und visueller Eleganz \\u2013 ohne Pathos, aber mit Tiefe. Analytisch. Still. Direkt. Fotografie als Spiegel gesell-schaftlicher Wirklichkeit \\u2013 reduziert, menschlich, zeitlos.<\\/p>\",\"l18n_diffsource\":\"\"},\"newRecord\":{\"tx_mask_text_info\":\"<p>Raffael Waldner, geboren in Basel mit jenischen Wurzeln, studierte Fotografie in Leipzig und Z\\u00fcrich. Seine Arbeiten wurden weltweit in zahlreichen Ausstellungen gezeigt. Er war Teil des Projekts \\u00abRegeneration 50 Photographers of Tomorrow\\u00bb und hat mehrere B\\u00fccher ver\\u00f6ffentlicht. Fasziniert von der Fotografie an der Schnittstelle zwischen Kunst und Dokumentation, interessiert er sich f\\u00fcr die Untersuchung von Lebensbedingungen, Orten und Alltagsgegen- st\\u00e4nden und den Werten, die sie vermitteln. Er konzentriert sich auf seine pers\\u00f6nlichen Arbeiten und Auftr\\u00e4ge f\\u00fcr Unternehmens-, Industrie-, Redaktions- und Portr\\u00e4tkunden in der Schweiz und im Ausland und unterrichtet Fotografie an der HKB, Hochschule der K\\u00fcnste Bern und der F+F, Schule f\\u00fcr Kunst und Design Z\\u00fcrich. Raffael Waldner ist Mitinhaber der Agentur 13Photo in Z\\u00fcrich, heute die gr\\u00f6sste Foto- grafenagentur der Schweiz mit \\u00fcber 50 Mitgliedern.&nbsp;<\\/p>\\r\\n\\r\\n<p>Raffael Waldners Fotografie ist ein Dialog zwischen Distanz und N\\u00e4he. Waldner beobachtet mit k\\u00fchler Klarheit und zugleich feiner Empathie. Seine Portr\\u00e4ts, Architekturen und Stories sind nie zuf\\u00e4llig \\u2013 sie sind sorgf\\u00e4ltig komponierte Beobachtungen \\u00fcber Menschen, R\\u00e4ume und Strukturen. In seiner Bildwelt herrscht ein kontrolliertes Licht, eine klare Ordnung und eine sp\\u00fcrbare Ruhe. Doch unter dieser Oberfl\\u00e4che liegt Bewegung \\u2013 Ironie, Verletzlichkeit, Kraft. Waldner zeigt das Unspektakul\\u00e4re mit W\\u00fcrde, das Gew\\u00f6hnliche mit Bedeutung. Seine Arbeiten sind visuelle Analysen des Alltags, pr\\u00e4zise, eigenwillig und voller Haltung. Sie sprechen die Sprache von Authentizit\\u00e4t, Intelligenz und visueller Eleganz \\u2013 ohne Pathos, aber mit Tiefe. Analytisch. Still. Direkt. Fotografie als Spiegel gesell-schaftlicher Wirklichkeit \\u2013 reduziert, menschlich, zeitlos.<\\/p>\",\"l18n_diffsource\":\"{\\\"CType\\\":\\\"\\\",\\\"categories\\\":\\\"\\\",\\\"colPos\\\":\\\"\\\",\\\"editlock\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"fe_group\\\":\\\"\\\",\\\"frame_class\\\":\\\"\\\",\\\"header\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"layout\\\":\\\"\\\",\\\"linkToTop\\\":\\\"\\\",\\\"rowDescription\\\":\\\"\\\",\\\"sectionIndex\\\":\\\"\\\",\\\"space_after_class\\\":\\\"\\\",\\\"space_before_class\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"tx_mask_clienst_second_col\\\":\\\"\\\",\\\"tx_mask_clients_first_colum\\\":\\\"\\\",\\\"tx_mask_photo_info\\\":\\\"\\\",\\\"tx_mask_text_info\\\":\\\"\\\"}\"}}',0,'0400$c8b673da4511bdefef096c95eee855f6:367f4f227870d8e2a11496a182574aa3'),
(98,1762442309,2,'BE',1,0,18,'sys_file_reference','{\"oldRecord\":{\"l10n_diffsource\":\"\"},\"newRecord\":{\"l10n_diffsource\":\"{\\\"hidden\\\":\\\"\\\"}\"}}',0,'0400$c8b673da4511bdefef096c95eee855f6:c9d27ac33ea45c5163a9ef7a25d8e7c7'),
(99,1762442507,2,'BE',1,0,3,'tx_mask_all_cases','{\"oldRecord\":{\"l10n_diffsource\":\"{\\\"editlock\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"fe_group\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"tx_mask_catgeory\\\":\\\"\\\",\\\"tx_mask_link_for_image\\\":\\\"\\\",\\\"tx_mask_photo_case\\\":\\\"\\\",\\\"tx_mask_text_on_image\\\":\\\"\\\"}\"},\"newRecord\":{\"l10n_diffsource\":\"{\\\"hidden\\\":\\\"\\\"}\"}}',0,'0400$156b78df43e641ac67db7a4a2cd51684:373afe1c25802cd9bcc3081fb735e1d1'),
(100,1762442507,1,'BE',1,0,19,'sys_file_reference','{\"sorting_foreign\":0,\"title\":null,\"description\":null,\"alternative\":null,\"autoplay\":0,\"hidden\":\"0\",\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"pid\":2,\"link\":\"\",\"crop\":\"{\\\"default\\\":{\\\"cropArea\\\":{\\\"x\\\":0,\\\"y\\\":0,\\\"width\\\":1,\\\"height\\\":1},\\\"selectedRatio\\\":\\\"NaN\\\",\\\"focusArea\\\":null}}\",\"uid_local\":\"9\",\"sys_language_uid\":0,\"crdate\":1762442507,\"t3ver_stage\":0,\"tstamp\":1762442507,\"uid\":19}',0,'0400$156b78df43e641ac67db7a4a2cd51684:7008e0248119dc3a255a0170bf6e9370'),
(101,1762442507,4,'BE',1,0,17,'sys_file_reference',NULL,0,'0400$156b78df43e641ac67db7a4a2cd51684:78ba90db28917b77e8d54ca398316d0e'),
(102,1762442661,2,'BE',1,0,4,'tx_mask_all_cases','{\"oldRecord\":{\"l10n_diffsource\":\"{\\\"editlock\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"fe_group\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"tx_mask_catgeory\\\":\\\"\\\",\\\"tx_mask_link_for_image\\\":\\\"\\\",\\\"tx_mask_photo_case\\\":\\\"\\\",\\\"tx_mask_text_on_image\\\":\\\"\\\"}\"},\"newRecord\":{\"l10n_diffsource\":\"{\\\"hidden\\\":\\\"\\\"}\"}}',0,'0400$4cdc9e9f5ae9e1179a4e49e1508939b3:db32ed038695c68e1679a42c52e4d454'),
(103,1762442661,1,'BE',1,0,6,'tx_mask_all_cases','{\"l10n_parent\":0,\"starttime\":0,\"endtime\":0,\"parentid\":0,\"tx_mask_catgeory\":\"1\",\"pid\":2,\"sorting\":0,\"tx_mask_text_on_image\":\"<p>Sinisha L\\u00fcscher,&nbsp;<br \\/>Zurich, Switzerland<\\/p>\",\"tx_mask_link_for_image\":\"t3:\\/\\/page?uid=6\",\"sys_language_uid\":0,\"hidden\":\"0\",\"fe_group\":\"\",\"editlock\":\"0\",\"l10n_diffsource\":\"{\\\"editlock\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"fe_group\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"parentid\\\":\\\"\\\",\\\"sorting\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"tx_mask_catgeory\\\":\\\"\\\",\\\"tx_mask_link_for_image\\\":\\\"\\\",\\\"tx_mask_photo_case\\\":\\\"\\\",\\\"tx_mask_text_on_image\\\":\\\"\\\"}\",\"crdate\":1762442661,\"t3ver_stage\":0,\"tstamp\":1762442661,\"uid\":6}',0,'0400$4cdc9e9f5ae9e1179a4e49e1508939b3:81a0808a349cf0edad8bf12fbfb9d84e'),
(104,1762442661,2,'BE',1,0,19,'sys_file_reference','{\"oldRecord\":{\"l10n_diffsource\":\"\"},\"newRecord\":{\"l10n_diffsource\":\"{\\\"alternative\\\":\\\"\\\",\\\"crop\\\":\\\"\\\",\\\"description\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"link\\\":\\\"\\\",\\\"title\\\":\\\"\\\",\\\"uid_local\\\":\\\"\\\"}\"}}',0,'0400$4cdc9e9f5ae9e1179a4e49e1508939b3:7008e0248119dc3a255a0170bf6e9370'),
(105,1762442661,1,'BE',1,0,20,'sys_file_reference','{\"sorting_foreign\":0,\"title\":null,\"description\":null,\"alternative\":null,\"autoplay\":0,\"hidden\":\"0\",\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"pid\":2,\"link\":\"\",\"crop\":\"{\\\"default\\\":{\\\"cropArea\\\":{\\\"x\\\":0,\\\"y\\\":0,\\\"width\\\":1,\\\"height\\\":1},\\\"selectedRatio\\\":\\\"NaN\\\",\\\"focusArea\\\":null}}\",\"uid_local\":\"2\",\"sys_language_uid\":0,\"crdate\":1762442661,\"t3ver_stage\":0,\"tstamp\":1762442661,\"uid\":20}',0,'0400$4cdc9e9f5ae9e1179a4e49e1508939b3:97d0d1c7a42cd9603b2010379c1e4e4d'),
(106,1762442745,2,'BE',1,0,1,'tx_mask_all_cases','{\"oldRecord\":{\"l10n_diffsource\":\"{\\\"hidden\\\":\\\"\\\"}\"},\"newRecord\":{\"l10n_diffsource\":\"{\\\"editlock\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"fe_group\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"tx_mask_catgeory\\\":\\\"\\\",\\\"tx_mask_link_for_image\\\":\\\"\\\",\\\"tx_mask_photo_case\\\":\\\"\\\",\\\"tx_mask_text_on_image\\\":\\\"\\\"}\"}}',0,'0400$faa1fcd4cc45ab2ccaa49fc299bf0688:4fa71a4e6ba5191b078d49ee5e775d3a'),
(107,1762442745,2,'BE',1,0,2,'tx_mask_all_cases','{\"oldRecord\":{\"l10n_diffsource\":\"{\\\"hidden\\\":\\\"\\\"}\"},\"newRecord\":{\"l10n_diffsource\":\"{\\\"editlock\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"fe_group\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"tx_mask_catgeory\\\":\\\"\\\",\\\"tx_mask_link_for_image\\\":\\\"\\\",\\\"tx_mask_photo_case\\\":\\\"\\\",\\\"tx_mask_text_on_image\\\":\\\"\\\"}\"}}',0,'0400$faa1fcd4cc45ab2ccaa49fc299bf0688:5e4c21dcb0299f635533788b0d9698d2'),
(108,1762442745,2,'BE',1,0,6,'tx_mask_all_cases','{\"oldRecord\":{\"l10n_diffsource\":\"{\\\"editlock\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"fe_group\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"parentid\\\":\\\"\\\",\\\"sorting\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"tx_mask_catgeory\\\":\\\"\\\",\\\"tx_mask_link_for_image\\\":\\\"\\\",\\\"tx_mask_photo_case\\\":\\\"\\\",\\\"tx_mask_text_on_image\\\":\\\"\\\"}\"},\"newRecord\":{\"l10n_diffsource\":\"{\\\"editlock\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"fe_group\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"tx_mask_catgeory\\\":\\\"\\\",\\\"tx_mask_link_for_image\\\":\\\"\\\",\\\"tx_mask_photo_case\\\":\\\"\\\",\\\"tx_mask_text_on_image\\\":\\\"\\\"}\"}}',0,'0400$faa1fcd4cc45ab2ccaa49fc299bf0688:81a0808a349cf0edad8bf12fbfb9d84e'),
(109,1762442745,1,'BE',1,0,21,'sys_file_reference','{\"sorting_foreign\":0,\"title\":null,\"description\":null,\"alternative\":null,\"autoplay\":0,\"hidden\":\"0\",\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"pid\":2,\"link\":\"\",\"crop\":\"{\\\"default\\\":{\\\"cropArea\\\":{\\\"x\\\":0,\\\"y\\\":0,\\\"width\\\":1,\\\"height\\\":1},\\\"selectedRatio\\\":\\\"NaN\\\",\\\"focusArea\\\":null}}\",\"uid_local\":\"10\",\"sys_language_uid\":0,\"crdate\":1762442745,\"t3ver_stage\":0,\"tstamp\":1762442745,\"uid\":21}',0,'0400$faa1fcd4cc45ab2ccaa49fc299bf0688:bd8e6a36b477d61e04d92cfd10d00f96'),
(110,1762442745,1,'BE',1,0,22,'sys_file_reference','{\"sorting_foreign\":0,\"title\":null,\"description\":null,\"alternative\":null,\"autoplay\":0,\"hidden\":\"0\",\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"pid\":2,\"link\":\"\",\"crop\":\"{\\\"default\\\":{\\\"cropArea\\\":{\\\"x\\\":0,\\\"y\\\":0,\\\"width\\\":1,\\\"height\\\":1},\\\"selectedRatio\\\":\\\"NaN\\\",\\\"focusArea\\\":null}}\",\"uid_local\":\"11\",\"sys_language_uid\":0,\"crdate\":1762442745,\"t3ver_stage\":0,\"tstamp\":1762442745,\"uid\":22}',0,'0400$faa1fcd4cc45ab2ccaa49fc299bf0688:d6a5725e5b31cdd97b9c53c992e81850'),
(111,1762442745,2,'BE',1,0,20,'sys_file_reference','{\"oldRecord\":{\"l10n_diffsource\":\"\"},\"newRecord\":{\"l10n_diffsource\":\"{\\\"alternative\\\":\\\"\\\",\\\"crop\\\":\\\"\\\",\\\"description\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"link\\\":\\\"\\\",\\\"title\\\":\\\"\\\",\\\"uid_local\\\":\\\"\\\"}\"}}',0,'0400$faa1fcd4cc45ab2ccaa49fc299bf0688:97d0d1c7a42cd9603b2010379c1e4e4d'),
(112,1762442745,2,'BE',1,0,1,'tx_mask_all_cases','{\"oldRecord\":{\"l10n_diffsource\":\"{\\\"hidden\\\":\\\"\\\"}\"},\"newRecord\":{\"l10n_diffsource\":\"{\\\"editlock\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"fe_group\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"tx_mask_catgeory\\\":\\\"\\\",\\\"tx_mask_link_for_image\\\":\\\"\\\",\\\"tx_mask_photo_case\\\":\\\"\\\",\\\"tx_mask_text_on_image\\\":\\\"\\\"}\"}}',0,'0400$faa1fcd4cc45ab2ccaa49fc299bf0688:4fa71a4e6ba5191b078d49ee5e775d3a'),
(113,1762442745,2,'BE',1,0,2,'tx_mask_all_cases','{\"oldRecord\":{\"l10n_diffsource\":\"{\\\"hidden\\\":\\\"\\\"}\"},\"newRecord\":{\"l10n_diffsource\":\"{\\\"editlock\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"fe_group\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"tx_mask_catgeory\\\":\\\"\\\",\\\"tx_mask_link_for_image\\\":\\\"\\\",\\\"tx_mask_photo_case\\\":\\\"\\\",\\\"tx_mask_text_on_image\\\":\\\"\\\"}\"}}',0,'0400$faa1fcd4cc45ab2ccaa49fc299bf0688:5e4c21dcb0299f635533788b0d9698d2'),
(114,1762442745,4,'BE',1,0,13,'sys_file_reference',NULL,0,'0400$faa1fcd4cc45ab2ccaa49fc299bf0688:5e1f4fea56ad8d21a419f2b59b059abf'),
(115,1762442745,4,'BE',1,0,14,'sys_file_reference',NULL,0,'0400$faa1fcd4cc45ab2ccaa49fc299bf0688:2207c2b650522ebf0efd90eaad3962af'),
(116,1762442865,2,'BE',1,0,3,'tx_mask_all_cases','{\"oldRecord\":{\"l10n_diffsource\":\"{\\\"hidden\\\":\\\"\\\"}\"},\"newRecord\":{\"l10n_diffsource\":\"{\\\"editlock\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"fe_group\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"tx_mask_catgeory\\\":\\\"\\\",\\\"tx_mask_link_for_image\\\":\\\"\\\",\\\"tx_mask_photo_case\\\":\\\"\\\",\\\"tx_mask_text_on_image\\\":\\\"\\\"}\"}}',0,'0400$27e07b13662b7e018b4675b00c9fb5b3:373afe1c25802cd9bcc3081fb735e1d1'),
(117,1762442865,2,'BE',1,0,21,'sys_file_reference','{\"oldRecord\":{\"l10n_diffsource\":\"\"},\"newRecord\":{\"l10n_diffsource\":\"{\\\"alternative\\\":\\\"\\\",\\\"crop\\\":\\\"\\\",\\\"description\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"link\\\":\\\"\\\",\\\"title\\\":\\\"\\\",\\\"uid_local\\\":\\\"\\\"}\"}}',0,'0400$27e07b13662b7e018b4675b00c9fb5b3:bd8e6a36b477d61e04d92cfd10d00f96'),
(118,1762442865,2,'BE',1,0,22,'sys_file_reference','{\"oldRecord\":{\"l10n_diffsource\":\"\"},\"newRecord\":{\"l10n_diffsource\":\"{\\\"alternative\\\":\\\"\\\",\\\"crop\\\":\\\"\\\",\\\"description\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"link\\\":\\\"\\\",\\\"title\\\":\\\"\\\",\\\"uid_local\\\":\\\"\\\"}\"}}',0,'0400$27e07b13662b7e018b4675b00c9fb5b3:d6a5725e5b31cdd97b9c53c992e81850'),
(119,1762442865,1,'BE',1,0,23,'sys_file_reference','{\"sorting_foreign\":0,\"title\":null,\"description\":null,\"alternative\":null,\"autoplay\":0,\"hidden\":\"0\",\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"pid\":2,\"link\":\"\",\"crop\":\"{\\\"default\\\":{\\\"cropArea\\\":{\\\"x\\\":0,\\\"y\\\":0,\\\"width\\\":1,\\\"height\\\":1},\\\"selectedRatio\\\":\\\"NaN\\\",\\\"focusArea\\\":null}}\",\"uid_local\":\"12\",\"sys_language_uid\":0,\"crdate\":1762442865,\"t3ver_stage\":0,\"tstamp\":1762442865,\"uid\":23}',0,'0400$27e07b13662b7e018b4675b00c9fb5b3:a4b81cbb471961a3c12b21861b94f4e1'),
(120,1762442865,2,'BE',1,0,3,'tx_mask_all_cases','{\"oldRecord\":{\"l10n_diffsource\":\"{\\\"hidden\\\":\\\"\\\"}\"},\"newRecord\":{\"l10n_diffsource\":\"{\\\"editlock\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"fe_group\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"tx_mask_catgeory\\\":\\\"\\\",\\\"tx_mask_link_for_image\\\":\\\"\\\",\\\"tx_mask_photo_case\\\":\\\"\\\",\\\"tx_mask_text_on_image\\\":\\\"\\\"}\"}}',0,'0400$27e07b13662b7e018b4675b00c9fb5b3:373afe1c25802cd9bcc3081fb735e1d1'),
(121,1762442865,4,'BE',1,0,15,'sys_file_reference',NULL,0,'0400$27e07b13662b7e018b4675b00c9fb5b3:53cbb769126fb106e07a09de5e196b60'),
(122,1762443238,2,'BE',1,0,2,'tx_mask_all_cases','{\"oldRecord\":{\"l10n_diffsource\":\"{\\\"editlock\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"fe_group\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"tx_mask_catgeory\\\":\\\"\\\",\\\"tx_mask_link_for_image\\\":\\\"\\\",\\\"tx_mask_photo_case\\\":\\\"\\\",\\\"tx_mask_text_on_image\\\":\\\"\\\"}\"},\"newRecord\":{\"l10n_diffsource\":\"{\\\"hidden\\\":\\\"\\\"}\"}}',0,'0400$ca79a0d64980b418b8cad755b4bbd05e:5e4c21dcb0299f635533788b0d9698d2'),
(123,1762443238,2,'BE',1,0,23,'sys_file_reference','{\"oldRecord\":{\"l10n_diffsource\":\"\"},\"newRecord\":{\"l10n_diffsource\":\"{\\\"alternative\\\":\\\"\\\",\\\"crop\\\":\\\"\\\",\\\"description\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"link\\\":\\\"\\\",\\\"title\\\":\\\"\\\",\\\"uid_local\\\":\\\"\\\"}\"}}',0,'0400$ca79a0d64980b418b8cad755b4bbd05e:a4b81cbb471961a3c12b21861b94f4e1'),
(124,1762443398,3,'BE',1,0,4,'sys_category','{\"oldData\":{\"pid\":2,\"tstamp\":1762435308,\"sorting\":1024},\"newData\":{\"tstamp\":1762443398,\"sorting\":640,\"pid\":2}}',0,'0400$d86b5ff24e98cef5fdb49ba4240f4f01:a832991055f9726888b6b83414d05630'),
(125,1762443420,3,'BE',1,0,3,'sys_category','{\"oldData\":{\"pid\":2,\"tstamp\":1762435305,\"sorting\":768},\"newData\":{\"tstamp\":1762443420,\"sorting\":576,\"pid\":2}}',0,'0400$0f30f1e390424b3deef55e78c6dd6cf4:265912e2a2dda6b4b6be4e7069754d09'),
(126,1762444509,2,'BE',1,0,3,'tt_content','{\"oldRecord\":{\"l18n_diffsource\":\"\"},\"newRecord\":{\"l18n_diffsource\":\"{\\\"CType\\\":\\\"\\\",\\\"categories\\\":\\\"\\\",\\\"colPos\\\":\\\"\\\",\\\"editlock\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"fe_group\\\":\\\"\\\",\\\"frame_class\\\":\\\"\\\",\\\"header\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"layout\\\":\\\"\\\",\\\"linkToTop\\\":\\\"\\\",\\\"rowDescription\\\":\\\"\\\",\\\"sectionIndex\\\":\\\"\\\",\\\"space_after_class\\\":\\\"\\\",\\\"space_before_class\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"tx_mask_chose_link\\\":\\\"\\\",\\\"tx_mask_home_image\\\":\\\"\\\",\\\"tx_mask_small_text_on_image\\\":\\\"\\\"}\"}}',0,'0400$6459681c081fa7e820e5676e30a8019f:b92300cfb5d1d3645c9cb212a7f56c1f'),
(127,1762444509,1,'BE',1,0,24,'sys_file_reference','{\"sorting_foreign\":0,\"title\":null,\"description\":null,\"alternative\":null,\"autoplay\":0,\"hidden\":\"0\",\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"pid\":1,\"link\":\"\",\"crop\":\"{\\\"default\\\":{\\\"cropArea\\\":{\\\"x\\\":0,\\\"y\\\":0,\\\"width\\\":1,\\\"height\\\":1},\\\"selectedRatio\\\":\\\"NaN\\\",\\\"focusArea\\\":null}}\",\"uid_local\":\"13\",\"sys_language_uid\":0,\"crdate\":1762444509,\"t3ver_stage\":0,\"tstamp\":1762444509,\"uid\":24}',0,'0400$6459681c081fa7e820e5676e30a8019f:ec378d8e96f494986de35c9be84dff5c'),
(128,1762444509,2,'BE',1,0,3,'tt_content','{\"oldRecord\":{\"l18n_diffsource\":\"\"},\"newRecord\":{\"l18n_diffsource\":\"{\\\"CType\\\":\\\"\\\",\\\"categories\\\":\\\"\\\",\\\"colPos\\\":\\\"\\\",\\\"editlock\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"fe_group\\\":\\\"\\\",\\\"frame_class\\\":\\\"\\\",\\\"header\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"layout\\\":\\\"\\\",\\\"linkToTop\\\":\\\"\\\",\\\"rowDescription\\\":\\\"\\\",\\\"sectionIndex\\\":\\\"\\\",\\\"space_after_class\\\":\\\"\\\",\\\"space_before_class\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"tx_mask_chose_link\\\":\\\"\\\",\\\"tx_mask_home_image\\\":\\\"\\\",\\\"tx_mask_small_text_on_image\\\":\\\"\\\"}\"}}',0,'0400$6459681c081fa7e820e5676e30a8019f:b92300cfb5d1d3645c9cb212a7f56c1f'),
(129,1762444509,4,'BE',1,0,3,'sys_file_reference',NULL,0,'0400$6459681c081fa7e820e5676e30a8019f:d2c609347a4764200256b39b9425159a'),
(130,1762444587,1,'BE',1,0,25,'sys_file_reference','{\"sorting_foreign\":0,\"title\":null,\"description\":null,\"alternative\":null,\"autoplay\":0,\"hidden\":\"0\",\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"pid\":1,\"link\":\"\",\"crop\":\"{\\\"default\\\":{\\\"cropArea\\\":{\\\"x\\\":0,\\\"y\\\":0,\\\"width\\\":1,\\\"height\\\":1},\\\"selectedRatio\\\":\\\"NaN\\\",\\\"focusArea\\\":null}}\",\"uid_local\":\"14\",\"sys_language_uid\":0,\"crdate\":1762444587,\"t3ver_stage\":0,\"tstamp\":1762444587,\"uid\":25}',0,'0400$9e4072fe51f3bfbfd22478ebb22b95d5:5ce305fb03b44e2e5ced3360656e263a'),
(131,1762444587,4,'BE',1,0,24,'sys_file_reference',NULL,0,'0400$9e4072fe51f3bfbfd22478ebb22b95d5:ec378d8e96f494986de35c9be84dff5c');
/*!40000 ALTER TABLE `sys_history` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_http_report`
--

DROP TABLE IF EXISTS `sys_http_report`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_http_report` (
  `uuid` varchar(36) NOT NULL,
  `status` smallint(5) unsigned NOT NULL DEFAULT 0,
  `created` int(10) unsigned NOT NULL,
  `changed` int(10) unsigned NOT NULL,
  `type` varchar(32) NOT NULL,
  `scope` varchar(100) NOT NULL,
  `request_time` bigint(20) unsigned NOT NULL,
  `meta` mediumtext DEFAULT NULL,
  `details` mediumtext DEFAULT NULL,
  `summary` varchar(40) NOT NULL,
  PRIMARY KEY (`uuid`),
  KEY `type_scope` (`type`,`scope`),
  KEY `created` (`created`),
  KEY `changed` (`changed`),
  KEY `request_time` (`request_time`),
  KEY `summary_created` (`summary`,`created`),
  KEY `all_conditions` (`type`,`status`,`scope`,`summary`,`request_time`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_http_report`
--

LOCK TABLES `sys_http_report` WRITE;
/*!40000 ALTER TABLE `sys_http_report` DISABLE KEYS */;
INSERT INTO `sys_http_report` VALUES
('61a9530e-8d7b-424d-b05a-c86f12d74834',0,1762859367,1762859367,'csp-report','backend',1762859367154169,'{\"addr\":\"172.18.0.0\",\"agent\":\"Mozilla\\/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/142.0.0.0 Safari\\/537.36\"}','{\"document-uri\":\"https:\\/\\/raffael.ddev.site\\/typo3\\/module\\/web\\/layout?id=2\",\"referrer\":\"https:\\/\\/raffael.ddev.site\\/typo3\\/module\\/web\\/layout?id=6\",\"violated-directive\":\"script-src-elem\",\"effective-directive\":\"script-src-elem\",\"original-policy\":\"default-src \'self\'; script-src \'self\' \'nonce-R4M1ZjN1G90-zposU86OWC7k0OZWQk3cEraCjXqg1DQGVd10acS6zw\' data: \'unsafe-eval\' \'report-sample\'; style-src \'self\' \'unsafe-inline\' \'report-sample\'; style-src-attr \'unsafe-inline\' \'report-sample\'; img-src \'self\' data: *.ytimg.com *.vimeocdn.com https:\\/\\/extensions.typo3.org; frame-src \'self\' *.youtube-nocookie.com *.youtube.com *.vimeo.com; base-uri \'none\'; object-src \'none\'; report-uri https:\\/\\/raffael.ddev.site\\/typo3\\/@http-reporting?csp=report&requestTime=1762859367154169&requestHash=5c137c01b8c50fdcca318b2a24c151389daf02b0\",\"disposition\":\"enforce\",\"blocked-uri\":\"inline\",\"line-number\":410,\"source-file\":\"https:\\/\\/raffael.ddev.site\\/typo3\\/module\\/web\\/layout\",\"status-code\":200,\"script-sample\":\"(function () {\\n    const nav = document.\"}','00a5adf68d3e5100c938525b2404cb88c0739484'),
('dfa2623a-21e9-47a3-a6e2-00cec8410c06',0,1762859363,1762859363,'csp-report','backend',1762859363576665,'{\"addr\":\"172.18.0.0\",\"agent\":\"Mozilla\\/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/142.0.0.0 Safari\\/537.36\"}','{\"document-uri\":\"https:\\/\\/raffael.ddev.site\\/typo3\\/module\\/web\\/layout?id=6\",\"referrer\":\"https:\\/\\/raffael.ddev.site\\/typo3\\/module\\/web\\/layout?id=1\",\"violated-directive\":\"script-src-elem\",\"effective-directive\":\"script-src-elem\",\"original-policy\":\"default-src \'self\'; script-src \'self\' \'nonce-uA7D_zpYtLzDau3f3bBKLUraVepx10sHOQfHRlQMPvxSjkyURw1H9A\' data: \'unsafe-eval\' \'report-sample\'; style-src \'self\' \'unsafe-inline\' \'report-sample\'; style-src-attr \'unsafe-inline\' \'report-sample\'; img-src \'self\' data: *.ytimg.com *.vimeocdn.com https:\\/\\/extensions.typo3.org; frame-src \'self\' *.youtube-nocookie.com *.youtube.com *.vimeo.com; base-uri \'none\'; object-src \'none\'; report-uri https:\\/\\/raffael.ddev.site\\/typo3\\/@http-reporting?csp=report&requestTime=1762859363576665&requestHash=728437c038cac80ea46e193fe11ce28b2ded5cb2\",\"disposition\":\"enforce\",\"blocked-uri\":\"inline\",\"line-number\":388,\"source-file\":\"https:\\/\\/raffael.ddev.site\\/typo3\\/module\\/web\\/layout\",\"status-code\":200,\"script-sample\":\"(function() {\\n        const backLink = d\"}','c8f382b527d159b2f184a615209984ef36df857b');
/*!40000 ALTER TABLE `sys_http_report` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_lockedrecords`
--

DROP TABLE IF EXISTS `sys_lockedrecords`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_lockedrecords` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `userid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `record_table` varchar(255) NOT NULL DEFAULT '',
  `record_uid` int(11) NOT NULL DEFAULT 0,
  `record_pid` int(11) NOT NULL DEFAULT 0,
  `username` varchar(50) NOT NULL DEFAULT '',
  `feuserid` int(10) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `event` (`userid`,`tstamp`)
) ENGINE=InnoDB AUTO_INCREMENT=77 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_lockedrecords`
--

LOCK TABLES `sys_lockedrecords` WRITE;
/*!40000 ALTER TABLE `sys_lockedrecords` DISABLE KEYS */;
INSERT INTO `sys_lockedrecords` VALUES
(76,1,1762503894,'tt_content',3,1,'admin',0);
/*!40000 ALTER TABLE `sys_lockedrecords` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_log`
--

DROP TABLE IF EXISTS `sys_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_log` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `userid` int(10) unsigned NOT NULL DEFAULT 0,
  `action` smallint(5) unsigned NOT NULL DEFAULT 0,
  `recuid` int(10) unsigned NOT NULL DEFAULT 0,
  `tablename` varchar(255) NOT NULL DEFAULT '',
  `recpid` int(11) NOT NULL DEFAULT 0,
  `error` smallint(5) unsigned NOT NULL DEFAULT 0,
  `details` text DEFAULT NULL,
  `type` smallint(5) unsigned NOT NULL DEFAULT 0,
  `channel` varchar(20) NOT NULL DEFAULT 'default',
  `details_nr` smallint(6) NOT NULL DEFAULT 0,
  `IP` varchar(39) NOT NULL DEFAULT '',
  `log_data` text DEFAULT NULL,
  `event_pid` int(11) NOT NULL DEFAULT -1,
  `workspace` int(11) NOT NULL DEFAULT 0,
  `request_id` varchar(13) NOT NULL DEFAULT '',
  `time_micro` double NOT NULL DEFAULT 0,
  `component` varchar(255) NOT NULL DEFAULT '',
  `level` varchar(10) NOT NULL DEFAULT 'info',
  `message` text DEFAULT NULL,
  `data` text DEFAULT NULL,
  PRIMARY KEY (`uid`),
  KEY `event` (`userid`,`event_pid`),
  KEY `recuidIdx` (`recuid`),
  KEY `user_auth` (`type`,`action`,`tstamp`),
  KEY `request` (`request_id`),
  KEY `combined_1` (`tstamp`,`type`,`userid`),
  KEY `errorcount` (`tstamp`,`error`),
  KEY `index_channel` (`channel`),
  KEY `index_level` (`level`)
) ENGINE=InnoDB AUTO_INCREMENT=293 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_log`
--

LOCK TABLES `sys_log` WRITE;
/*!40000 ALTER TABLE `sys_log` DISABLE KEYS */;
INSERT INTO `sys_log` VALUES
(1,1762268426,1,1,0,'',0,0,'User %s logged in from ###IP###',255,'user',0,'172.18.0.5','[\"admin\"]',-1,-99,'',0,'','info',NULL,NULL),
(2,1762268438,1,1,1,'pages',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content',0,'172.18.0.5','{\"table\":\"pages\",\"uid\":1,\"pid\":0}',0,0,'',0,'','info',NULL,NULL),
(3,1762268438,1,1,0,'site',0,0,'Site configuration \'%s\' was automatically created for new root page (%s).',6,'site',0,'172.18.0.5','[\"autogenerated-1-c4ca4238a0b923820dcc509a6f75849b\",1]',-1,0,'',0,'','info',NULL,NULL),
(4,1762268438,1,2,1,'pages',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.5','{\"table\":\"pages\",\"uid\":1,\"history\":\"2\"}',0,0,'',0,'','info',NULL,NULL),
(5,1762268470,1,2,1,'pages',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.5','{\"table\":\"pages\",\"uid\":1,\"history\":\"3\"}',0,0,'',0,'','info',NULL,NULL),
(6,1762268502,1,3,0,'site',0,0,'Site configuration \'%s\' was renamed to \'%s\'.',6,'site',0,'172.18.0.5','[\"autogenerated-1-c4ca4238a0b923820dcc509a6f75849b\",\"raffael_page_ok\"]',-1,0,'',0,'','info',NULL,NULL),
(7,1762268502,1,2,0,'site',0,0,'Site configuration \'%s\' was updated.',6,'site',0,'172.18.0.5','[\"raffael_page_ok\"]',-1,0,'',0,'','info',NULL,NULL),
(8,1762268507,1,2,0,'site',0,0,'Site configuration \'%s\' was updated.',6,'site',0,'172.18.0.5','[\"raffael_page_ok\"]',-1,0,'',0,'','info',NULL,NULL),
(9,1762268508,1,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1607585445: No TypoScript record found! | TYPO3\\CMS\\Core\\Error\\Http\\InternalServerErrorException thrown in file /var/www/html/vendor/typo3/cms-frontend/Classes/Controller/ErrorController.php in line 48. Requested URL: https://raffael.ddev.site/',5,'php',0,'172.18.0.5','',-1,0,'',0,'','error',NULL,NULL),
(10,1762268511,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.5','{\"username\":\"admin\",\"command\":\"all\"}',-1,0,'',0,'','info',NULL,NULL),
(11,1762268533,1,2,0,'site',0,0,'Site configuration \'%s\' was updated.',6,'site',0,'172.18.0.5','[\"raffael_page_ok\"]',-1,0,'',0,'','info',NULL,NULL),
(12,1762268546,1,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1607585445: No page configured for type=0. | TYPO3\\CMS\\Core\\Error\\Http\\InternalServerErrorException thrown in file /var/www/html/vendor/typo3/cms-frontend/Classes/Controller/ErrorController.php in line 48. Requested URL: https://raffael.ddev.site/',5,'php',0,'172.18.0.5','',-1,0,'',0,'','error',NULL,NULL),
(13,1762268549,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.5','{\"username\":\"admin\",\"command\":\"all\"}',-1,0,'',0,'','info',NULL,NULL),
(14,1762268550,1,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1607585445: No page configured for type=0. | TYPO3\\CMS\\Core\\Error\\Http\\InternalServerErrorException thrown in file /var/www/html/vendor/typo3/cms-frontend/Classes/Controller/ErrorController.php in line 48. Requested URL: https://raffael.ddev.site/',5,'php',0,'172.18.0.5','',-1,0,'',0,'','error',NULL,NULL),
(15,1762268907,1,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1607585445: No page configured for type=0. | TYPO3\\CMS\\Core\\Error\\Http\\InternalServerErrorException thrown in file /var/www/html/vendor/typo3/cms-frontend/Classes/Controller/ErrorController.php in line 48. Requested URL: https://raffael.ddev.site/',5,'php',0,'172.18.0.5','',-1,0,'',0,'','error',NULL,NULL),
(16,1762268908,1,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1607585445: No page configured for type=0. | TYPO3\\CMS\\Core\\Error\\Http\\InternalServerErrorException thrown in file /var/www/html/vendor/typo3/cms-frontend/Classes/Controller/ErrorController.php in line 48. Requested URL: https://raffael.ddev.site/',5,'php',0,'172.18.0.5','',-1,0,'',0,'','error',NULL,NULL),
(17,1762268911,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.5','{\"username\":\"admin\",\"command\":\"all\"}',-1,0,'',0,'','info',NULL,NULL),
(18,1762269310,1,2,0,'site',0,0,'Site configuration \'%s\' was updated.',6,'site',0,'172.18.0.5','[\"raffael_page_ok\"]',-1,0,'',0,'','info',NULL,NULL),
(19,1762269315,1,2,0,'site',0,0,'Site configuration \'%s\' was updated.',6,'site',0,'172.18.0.5','[\"raffael_page_ok\"]',-1,0,'',0,'','info',NULL,NULL),
(20,1762269321,1,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1607585445: No page configured for type=0. | TYPO3\\CMS\\Core\\Error\\Http\\InternalServerErrorException thrown in file /var/www/html/vendor/typo3/cms-frontend/Classes/Controller/ErrorController.php in line 48. Requested URL: https://raffael.ddev.site/',5,'php',0,'172.18.0.5','',-1,0,'',0,'','error',NULL,NULL),
(21,1762269324,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.5','{\"username\":\"admin\",\"command\":\"all\"}',-1,0,'',0,'','info',NULL,NULL),
(22,1762269325,1,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1607585445: No page configured for type=0. | TYPO3\\CMS\\Core\\Error\\Http\\InternalServerErrorException thrown in file /var/www/html/vendor/typo3/cms-frontend/Classes/Controller/ErrorController.php in line 48. Requested URL: https://raffael.ddev.site/',5,'php',0,'172.18.0.5','',-1,0,'',0,'','error',NULL,NULL),
(23,1762269420,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.5','{\"username\":\"admin\",\"command\":\"all\"}',-1,0,'',0,'','info',NULL,NULL),
(24,1762269439,1,2,0,'site',0,0,'Site configuration \'%s\' was updated.',6,'site',0,'172.18.0.5','[\"raffael_page_ok\"]',-1,0,'',0,'','info',NULL,NULL),
(25,1762269443,1,2,0,'site',0,0,'Site configuration \'%s\' was updated.',6,'site',0,'172.18.0.5','[\"raffael_page_ok\"]',-1,0,'',0,'','info',NULL,NULL),
(26,1762269447,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.5','{\"username\":\"admin\",\"command\":\"all\"}',-1,0,'',0,'','info',NULL,NULL),
(27,1762269450,1,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1607585445: No page configured for type=0. | TYPO3\\CMS\\Core\\Error\\Http\\InternalServerErrorException thrown in file /var/www/html/vendor/typo3/cms-frontend/Classes/Controller/ErrorController.php in line 48. Requested URL: https://raffael.ddev.site/',5,'php',0,'172.18.0.5','',-1,0,'',0,'','error',NULL,NULL),
(28,1762269816,1,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1607585445: No page configured for type=0. | TYPO3\\CMS\\Core\\Error\\Http\\InternalServerErrorException thrown in file /var/www/html/vendor/typo3/cms-frontend/Classes/Controller/ErrorController.php in line 48. Requested URL: https://raffael.ddev.site/',5,'php',0,'172.18.0.5','',-1,0,'',0,'','error',NULL,NULL),
(29,1762269818,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.5','{\"username\":\"admin\",\"command\":\"all\"}',-1,0,'',0,'','info',NULL,NULL),
(30,1762269845,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.5','{\"username\":\"admin\",\"command\":\"all\"}',-1,0,'',0,'','info',NULL,NULL),
(31,1762269960,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.5','{\"username\":\"admin\",\"command\":\"all\"}',-1,0,'',0,'','info',NULL,NULL),
(32,1762270185,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.5','{\"username\":\"admin\",\"command\":\"all\"}',-1,0,'',0,'','info',NULL,NULL),
(33,1762270235,1,2,0,'site',0,0,'Site configuration \'%s\' was updated.',6,'site',0,'172.18.0.5','[\"raffael_page_ok\"]',-1,0,'',0,'','info',NULL,NULL),
(34,1762270436,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.5','{\"username\":\"admin\",\"command\":\"all\"}',-1,0,'',0,'','info',NULL,NULL),
(35,1762270461,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.5','{\"username\":\"admin\",\"command\":\"all\"}',-1,0,'',0,'','info',NULL,NULL),
(36,1762270504,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.5','{\"username\":\"admin\",\"command\":\"all\"}',-1,0,'',0,'','info',NULL,NULL),
(37,1762270553,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.5','{\"username\":\"admin\",\"command\":\"all\"}',-1,0,'',0,'','info',NULL,NULL),
(38,1762270750,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.5','{\"username\":\"admin\",\"command\":\"all\"}',-1,0,'',0,'','info',NULL,NULL),
(39,1762270755,1,2,0,'site',0,0,'Site configuration \'%s\' was updated.',6,'site',0,'172.18.0.5','[\"raffael_page_ok\"]',-1,0,'',0,'','info',NULL,NULL),
(40,1762270921,1,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1509741914: Unable to render image tag in \"pages:1\": File /_assets/7615faf4ef1c8e2ff0d9d782346dc48a/Images/logo-black.svg does not exist. | TYPO3Fluid\\Fluid\\Core\\ViewHelper\\Exception thrown in file /var/www/html/vendor/typo3/cms-fluid/Classes/ViewHelpers/ImageViewHelper.php in line 172. Requested URL: https://raffael.ddev.site/',5,'php',0,'172.18.0.5','',-1,0,'',0,'','error',NULL,NULL),
(41,1762271436,1,1,2,'pages',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content',0,'172.18.0.5','{\"table\":\"pages\",\"uid\":2,\"pid\":1}',1,0,'',0,'','info',NULL,NULL),
(42,1762271440,1,1,3,'pages',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content',0,'172.18.0.5','{\"table\":\"pages\",\"uid\":3,\"pid\":1}',1,0,'',0,'','info',NULL,NULL),
(43,1762271444,1,4,3,'pages',0,0,'Moved record {table}:{uid} on page {pid}',1,'content',0,'172.18.0.5','{\"table\":\"pages\",\"uid\":3,\"pid\":1}',1,0,'',0,'','info',NULL,NULL),
(44,1762271448,1,2,3,'pages',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.5','{\"table\":\"pages\",\"uid\":3,\"history\":\"7\"}',1,0,'',0,'','info',NULL,NULL),
(45,1762271450,1,2,2,'pages',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.5','{\"table\":\"pages\",\"uid\":2,\"history\":\"8\"}',1,0,'',0,'','info',NULL,NULL),
(46,1762271797,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.5','{\"username\":\"admin\",\"command\":\"all\"}',-1,0,'',0,'','info',NULL,NULL),
(47,1762272167,1,1,0,'',0,0,'Uploading file \"{identifier}\" to \"{destination}\"',2,'file',0,'172.18.0.5','{\"identifier\":\"elo.jpg\",\"destination\":\"\\/user_upload\\/\"}',-1,0,'',0,'','info',NULL,NULL),
(48,1762272170,1,2,1,'pages',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.5','{\"table\":\"pages\",\"uid\":1,\"history\":\"9\"}',0,0,'',0,'','info',NULL,NULL),
(49,1762272170,1,1,1,'sys_file_reference',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content',0,'172.18.0.5','{\"table\":\"sys_file_reference\",\"uid\":1,\"pid\":1}',1,0,'',0,'','info',NULL,NULL),
(50,1762272170,1,2,1,'pages',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.5','{\"table\":\"pages\",\"uid\":1,\"history\":\"11\"}',0,0,'',0,'','info',NULL,NULL),
(51,1762272171,1,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined property: TYPO3\\CMS\\Frontend\\Controller\\TypoScriptFrontendController::$lastImgResourceInfo in /var/www/html/vendor/typo3/cms-frontend/Classes/ContentObject/ContentObjectRenderer.php line 4285',5,'php',0,'172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL),
(52,1762272175,1,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined property: TYPO3\\CMS\\Frontend\\Controller\\TypoScriptFrontendController::$lastImgResourceInfo in /var/www/html/vendor/typo3/cms-frontend/Classes/ContentObject/ContentObjectRenderer.php line 4285',5,'php',0,'172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL),
(53,1762272179,1,2,1,'pages',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.5','{\"table\":\"pages\",\"uid\":1,\"history\":0}',0,0,'',0,'','info',NULL,NULL),
(54,1762272179,1,2,1,'sys_file_reference',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.5','{\"table\":\"sys_file_reference\",\"uid\":1,\"history\":\"12\"}',1,0,'',0,'','info',NULL,NULL),
(55,1762272181,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.5','{\"username\":\"admin\",\"command\":\"all\"}',-1,0,'',0,'','info',NULL,NULL),
(56,1762272182,1,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined property: TYPO3\\CMS\\Frontend\\Controller\\TypoScriptFrontendController::$lastImgResourceInfo in /var/www/html/vendor/typo3/cms-frontend/Classes/ContentObject/ContentObjectRenderer.php line 4285',5,'php',0,'172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL),
(57,1762272199,1,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined property: TYPO3\\CMS\\Frontend\\Controller\\TypoScriptFrontendController::$lastImgResourceInfo in /var/www/html/vendor/typo3/cms-frontend/Classes/ContentObject/ContentObjectRenderer.php line 4285',5,'php',0,'172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL),
(58,1762272249,1,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined property: TYPO3\\CMS\\Frontend\\Controller\\TypoScriptFrontendController::$lastImgResourceInfo in /var/www/html/vendor/typo3/cms-frontend/Classes/ContentObject/ContentObjectRenderer.php line 4285',5,'php',0,'172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL),
(59,1762272271,1,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined property: TYPO3\\CMS\\Frontend\\Controller\\TypoScriptFrontendController::$lastImgResourceInfo in /var/www/html/vendor/typo3/cms-frontend/Classes/ContentObject/ContentObjectRenderer.php line 4285',5,'php',0,'172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL),
(60,1762272317,1,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1476107295: PHP Warning: Undefined property: TYPO3\\CMS\\Frontend\\Controller\\TypoScriptFrontendController::$lastImgResourceInfo in /var/www/html/vendor/typo3/cms-frontend/Classes/ContentObject/ContentObjectRenderer.php line 4285 | TYPO3\\CMS\\Core\\Error\\Exception thrown in file /var/www/html/vendor/typo3/cms-core/Classes/Error/ErrorHandler.php in line 141. Requested URL: https://raffael.ddev.site/work',5,'php',0,'172.18.0.5','',-1,0,'',0,'','error',NULL,NULL),
(61,1762272341,1,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1476107295: PHP Warning: Undefined property: TYPO3\\CMS\\Frontend\\Controller\\TypoScriptFrontendController::$lastImgResourceInfo in /var/www/html/vendor/typo3/cms-frontend/Classes/ContentObject/ContentObjectRenderer.php line 4285 | TYPO3\\CMS\\Core\\Error\\Exception thrown in file /var/www/html/vendor/typo3/cms-core/Classes/Error/ErrorHandler.php in line 141. Requested URL: https://raffael.ddev.site/work',5,'php',0,'172.18.0.5','',-1,0,'',0,'','error',NULL,NULL),
(62,1762272344,1,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1476107295: PHP Warning: Undefined property: TYPO3\\CMS\\Frontend\\Controller\\TypoScriptFrontendController::$lastImgResourceInfo in /var/www/html/vendor/typo3/cms-frontend/Classes/ContentObject/ContentObjectRenderer.php line 4285 | TYPO3\\CMS\\Core\\Error\\Exception thrown in file /var/www/html/vendor/typo3/cms-core/Classes/Error/ErrorHandler.php in line 141. Requested URL: https://raffael.ddev.site/work',5,'php',0,'172.18.0.5','',-1,0,'',0,'','error',NULL,NULL),
(63,1762272344,1,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1476107295: PHP Warning: Undefined property: TYPO3\\CMS\\Frontend\\Controller\\TypoScriptFrontendController::$lastImgResourceInfo in /var/www/html/vendor/typo3/cms-frontend/Classes/ContentObject/ContentObjectRenderer.php line 4285 | TYPO3\\CMS\\Core\\Error\\Exception thrown in file /var/www/html/vendor/typo3/cms-core/Classes/Error/ErrorHandler.php in line 141. Requested URL: https://raffael.ddev.site/work',5,'php',0,'172.18.0.5','',-1,0,'',0,'','error',NULL,NULL),
(64,1762272345,1,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1476107295: PHP Warning: Undefined property: TYPO3\\CMS\\Frontend\\Controller\\TypoScriptFrontendController::$lastImgResourceInfo in /var/www/html/vendor/typo3/cms-frontend/Classes/ContentObject/ContentObjectRenderer.php line 4285 | TYPO3\\CMS\\Core\\Error\\Exception thrown in file /var/www/html/vendor/typo3/cms-core/Classes/Error/ErrorHandler.php in line 141. Requested URL: https://raffael.ddev.site/work',5,'php',0,'172.18.0.5','',-1,0,'',0,'','error',NULL,NULL),
(65,1762272345,1,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1476107295: PHP Warning: Undefined property: TYPO3\\CMS\\Frontend\\Controller\\TypoScriptFrontendController::$lastImgResourceInfo in /var/www/html/vendor/typo3/cms-frontend/Classes/ContentObject/ContentObjectRenderer.php line 4285 | TYPO3\\CMS\\Core\\Error\\Exception thrown in file /var/www/html/vendor/typo3/cms-core/Classes/Error/ErrorHandler.php in line 141. Requested URL: https://raffael.ddev.site/work',5,'php',0,'172.18.0.5','',-1,0,'',0,'','error',NULL,NULL),
(66,1762272366,1,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1698750868: Cannot cast an array to string. | TYPO3Fluid\\Fluid\\Core\\Parser\\Exception thrown in file /var/www/html/vendor/typo3fluid/fluid/src/Core/Parser/SyntaxTree/AbstractNode.php in line 72. Requested URL: https://raffael.ddev.site/',5,'php',0,'172.18.0.5','',-1,0,'',0,'','error',NULL,NULL),
(67,1762272393,1,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1540246570: No Content Object definition found at TypoScript object path \"\" | TYPO3Fluid\\Fluid\\Core\\ViewHelper\\Exception thrown in file /var/www/html/vendor/typo3/cms-fluid/Classes/ViewHelpers/CObjectViewHelper.php in line 114. Requested URL: https://raffael.ddev.site/',5,'php',0,'172.18.0.5','',-1,0,'',0,'','error',NULL,NULL),
(68,1762272429,1,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1476107295: PHP Warning: Undefined property: TYPO3\\CMS\\Frontend\\Controller\\TypoScriptFrontendController::$lastImgResourceInfo in /var/www/html/vendor/typo3/cms-frontend/Classes/ContentObject/ContentObjectRenderer.php line 4285 | TYPO3\\CMS\\Core\\Error\\Exception thrown in file /var/www/html/vendor/typo3/cms-core/Classes/Error/ErrorHandler.php in line 141. Requested URL: https://raffael.ddev.site/',5,'php',0,'172.18.0.5','',-1,0,'',0,'','error',NULL,NULL),
(69,1762272452,1,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1476107295: PHP Warning: Undefined property: TYPO3\\CMS\\Frontend\\Controller\\TypoScriptFrontendController::$lastImgResourceInfo in /var/www/html/vendor/typo3/cms-frontend/Classes/ContentObject/ContentObjectRenderer.php line 4285 | TYPO3\\CMS\\Core\\Error\\Exception thrown in file /var/www/html/vendor/typo3/cms-core/Classes/Error/ErrorHandler.php in line 141. Requested URL: https://raffael.ddev.site/',5,'php',0,'172.18.0.5','',-1,0,'',0,'','error',NULL,NULL),
(70,1762272470,1,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1476107295: PHP Warning: Undefined property: TYPO3\\CMS\\Frontend\\Controller\\TypoScriptFrontendController::$lastImgResourceInfo in /var/www/html/vendor/typo3/cms-frontend/Classes/ContentObject/ContentObjectRenderer.php line 4285 | TYPO3\\CMS\\Core\\Error\\Exception thrown in file /var/www/html/vendor/typo3/cms-core/Classes/Error/ErrorHandler.php in line 141. Requested URL: https://raffael.ddev.site/',5,'php',0,'172.18.0.5','',-1,0,'',0,'','error',NULL,NULL),
(71,1762272473,1,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1476107295: PHP Warning: Undefined property: TYPO3\\CMS\\Frontend\\Controller\\TypoScriptFrontendController::$lastImgResourceInfo in /var/www/html/vendor/typo3/cms-frontend/Classes/ContentObject/ContentObjectRenderer.php line 4285 | TYPO3\\CMS\\Core\\Error\\Exception thrown in file /var/www/html/vendor/typo3/cms-core/Classes/Error/ErrorHandler.php in line 141. Requested URL: https://raffael.ddev.site/',5,'php',0,'172.18.0.5','',-1,0,'',0,'','error',NULL,NULL),
(72,1762272478,1,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1476107295: PHP Warning: Undefined property: TYPO3\\CMS\\Frontend\\Controller\\TypoScriptFrontendController::$lastImgResourceInfo in /var/www/html/vendor/typo3/cms-frontend/Classes/ContentObject/ContentObjectRenderer.php line 4285 | TYPO3\\CMS\\Core\\Error\\Exception thrown in file /var/www/html/vendor/typo3/cms-core/Classes/Error/ErrorHandler.php in line 141. Requested URL: https://raffael.ddev.site/',5,'php',0,'172.18.0.5','',-1,0,'',0,'','error',NULL,NULL),
(73,1762272480,1,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1476107295: PHP Warning: Undefined property: TYPO3\\CMS\\Frontend\\Controller\\TypoScriptFrontendController::$lastImgResourceInfo in /var/www/html/vendor/typo3/cms-frontend/Classes/ContentObject/ContentObjectRenderer.php line 4285 | TYPO3\\CMS\\Core\\Error\\Exception thrown in file /var/www/html/vendor/typo3/cms-core/Classes/Error/ErrorHandler.php in line 141. Requested URL: https://raffael.ddev.site/',5,'php',0,'172.18.0.5','',-1,0,'',0,'','error',NULL,NULL),
(74,1762272482,1,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1476107295: PHP Warning: Undefined property: TYPO3\\CMS\\Frontend\\Controller\\TypoScriptFrontendController::$lastImgResourceInfo in /var/www/html/vendor/typo3/cms-frontend/Classes/ContentObject/ContentObjectRenderer.php line 4285 | TYPO3\\CMS\\Core\\Error\\Exception thrown in file /var/www/html/vendor/typo3/cms-core/Classes/Error/ErrorHandler.php in line 141. Requested URL: https://raffael.ddev.site/',5,'php',0,'172.18.0.5','',-1,0,'',0,'','error',NULL,NULL),
(75,1762272518,1,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1476107295: PHP Warning: Undefined property: TYPO3\\CMS\\Frontend\\Controller\\TypoScriptFrontendController::$lastImgResourceInfo in /var/www/html/vendor/typo3/cms-frontend/Classes/ContentObject/ContentObjectRenderer.php line 4285 | TYPO3\\CMS\\Core\\Error\\Exception thrown in file /var/www/html/vendor/typo3/cms-core/Classes/Error/ErrorHandler.php in line 141. Requested URL: https://raffael.ddev.site/',5,'php',0,'172.18.0.5','',-1,0,'',0,'','error',NULL,NULL),
(76,1762272519,1,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1476107295: PHP Warning: Undefined property: TYPO3\\CMS\\Frontend\\Controller\\TypoScriptFrontendController::$lastImgResourceInfo in /var/www/html/vendor/typo3/cms-frontend/Classes/ContentObject/ContentObjectRenderer.php line 4285 | TYPO3\\CMS\\Core\\Error\\Exception thrown in file /var/www/html/vendor/typo3/cms-core/Classes/Error/ErrorHandler.php in line 141. Requested URL: https://raffael.ddev.site/',5,'php',0,'172.18.0.5','',-1,0,'',0,'','error',NULL,NULL),
(77,1762272523,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.5','{\"username\":\"admin\",\"command\":\"all\"}',-1,0,'',0,'','info',NULL,NULL),
(78,1762272812,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.5','{\"username\":\"admin\",\"command\":\"all\"}',-1,0,'',0,'','info',NULL,NULL),
(79,1762273059,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.5','{\"username\":\"admin\",\"command\":\"all\"}',-1,0,'',0,'','info',NULL,NULL),
(80,1762273085,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.5','{\"username\":\"admin\",\"command\":\"all\"}',-1,0,'',0,'','info',NULL,NULL),
(81,1762273125,1,1,1,'tt_content',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content',0,'172.18.0.5','{\"table\":\"tt_content\",\"uid\":1,\"pid\":1}',1,0,'',0,'','info',NULL,NULL),
(82,1762273125,1,1,2,'sys_file_reference',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content',0,'172.18.0.5','{\"table\":\"sys_file_reference\",\"uid\":2,\"pid\":1}',1,0,'',0,'','info',NULL,NULL),
(83,1762273125,1,2,1,'tt_content',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.5','{\"table\":\"tt_content\",\"uid\":1,\"history\":0}',1,0,'',0,'','info',NULL,NULL),
(84,1762273157,1,2,1,'tt_content',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.5','{\"table\":\"tt_content\",\"uid\":1,\"history\":\"15\"}',1,0,'',0,'','info',NULL,NULL),
(85,1762273157,1,2,2,'sys_file_reference',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.5','{\"table\":\"sys_file_reference\",\"uid\":2,\"history\":\"16\"}',1,0,'',0,'','info',NULL,NULL),
(86,1762273282,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.5','{\"username\":\"admin\",\"command\":\"all\"}',-1,0,'',0,'','info',NULL,NULL),
(87,1762273624,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.5','{\"username\":\"admin\",\"command\":\"all\"}',-1,0,'',0,'','info',NULL,NULL),
(88,1762273638,1,2,1,'pages',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.5','{\"table\":\"pages\",\"uid\":1,\"history\":\"17\"}',0,0,'',0,'','info',NULL,NULL),
(89,1762273638,1,3,1,'sys_file_reference',0,0,'Record {table}:{uid} was deleted from pages:{pid}',1,'content',0,'172.18.0.5','{\"table\":\"sys_file_reference\",\"uid\":1,\"pid\":1}',1,0,'',0,'','info',NULL,NULL),
(90,1762414049,1,1,0,'',0,0,'User %s logged in from ###IP###',255,'user',0,'172.18.0.5','[\"admin\"]',-1,-99,'',0,'','info',NULL,NULL),
(91,1762416826,1,1,4,'pages',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content',0,'172.18.0.5','{\"table\":\"pages\",\"uid\":4,\"pid\":1}',1,0,'',0,'','info',NULL,NULL),
(92,1762416828,1,2,4,'pages',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.5','{\"table\":\"pages\",\"uid\":4,\"history\":\"20\"}',1,0,'',0,'','info',NULL,NULL),
(93,1762416924,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.5','{\"username\":\"admin\",\"command\":\"all\"}',-1,0,'',0,'','info',NULL,NULL),
(94,1762416979,1,1,2,'tt_content',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content',0,'172.18.0.5','{\"table\":\"tt_content\",\"uid\":2,\"pid\":4}',4,0,'',0,'','info',NULL,NULL),
(95,1762417203,1,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: Undeclared arguments passed to ViewHelper TYPO3\\CMS\\Fluid\\ViewHelpers\\CObjectViewHelper: id. Valid arguments are: data, typoscriptObjectPath, currentValueKey, table | TYPO3Fluid\\Fluid\\Core\\ViewHelper\\Exception thrown in file /var/www/html/vendor/typo3fluid/fluid/src/Core/ViewHelper/AbstractViewHelper.php in line 466. Requested URL: https://raffael.ddev.site/',5,'php',0,'172.18.0.5','',-1,0,'',0,'','error',NULL,NULL),
(96,1762417535,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.5','{\"username\":\"admin\",\"command\":\"all\"}',-1,0,'',0,'','info',NULL,NULL),
(97,1762417838,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.5','{\"username\":\"admin\",\"command\":\"all\"}',-1,0,'',0,'','info',NULL,NULL),
(98,1762417847,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.5','{\"username\":\"admin\",\"command\":\"all\"}',-1,0,'',0,'','info',NULL,NULL),
(99,1762418233,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.5','{\"username\":\"admin\",\"command\":\"all\"}',-1,0,'',0,'','info',NULL,NULL),
(100,1762418333,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.5','{\"username\":\"admin\",\"command\":\"all\"}',-1,0,'',0,'','info',NULL,NULL),
(101,1762418694,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.5','{\"username\":\"admin\",\"command\":\"all\"}',-1,0,'',0,'','info',NULL,NULL),
(102,1762418707,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.5','{\"username\":\"admin\",\"command\":\"all\"}',-1,0,'',0,'','info',NULL,NULL),
(103,1762418720,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.5','{\"username\":\"admin\",\"command\":\"all\"}',-1,0,'',0,'','info',NULL,NULL),
(104,1762418721,1,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1540246570: No Content Object definition found at TypoScript object path \"lib.renderAnyRecord\" | TYPO3Fluid\\Fluid\\Core\\ViewHelper\\Exception thrown in file /var/www/html/vendor/typo3/cms-fluid/Classes/ViewHelpers/CObjectViewHelper.php in line 114. Requested URL: https://raffael.ddev.site/',5,'php',0,'172.18.0.5','',-1,0,'',0,'','error',NULL,NULL),
(105,1762418732,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.5','{\"username\":\"admin\",\"command\":\"all\"}',-1,0,'',0,'','info',NULL,NULL),
(106,1762418773,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.5','{\"username\":\"admin\",\"command\":\"all\"}',-1,0,'',0,'','info',NULL,NULL),
(107,1762418784,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.5','{\"username\":\"admin\",\"command\":\"all\"}',-1,0,'',0,'','info',NULL,NULL),
(108,1762418887,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.5','{\"username\":\"admin\",\"command\":\"all\"}',-1,0,'',0,'','info',NULL,NULL),
(109,1762419030,1,1,5,'pages',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content',0,'172.18.0.5','{\"table\":\"pages\",\"uid\":5,\"pid\":1}',1,0,'',0,'','info',NULL,NULL),
(110,1762419032,1,2,5,'pages',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.5','{\"table\":\"pages\",\"uid\":5,\"history\":\"23\"}',1,0,'',0,'','info',NULL,NULL),
(111,1762419035,1,2,5,'pages',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.5','{\"table\":\"pages\",\"uid\":5,\"history\":\"24\"}',1,0,'',0,'','info',NULL,NULL),
(112,1762422668,1,1,3,'tt_content',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content',0,'172.18.0.5','{\"table\":\"tt_content\",\"uid\":3,\"pid\":1}',1,0,'',0,'','info',NULL,NULL),
(113,1762422668,1,1,3,'sys_file_reference',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content',0,'172.18.0.5','{\"table\":\"sys_file_reference\",\"uid\":3,\"pid\":1}',1,0,'',0,'','info',NULL,NULL),
(114,1762422668,1,2,3,'tt_content',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.5','{\"table\":\"tt_content\",\"uid\":3,\"history\":0}',1,0,'',0,'','info',NULL,NULL),
(115,1762422672,1,3,2,'sys_file_reference',0,0,'Record {table}:{uid} was deleted from pages:{pid}',1,'content',0,'172.18.0.5','{\"table\":\"sys_file_reference\",\"uid\":2,\"pid\":1}',1,0,'',0,'','info',NULL,NULL),
(116,1762422672,1,3,1,'tt_content',0,0,'Record {table}:{uid} was deleted from pages:{pid}',1,'content',0,'172.18.0.5','{\"table\":\"tt_content\",\"uid\":1,\"pid\":1}',1,0,'',0,'','info',NULL,NULL),
(117,1762422678,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.5','{\"username\":\"admin\",\"command\":\"all\"}',-1,0,'',0,'','info',NULL,NULL),
(118,1762423246,1,1,4,'sys_file_reference',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content',0,'172.18.0.5','{\"table\":\"sys_file_reference\",\"uid\":4,\"pid\":1}',1,0,'',0,'','info',NULL,NULL),
(119,1762423246,1,1,4,'tt_content',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content',0,'172.18.0.5','{\"table\":\"tt_content\",\"uid\":4,\"pid\":1}',1,0,'',0,'','info',NULL,NULL),
(120,1762423246,1,2,4,'tt_content',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.5','{\"table\":\"tt_content\",\"uid\":4,\"history\":0}',1,0,'',0,'','info',NULL,NULL),
(121,1762423246,1,2,4,'tt_content',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.5','{\"table\":\"tt_content\",\"uid\":4,\"history\":\"31\"}',1,0,'',0,'','info',NULL,NULL),
(122,1762423271,1,2,4,'tt_content',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.5','{\"table\":\"tt_content\",\"uid\":4,\"history\":\"32\"}',1,0,'',0,'','info',NULL,NULL),
(123,1762423380,1,1,0,'',0,0,'Uploading file \"{identifier}\" to \"{destination}\"',2,'file',0,'172.18.0.5','{\"identifier\":\"test.jpg\",\"destination\":\"\\/user_upload\\/\"}',-1,0,'',0,'','info',NULL,NULL),
(124,1762423393,1,2,4,'tt_content',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.5','{\"table\":\"tt_content\",\"uid\":4,\"history\":\"33\"}',1,0,'',0,'','info',NULL,NULL),
(125,1762423393,1,1,5,'sys_file_reference',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content',0,'172.18.0.5','{\"table\":\"sys_file_reference\",\"uid\":5,\"pid\":1}',1,0,'',0,'','info',NULL,NULL),
(126,1762423393,1,2,4,'tt_content',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.5','{\"table\":\"tt_content\",\"uid\":4,\"history\":\"35\"}',1,0,'',0,'','info',NULL,NULL),
(127,1762423393,1,3,4,'sys_file_reference',0,0,'Record {table}:{uid} was deleted from pages:{pid}',1,'content',0,'172.18.0.5','{\"table\":\"sys_file_reference\",\"uid\":4,\"pid\":1}',1,0,'',0,'','info',NULL,NULL),
(128,1762423420,1,1,6,'sys_file_reference',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content',0,'172.18.0.5','{\"table\":\"sys_file_reference\",\"uid\":6,\"pid\":1}',1,0,'',0,'','info',NULL,NULL),
(129,1762423420,1,1,5,'tt_content',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content',0,'172.18.0.5','{\"table\":\"tt_content\",\"uid\":5,\"pid\":1}',1,0,'',0,'','info',NULL,NULL),
(130,1762423420,1,2,5,'tt_content',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.5','{\"table\":\"tt_content\",\"uid\":5,\"history\":0}',1,0,'',0,'','info',NULL,NULL),
(131,1762423420,1,2,5,'tt_content',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.5','{\"table\":\"tt_content\",\"uid\":5,\"history\":\"39\"}',1,0,'',0,'','info',NULL,NULL),
(132,1762423422,1,1,7,'sys_file_reference',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content',0,'172.18.0.5','{\"table\":\"sys_file_reference\",\"uid\":7,\"pid\":1}',1,0,'',0,'','info',NULL,NULL),
(133,1762423422,1,1,6,'tt_content',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content',0,'172.18.0.5','{\"table\":\"tt_content\",\"uid\":6,\"pid\":1}',1,0,'',0,'','info',NULL,NULL),
(134,1762423422,1,2,6,'tt_content',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.5','{\"table\":\"tt_content\",\"uid\":6,\"history\":0}',1,0,'',0,'','info',NULL,NULL),
(135,1762423422,1,2,6,'tt_content',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.5','{\"table\":\"tt_content\",\"uid\":6,\"history\":\"42\"}',1,0,'',0,'','info',NULL,NULL),
(136,1762423423,1,2,6,'tt_content',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.5','{\"table\":\"tt_content\",\"uid\":6,\"history\":\"43\"}',1,0,'',0,'','info',NULL,NULL),
(137,1762423425,1,2,5,'tt_content',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.5','{\"table\":\"tt_content\",\"uid\":5,\"history\":\"44\"}',1,0,'',0,'','info',NULL,NULL),
(138,1762425054,1,1,7,'tt_content',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content',0,'172.18.0.5','{\"table\":\"tt_content\",\"uid\":7,\"pid\":2}',2,0,'',0,'','info',NULL,NULL),
(139,1762425059,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.5','{\"username\":\"admin\",\"command\":\"all\"}',-1,0,'',0,'','info',NULL,NULL),
(140,1762425213,1,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1509741912: Unable to render image tag in \"tt_content:7\": Resolved file object type TYPO3\\CMS\\Core\\Resource\\ProcessedFile for /fileadmin/_processed_/5/4/csm_elo_4e2b01691a.jpg must be File or FileReference. | TYPO3Fluid\\Fluid\\Core\\ViewHelper\\Exception thrown in file /var/www/html/vendor/typo3/cms-fluid/Classes/ViewHelpers/ImageViewHelper.php in line 169. Requested URL: https://raffael.ddev.site/work',5,'php',0,'172.18.0.5','',-1,0,'',0,'','error',NULL,NULL),
(141,1762432121,1,1,6,'pages',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content',0,'172.18.0.5','{\"table\":\"pages\",\"uid\":6,\"pid\":2}',2,0,'',0,'','info',NULL,NULL),
(142,1762432124,1,2,6,'pages',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.5','{\"table\":\"pages\",\"uid\":6,\"history\":\"47\"}',2,0,'',0,'','info',NULL,NULL),
(143,1762432187,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.5','{\"username\":\"admin\",\"command\":\"all\"}',-1,0,'',0,'','info',NULL,NULL),
(144,1762432204,1,6,0,'',0,0,'Directory \"{identifier}\" created in \"{destination}\"',2,'file',0,'172.18.0.5','{\"identifier\":\"Cases\",\"destination\":\"\\/user_upload\\/\"}',-1,0,'',0,'','info',NULL,NULL),
(145,1762432210,1,6,0,'',0,0,'Directory \"{identifier}\" created in \"{destination}\"',2,'file',0,'172.18.0.5','{\"identifier\":\"Case nr1\",\"destination\":\"\\/user_upload\\/Cases\\/\"}',-1,0,'',0,'','info',NULL,NULL),
(146,1762432234,1,1,0,'',0,0,'Uploading file \"{identifier}\" to \"{destination}\"',2,'file',0,'172.18.0.5','{\"identifier\":\"R-1.png\",\"destination\":\"\\/user_upload\\/Cases\\/Case_nr1\\/\"}',-1,0,'',0,'','info',NULL,NULL),
(147,1762432234,1,1,0,'',0,0,'Uploading file \"{identifier}\" to \"{destination}\"',2,'file',0,'172.18.0.5','{\"identifier\":\"R-2.png\",\"destination\":\"\\/user_upload\\/Cases\\/Case_nr1\\/\"}',-1,0,'',0,'','info',NULL,NULL),
(148,1762432234,1,1,0,'',0,0,'Uploading file \"{identifier}\" to \"{destination}\"',2,'file',0,'172.18.0.5','{\"identifier\":\"R-3.png\",\"destination\":\"\\/user_upload\\/Cases\\/Case_nr1\\/\"}',-1,0,'',0,'','info',NULL,NULL),
(149,1762432234,1,1,0,'',0,0,'Uploading file \"{identifier}\" to \"{destination}\"',2,'file',0,'172.18.0.5','{\"identifier\":\"R0004824.png\",\"destination\":\"\\/user_upload\\/Cases\\/Case_nr1\\/\"}',-1,0,'',0,'','info',NULL,NULL),
(150,1762432234,1,1,0,'',0,0,'Uploading file \"{identifier}\" to \"{destination}\"',2,'file',0,'172.18.0.5','{\"identifier\":\"R0005129.png\",\"destination\":\"\\/user_upload\\/Cases\\/Case_nr1\\/\"}',-1,0,'',0,'','info',NULL,NULL),
(151,1762432251,1,1,8,'tt_content',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content',0,'172.18.0.5','{\"table\":\"tt_content\",\"uid\":8,\"pid\":6}',6,0,'',0,'','info',NULL,NULL),
(152,1762432251,1,1,8,'sys_file_reference',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content',0,'172.18.0.5','{\"table\":\"sys_file_reference\",\"uid\":8,\"pid\":6}',6,0,'',0,'','info',NULL,NULL),
(153,1762432251,1,1,9,'sys_file_reference',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content',0,'172.18.0.5','{\"table\":\"sys_file_reference\",\"uid\":9,\"pid\":6}',6,0,'',0,'','info',NULL,NULL),
(154,1762432251,1,1,10,'sys_file_reference',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content',0,'172.18.0.5','{\"table\":\"sys_file_reference\",\"uid\":10,\"pid\":6}',6,0,'',0,'','info',NULL,NULL),
(155,1762432251,1,1,11,'sys_file_reference',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content',0,'172.18.0.5','{\"table\":\"sys_file_reference\",\"uid\":11,\"pid\":6}',6,0,'',0,'','info',NULL,NULL),
(156,1762432251,1,1,12,'sys_file_reference',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content',0,'172.18.0.5','{\"table\":\"sys_file_reference\",\"uid\":12,\"pid\":6}',6,0,'',0,'','info',NULL,NULL),
(157,1762432251,1,2,8,'tt_content',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.5','{\"table\":\"tt_content\",\"uid\":8,\"history\":0}',6,0,'',0,'','info',NULL,NULL),
(158,1762432859,1,2,8,'tt_content',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.5','{\"table\":\"tt_content\",\"uid\":8,\"history\":\"54\"}',6,0,'',0,'','info',NULL,NULL),
(159,1762432859,1,2,8,'sys_file_reference',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.5','{\"table\":\"sys_file_reference\",\"uid\":8,\"history\":\"55\"}',6,0,'',0,'','info',NULL,NULL),
(160,1762432859,1,2,9,'sys_file_reference',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.5','{\"table\":\"sys_file_reference\",\"uid\":9,\"history\":\"56\"}',6,0,'',0,'','info',NULL,NULL),
(161,1762432859,1,2,10,'sys_file_reference',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.5','{\"table\":\"sys_file_reference\",\"uid\":10,\"history\":\"57\"}',6,0,'',0,'','info',NULL,NULL),
(162,1762432859,1,2,11,'sys_file_reference',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.5','{\"table\":\"sys_file_reference\",\"uid\":11,\"history\":\"58\"}',6,0,'',0,'','info',NULL,NULL),
(163,1762432859,1,2,12,'sys_file_reference',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.5','{\"table\":\"sys_file_reference\",\"uid\":12,\"history\":\"59\"}',6,0,'',0,'','info',NULL,NULL),
(164,1762432949,1,2,8,'tt_content',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.5','{\"table\":\"tt_content\",\"uid\":8,\"history\":\"60\"}',6,0,'',0,'','info',NULL,NULL),
(165,1762434894,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.5','{\"username\":\"admin\",\"command\":\"all\"}',-1,0,'',0,'','info',NULL,NULL),
(166,1762434972,1,2,7,'tt_content',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.5','{\"table\":\"tt_content\",\"uid\":7,\"history\":\"61\"}',2,0,'',0,'','info',NULL,NULL),
(167,1762434972,1,1,1,'tx_mask_all_cases',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content',0,'172.18.0.5','{\"table\":\"tx_mask_all_cases\",\"uid\":1,\"pid\":2}',2,0,'',0,'','info',NULL,NULL),
(168,1762434972,1,1,13,'sys_file_reference',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content',0,'172.18.0.5','{\"table\":\"sys_file_reference\",\"uid\":13,\"pid\":2}',2,0,'',0,'','info',NULL,NULL),
(169,1762434972,1,2,7,'tt_content',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.5','{\"table\":\"tt_content\",\"uid\":7,\"history\":\"64\"}',2,0,'',0,'','info',NULL,NULL),
(170,1762434972,1,2,1,'tx_mask_all_cases',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.5','{\"table\":\"tx_mask_all_cases\",\"uid\":1,\"history\":0}',2,0,'',0,'','info',NULL,NULL),
(171,1762435002,1,2,7,'tt_content',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.5','{\"table\":\"tt_content\",\"uid\":7,\"history\":0}',2,0,'',0,'','info',NULL,NULL),
(172,1762435002,1,2,1,'tx_mask_all_cases',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.5','{\"table\":\"tx_mask_all_cases\",\"uid\":1,\"history\":\"65\"}',2,0,'',0,'','info',NULL,NULL),
(173,1762435002,1,2,13,'sys_file_reference',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.5','{\"table\":\"sys_file_reference\",\"uid\":13,\"history\":\"66\"}',2,0,'',0,'','info',NULL,NULL),
(174,1762435038,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.5','{\"username\":\"admin\",\"command\":\"all\"}',-1,0,'',0,'','info',NULL,NULL),
(175,1762435207,1,2,7,'tt_content',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.5','{\"table\":\"tt_content\",\"uid\":7,\"history\":0}',2,0,'',0,'','info',NULL,NULL),
(176,1762435207,1,2,1,'tx_mask_all_cases',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.5','{\"table\":\"tx_mask_all_cases\",\"uid\":1,\"history\":\"67\"}',2,0,'',0,'','info',NULL,NULL),
(177,1762435256,1,1,1,'sys_category',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content',0,'172.18.0.5','{\"table\":\"sys_category\",\"uid\":1,\"pid\":2}',2,0,'',0,'','info',NULL,NULL),
(178,1762435264,1,1,2,'sys_category',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content',0,'172.18.0.5','{\"table\":\"sys_category\",\"uid\":2,\"pid\":2}',2,0,'',0,'','info',NULL,NULL),
(179,1762435267,1,2,2,'sys_category',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.5','{\"table\":\"sys_category\",\"uid\":2,\"history\":\"70\"}',2,0,'',0,'','info',NULL,NULL),
(180,1762435277,1,2,2,'sys_category',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.5','{\"table\":\"sys_category\",\"uid\":2,\"history\":\"71\"}',2,0,'',0,'','info',NULL,NULL),
(181,1762435299,1,2,2,'sys_category',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.5','{\"table\":\"sys_category\",\"uid\":2,\"history\":\"72\"}',2,0,'',0,'','info',NULL,NULL),
(182,1762435305,1,1,3,'sys_category',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content',0,'172.18.0.5','{\"table\":\"sys_category\",\"uid\":3,\"pid\":2}',2,0,'',0,'','info',NULL,NULL),
(183,1762435308,1,1,4,'sys_category',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content',0,'172.18.0.5','{\"table\":\"sys_category\",\"uid\":4,\"pid\":2}',2,0,'',0,'','info',NULL,NULL),
(184,1762435332,1,2,7,'tt_content',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.5','{\"table\":\"tt_content\",\"uid\":7,\"history\":0}',2,0,'',0,'','info',NULL,NULL),
(185,1762435332,1,2,1,'tx_mask_all_cases',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.5','{\"table\":\"tx_mask_all_cases\",\"uid\":1,\"history\":\"75\"}',2,0,'',0,'','info',NULL,NULL),
(186,1762435332,1,2,13,'sys_file_reference',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.5','{\"table\":\"sys_file_reference\",\"uid\":13,\"history\":\"76\"}',2,0,'',0,'','info',NULL,NULL),
(187,1762437321,1,2,7,'tt_content',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.5','{\"table\":\"tt_content\",\"uid\":7,\"history\":0}',2,0,'',0,'','info',NULL,NULL),
(188,1762437321,1,2,1,'tx_mask_all_cases',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.5','{\"table\":\"tx_mask_all_cases\",\"uid\":1,\"history\":0}',2,0,'',0,'','info',NULL,NULL),
(189,1762437321,1,1,2,'tx_mask_all_cases',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content',0,'172.18.0.5','{\"table\":\"tx_mask_all_cases\",\"uid\":2,\"pid\":2}',2,0,'',0,'','info',NULL,NULL),
(190,1762437321,1,1,14,'sys_file_reference',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content',0,'172.18.0.5','{\"table\":\"sys_file_reference\",\"uid\":14,\"pid\":2}',2,0,'',0,'','info',NULL,NULL),
(191,1762437321,1,2,7,'tt_content',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.5','{\"table\":\"tt_content\",\"uid\":7,\"history\":0}',2,0,'',0,'','info',NULL,NULL),
(192,1762437321,1,2,2,'tx_mask_all_cases',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.5','{\"table\":\"tx_mask_all_cases\",\"uid\":2,\"history\":0}',2,0,'',0,'','info',NULL,NULL),
(193,1762437355,1,2,7,'tt_content',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.5','{\"table\":\"tt_content\",\"uid\":7,\"history\":0}',2,0,'',0,'','info',NULL,NULL),
(194,1762437355,1,2,1,'tx_mask_all_cases',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.5','{\"table\":\"tx_mask_all_cases\",\"uid\":1,\"history\":\"79\"}',2,0,'',0,'','info',NULL,NULL),
(195,1762437355,1,2,2,'tx_mask_all_cases',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.5','{\"table\":\"tx_mask_all_cases\",\"uid\":2,\"history\":\"80\"}',2,0,'',0,'','info',NULL,NULL),
(196,1762437355,1,1,3,'tx_mask_all_cases',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content',0,'172.18.0.5','{\"table\":\"tx_mask_all_cases\",\"uid\":3,\"pid\":2}',2,0,'',0,'','info',NULL,NULL),
(197,1762437355,1,2,14,'sys_file_reference',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.5','{\"table\":\"sys_file_reference\",\"uid\":14,\"history\":\"82\"}',2,0,'',0,'','info',NULL,NULL),
(198,1762437355,1,1,15,'sys_file_reference',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content',0,'172.18.0.5','{\"table\":\"sys_file_reference\",\"uid\":15,\"pid\":2}',2,0,'',0,'','info',NULL,NULL),
(199,1762437355,1,2,7,'tt_content',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.5','{\"table\":\"tt_content\",\"uid\":7,\"history\":0}',2,0,'',0,'','info',NULL,NULL),
(200,1762437355,1,2,3,'tx_mask_all_cases',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.5','{\"table\":\"tx_mask_all_cases\",\"uid\":3,\"history\":0}',2,0,'',0,'','info',NULL,NULL),
(201,1762437772,1,2,7,'tt_content',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.5','{\"table\":\"tt_content\",\"uid\":7,\"history\":0}',2,0,'',0,'','info',NULL,NULL),
(202,1762437772,1,2,2,'tx_mask_all_cases',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.5','{\"table\":\"tx_mask_all_cases\",\"uid\":2,\"history\":\"84\"}',2,0,'',0,'','info',NULL,NULL),
(203,1762437772,1,2,3,'tx_mask_all_cases',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.5','{\"table\":\"tx_mask_all_cases\",\"uid\":3,\"history\":\"85\"}',2,0,'',0,'','info',NULL,NULL),
(204,1762437772,1,1,4,'tx_mask_all_cases',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content',0,'172.18.0.5','{\"table\":\"tx_mask_all_cases\",\"uid\":4,\"pid\":2}',2,0,'',0,'','info',NULL,NULL),
(205,1762437772,1,2,15,'sys_file_reference',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.5','{\"table\":\"sys_file_reference\",\"uid\":15,\"history\":\"87\"}',2,0,'',0,'','info',NULL,NULL),
(206,1762437772,1,1,16,'sys_file_reference',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content',0,'172.18.0.5','{\"table\":\"sys_file_reference\",\"uid\":16,\"pid\":2}',2,0,'',0,'','info',NULL,NULL),
(207,1762437772,1,2,7,'tt_content',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.5','{\"table\":\"tt_content\",\"uid\":7,\"history\":0}',2,0,'',0,'','info',NULL,NULL),
(208,1762437772,1,2,4,'tx_mask_all_cases',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.5','{\"table\":\"tx_mask_all_cases\",\"uid\":4,\"history\":0}',2,0,'',0,'','info',NULL,NULL),
(209,1762439342,1,2,7,'tt_content',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.5','{\"table\":\"tt_content\",\"uid\":7,\"history\":0}',2,0,'',0,'','info',NULL,NULL),
(210,1762439342,1,2,3,'tx_mask_all_cases',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.5','{\"table\":\"tx_mask_all_cases\",\"uid\":3,\"history\":0}',2,0,'',0,'','info',NULL,NULL),
(211,1762439342,1,2,4,'tx_mask_all_cases',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.5','{\"table\":\"tx_mask_all_cases\",\"uid\":4,\"history\":\"89\"}',2,0,'',0,'','info',NULL,NULL),
(212,1762439342,1,1,5,'tx_mask_all_cases',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content',0,'172.18.0.5','{\"table\":\"tx_mask_all_cases\",\"uid\":5,\"pid\":2}',2,0,'',0,'','info',NULL,NULL),
(213,1762439342,1,2,16,'sys_file_reference',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.5','{\"table\":\"sys_file_reference\",\"uid\":16,\"history\":\"91\"}',2,0,'',0,'','info',NULL,NULL),
(214,1762439342,1,1,17,'sys_file_reference',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content',0,'172.18.0.5','{\"table\":\"sys_file_reference\",\"uid\":17,\"pid\":2}',2,0,'',0,'','info',NULL,NULL),
(215,1762439342,1,2,7,'tt_content',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.5','{\"table\":\"tt_content\",\"uid\":7,\"history\":0}',2,0,'',0,'','info',NULL,NULL),
(216,1762439342,1,2,5,'tx_mask_all_cases',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.5','{\"table\":\"tx_mask_all_cases\",\"uid\":5,\"history\":0}',2,0,'',0,'','info',NULL,NULL),
(217,1762440507,1,2,7,'tt_content',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.5','{\"table\":\"tt_content\",\"uid\":7,\"history\":0}',2,0,'',0,'','info',NULL,NULL),
(218,1762440507,1,2,3,'tx_mask_all_cases',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.5','{\"table\":\"tx_mask_all_cases\",\"uid\":3,\"history\":0}',2,0,'',0,'','info',NULL,NULL),
(219,1762440507,1,2,4,'tx_mask_all_cases',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.5','{\"table\":\"tx_mask_all_cases\",\"uid\":4,\"history\":0}',2,0,'',0,'','info',NULL,NULL),
(220,1762440507,1,2,5,'tx_mask_all_cases',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.5','{\"table\":\"tx_mask_all_cases\",\"uid\":5,\"history\":\"93\"}',2,0,'',0,'','info',NULL,NULL),
(221,1762440507,1,2,17,'sys_file_reference',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.5','{\"table\":\"sys_file_reference\",\"uid\":17,\"history\":\"94\"}',2,0,'',0,'','info',NULL,NULL),
(222,1762441917,1,1,0,'',0,0,'Uploading file \"{identifier}\" to \"{destination}\"',2,'file',0,'172.18.0.5','{\"identifier\":\"Bildschirmfoto 2025-11-06 um 16.11.46.png\",\"destination\":\"\\/user_upload\\/Cases\\/Case_nr1\\/\"}',-1,0,'',0,'','info',NULL,NULL),
(223,1762441921,1,1,9,'tt_content',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content',0,'172.18.0.5','{\"table\":\"tt_content\",\"uid\":9,\"pid\":3}',3,0,'',0,'','info',NULL,NULL),
(224,1762441921,1,1,18,'sys_file_reference',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content',0,'172.18.0.5','{\"table\":\"sys_file_reference\",\"uid\":18,\"pid\":3}',3,0,'',0,'','info',NULL,NULL),
(225,1762441921,1,2,9,'tt_content',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.5','{\"table\":\"tt_content\",\"uid\":9,\"history\":0}',3,0,'',0,'','info',NULL,NULL),
(226,1762441926,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.5','{\"username\":\"admin\",\"command\":\"all\"}',-1,0,'',0,'','info',NULL,NULL),
(227,1762442309,1,2,9,'tt_content',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.5','{\"table\":\"tt_content\",\"uid\":9,\"history\":\"97\"}',3,0,'',0,'','info',NULL,NULL),
(228,1762442309,1,2,18,'sys_file_reference',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.5','{\"table\":\"sys_file_reference\",\"uid\":18,\"history\":\"98\"}',3,0,'',0,'','info',NULL,NULL),
(229,1762442507,1,2,7,'tt_content',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.5','{\"table\":\"tt_content\",\"uid\":7,\"history\":0}',2,0,'',0,'','info',NULL,NULL),
(230,1762442507,1,2,3,'tx_mask_all_cases',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.5','{\"table\":\"tx_mask_all_cases\",\"uid\":3,\"history\":\"99\"}',2,0,'',0,'','info',NULL,NULL),
(231,1762442507,1,2,4,'tx_mask_all_cases',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.5','{\"table\":\"tx_mask_all_cases\",\"uid\":4,\"history\":0}',2,0,'',0,'','info',NULL,NULL),
(232,1762442507,1,2,5,'tx_mask_all_cases',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.5','{\"table\":\"tx_mask_all_cases\",\"uid\":5,\"history\":0}',2,0,'',0,'','info',NULL,NULL),
(233,1762442507,1,1,19,'sys_file_reference',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content',0,'172.18.0.5','{\"table\":\"sys_file_reference\",\"uid\":19,\"pid\":2}',2,0,'',0,'','info',NULL,NULL),
(234,1762442507,1,2,5,'tx_mask_all_cases',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.5','{\"table\":\"tx_mask_all_cases\",\"uid\":5,\"history\":0}',2,0,'',0,'','info',NULL,NULL),
(235,1762442507,1,3,17,'sys_file_reference',0,0,'Record {table}:{uid} was deleted from pages:{pid}',1,'content',0,'172.18.0.5','{\"table\":\"sys_file_reference\",\"uid\":17,\"pid\":2}',2,0,'',0,'','info',NULL,NULL),
(236,1762442661,1,2,7,'tt_content',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.5','{\"table\":\"tt_content\",\"uid\":7,\"history\":0}',2,0,'',0,'','info',NULL,NULL),
(237,1762442661,1,2,4,'tx_mask_all_cases',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.5','{\"table\":\"tx_mask_all_cases\",\"uid\":4,\"history\":\"102\"}',2,0,'',0,'','info',NULL,NULL),
(238,1762442661,1,2,5,'tx_mask_all_cases',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.5','{\"table\":\"tx_mask_all_cases\",\"uid\":5,\"history\":0}',2,0,'',0,'','info',NULL,NULL),
(239,1762442661,1,1,6,'tx_mask_all_cases',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content',0,'172.18.0.5','{\"table\":\"tx_mask_all_cases\",\"uid\":6,\"pid\":2}',2,0,'',0,'','info',NULL,NULL),
(240,1762442661,1,2,19,'sys_file_reference',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.5','{\"table\":\"sys_file_reference\",\"uid\":19,\"history\":\"104\"}',2,0,'',0,'','info',NULL,NULL),
(241,1762442661,1,1,20,'sys_file_reference',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content',0,'172.18.0.5','{\"table\":\"sys_file_reference\",\"uid\":20,\"pid\":2}',2,0,'',0,'','info',NULL,NULL),
(242,1762442661,1,2,7,'tt_content',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.5','{\"table\":\"tt_content\",\"uid\":7,\"history\":0}',2,0,'',0,'','info',NULL,NULL),
(243,1762442661,1,2,6,'tx_mask_all_cases',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.5','{\"table\":\"tx_mask_all_cases\",\"uid\":6,\"history\":0}',2,0,'',0,'','info',NULL,NULL),
(244,1762442717,1,1,0,'',0,0,'Uploading file \"{identifier}\" to \"{destination}\"',2,'file',0,'172.18.0.5','{\"identifier\":\"ada77224d526a050ce627d29a78c8596.jpg\",\"destination\":\"\\/user_upload\\/\"}',-1,0,'',0,'','info',NULL,NULL),
(245,1762442743,1,1,0,'',0,0,'Uploading file \"{identifier}\" to \"{destination}\"',2,'file',0,'172.18.0.5','{\"identifier\":\"82062406_Mood2_47cfd87f-954d-4f12-ba9e-cd7f7cf44187.webp\",\"destination\":\"\\/user_upload\\/\"}',-1,0,'',0,'','info',NULL,NULL),
(246,1762442745,1,2,7,'tt_content',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.5','{\"table\":\"tt_content\",\"uid\":7,\"history\":0}',2,0,'',0,'','info',NULL,NULL),
(247,1762442745,1,2,1,'tx_mask_all_cases',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.5','{\"table\":\"tx_mask_all_cases\",\"uid\":1,\"history\":\"106\"}',2,0,'',0,'','info',NULL,NULL),
(248,1762442745,1,2,2,'tx_mask_all_cases',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.5','{\"table\":\"tx_mask_all_cases\",\"uid\":2,\"history\":\"107\"}',2,0,'',0,'','info',NULL,NULL),
(249,1762442745,1,2,5,'tx_mask_all_cases',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.5','{\"table\":\"tx_mask_all_cases\",\"uid\":5,\"history\":0}',2,0,'',0,'','info',NULL,NULL),
(250,1762442745,1,2,6,'tx_mask_all_cases',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.5','{\"table\":\"tx_mask_all_cases\",\"uid\":6,\"history\":\"108\"}',2,0,'',0,'','info',NULL,NULL),
(251,1762442745,1,1,21,'sys_file_reference',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content',0,'172.18.0.5','{\"table\":\"sys_file_reference\",\"uid\":21,\"pid\":2}',2,0,'',0,'','info',NULL,NULL),
(252,1762442745,1,1,22,'sys_file_reference',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content',0,'172.18.0.5','{\"table\":\"sys_file_reference\",\"uid\":22,\"pid\":2}',2,0,'',0,'','info',NULL,NULL),
(253,1762442745,1,2,20,'sys_file_reference',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.5','{\"table\":\"sys_file_reference\",\"uid\":20,\"history\":\"111\"}',2,0,'',0,'','info',NULL,NULL),
(254,1762442745,1,2,1,'tx_mask_all_cases',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.5','{\"table\":\"tx_mask_all_cases\",\"uid\":1,\"history\":\"112\"}',2,0,'',0,'','info',NULL,NULL),
(255,1762442745,1,2,2,'tx_mask_all_cases',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.5','{\"table\":\"tx_mask_all_cases\",\"uid\":2,\"history\":\"113\"}',2,0,'',0,'','info',NULL,NULL),
(256,1762442745,1,3,13,'sys_file_reference',0,0,'Record {table}:{uid} was deleted from pages:{pid}',1,'content',0,'172.18.0.5','{\"table\":\"sys_file_reference\",\"uid\":13,\"pid\":2}',2,0,'',0,'','info',NULL,NULL),
(257,1762442745,1,3,14,'sys_file_reference',0,0,'Record {table}:{uid} was deleted from pages:{pid}',1,'content',0,'172.18.0.5','{\"table\":\"sys_file_reference\",\"uid\":14,\"pid\":2}',2,0,'',0,'','info',NULL,NULL),
(258,1762442860,1,1,0,'',0,0,'Uploading file \"{identifier}\" to \"{destination}\"',2,'file',0,'172.18.0.5','{\"identifier\":\"d25f377994b383efcf8332f56d0a61b1.jpg\",\"destination\":\"\\/user_upload\\/\"}',-1,0,'',0,'','info',NULL,NULL),
(259,1762442865,1,2,7,'tt_content',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.5','{\"table\":\"tt_content\",\"uid\":7,\"history\":0}',2,0,'',0,'','info',NULL,NULL),
(260,1762442865,1,2,1,'tx_mask_all_cases',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.5','{\"table\":\"tx_mask_all_cases\",\"uid\":1,\"history\":0}',2,0,'',0,'','info',NULL,NULL),
(261,1762442865,1,2,2,'tx_mask_all_cases',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.5','{\"table\":\"tx_mask_all_cases\",\"uid\":2,\"history\":0}',2,0,'',0,'','info',NULL,NULL),
(262,1762442865,1,2,3,'tx_mask_all_cases',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.5','{\"table\":\"tx_mask_all_cases\",\"uid\":3,\"history\":\"116\"}',2,0,'',0,'','info',NULL,NULL),
(263,1762442865,1,2,5,'tx_mask_all_cases',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.5','{\"table\":\"tx_mask_all_cases\",\"uid\":5,\"history\":0}',2,0,'',0,'','info',NULL,NULL),
(264,1762442865,1,2,6,'tx_mask_all_cases',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.5','{\"table\":\"tx_mask_all_cases\",\"uid\":6,\"history\":0}',2,0,'',0,'','info',NULL,NULL),
(265,1762442865,1,2,21,'sys_file_reference',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.5','{\"table\":\"sys_file_reference\",\"uid\":21,\"history\":\"117\"}',2,0,'',0,'','info',NULL,NULL),
(266,1762442865,1,2,22,'sys_file_reference',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.5','{\"table\":\"sys_file_reference\",\"uid\":22,\"history\":\"118\"}',2,0,'',0,'','info',NULL,NULL),
(267,1762442865,1,1,23,'sys_file_reference',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content',0,'172.18.0.5','{\"table\":\"sys_file_reference\",\"uid\":23,\"pid\":2}',2,0,'',0,'','info',NULL,NULL),
(268,1762442865,1,2,3,'tx_mask_all_cases',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.5','{\"table\":\"tx_mask_all_cases\",\"uid\":3,\"history\":\"120\"}',2,0,'',0,'','info',NULL,NULL),
(269,1762442865,1,3,15,'sys_file_reference',0,0,'Record {table}:{uid} was deleted from pages:{pid}',1,'content',0,'172.18.0.5','{\"table\":\"sys_file_reference\",\"uid\":15,\"pid\":2}',2,0,'',0,'','info',NULL,NULL),
(270,1762443238,1,2,7,'tt_content',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.5','{\"table\":\"tt_content\",\"uid\":7,\"history\":0}',2,0,'',0,'','info',NULL,NULL),
(271,1762443238,1,2,1,'tx_mask_all_cases',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.5','{\"table\":\"tx_mask_all_cases\",\"uid\":1,\"history\":0}',2,0,'',0,'','info',NULL,NULL),
(272,1762443238,1,2,2,'tx_mask_all_cases',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.5','{\"table\":\"tx_mask_all_cases\",\"uid\":2,\"history\":\"122\"}',2,0,'',0,'','info',NULL,NULL),
(273,1762443238,1,2,3,'tx_mask_all_cases',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.5','{\"table\":\"tx_mask_all_cases\",\"uid\":3,\"history\":0}',2,0,'',0,'','info',NULL,NULL),
(274,1762443238,1,2,5,'tx_mask_all_cases',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.5','{\"table\":\"tx_mask_all_cases\",\"uid\":5,\"history\":0}',2,0,'',0,'','info',NULL,NULL),
(275,1762443238,1,2,6,'tx_mask_all_cases',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.5','{\"table\":\"tx_mask_all_cases\",\"uid\":6,\"history\":0}',2,0,'',0,'','info',NULL,NULL),
(276,1762443238,1,2,23,'sys_file_reference',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.5','{\"table\":\"sys_file_reference\",\"uid\":23,\"history\":\"123\"}',2,0,'',0,'','info',NULL,NULL),
(277,1762443398,1,4,4,'sys_category',0,0,'Moved record {table}:{uid} on page {pid}',1,'content',0,'172.18.0.5','{\"table\":\"sys_category\",\"uid\":4,\"pid\":2}',2,0,'',0,'','info',NULL,NULL),
(278,1762443411,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.5','{\"username\":\"admin\",\"command\":\"all\"}',-1,0,'',0,'','info',NULL,NULL),
(279,1762443420,1,4,3,'sys_category',0,0,'Moved record {table}:{uid} on page {pid}',1,'content',0,'172.18.0.5','{\"table\":\"sys_category\",\"uid\":3,\"pid\":2}',2,0,'',0,'','info',NULL,NULL),
(280,1762443431,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.5','{\"username\":\"admin\",\"command\":\"all\"}',-1,0,'',0,'','info',NULL,NULL),
(281,1762444507,1,1,0,'',0,0,'Uploading file \"{identifier}\" to \"{destination}\"',2,'file',0,'172.18.0.5','{\"identifier\":\"Bildschirmfoto 2025-11-06 um 16.54.31.png\",\"destination\":\"\\/user_upload\\/\"}',-1,0,'',0,'','info',NULL,NULL),
(282,1762444509,1,2,3,'tt_content',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.5','{\"table\":\"tt_content\",\"uid\":3,\"history\":\"126\"}',1,0,'',0,'','info',NULL,NULL),
(283,1762444509,1,1,24,'sys_file_reference',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content',0,'172.18.0.5','{\"table\":\"sys_file_reference\",\"uid\":24,\"pid\":1}',1,0,'',0,'','info',NULL,NULL),
(284,1762444509,1,2,3,'tt_content',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.5','{\"table\":\"tt_content\",\"uid\":3,\"history\":\"128\"}',1,0,'',0,'','info',NULL,NULL),
(285,1762444509,1,3,3,'sys_file_reference',0,0,'Record {table}:{uid} was deleted from pages:{pid}',1,'content',0,'172.18.0.5','{\"table\":\"sys_file_reference\",\"uid\":3,\"pid\":1}',1,0,'',0,'','info',NULL,NULL),
(286,1762444586,1,1,0,'',0,0,'Uploading file \"{identifier}\" to \"{destination}\"',2,'file',0,'172.18.0.5','{\"identifier\":\"Bildschirmfoto 2025-11-06 um 16.56.14.png\",\"destination\":\"\\/user_upload\\/\"}',-1,0,'',0,'','info',NULL,NULL),
(287,1762444587,1,2,3,'tt_content',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.5','{\"table\":\"tt_content\",\"uid\":3,\"history\":0}',1,0,'',0,'','info',NULL,NULL),
(288,1762444587,1,1,25,'sys_file_reference',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content',0,'172.18.0.5','{\"table\":\"sys_file_reference\",\"uid\":25,\"pid\":1}',1,0,'',0,'','info',NULL,NULL),
(289,1762444587,1,2,3,'tt_content',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.5','{\"table\":\"tt_content\",\"uid\":3,\"history\":0}',1,0,'',0,'','info',NULL,NULL),
(290,1762444587,1,3,24,'sys_file_reference',0,0,'Record {table}:{uid} was deleted from pages:{pid}',1,'content',0,'172.18.0.5','{\"table\":\"sys_file_reference\",\"uid\":24,\"pid\":1}',1,0,'',0,'','info',NULL,NULL),
(291,1762503893,1,1,0,'',0,0,'User %s logged in from ###IP###',255,'user',0,'172.18.0.5','[\"admin\"]',-1,-99,'',0,'','info',NULL,NULL),
(292,1762859332,1,1,0,'',0,0,'User %s logged in from ###IP###',255,'user',0,'172.18.0.5','[\"admin\"]',-1,-99,'',0,'','info',NULL,NULL);
/*!40000 ALTER TABLE `sys_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_messenger_messages`
--

DROP TABLE IF EXISTS `sys_messenger_messages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_messenger_messages` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `body` longtext NOT NULL,
  `headers` longtext NOT NULL,
  `queue_name` varchar(190) NOT NULL,
  `created_at` datetime NOT NULL,
  `available_at` datetime NOT NULL,
  `delivered_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `queue_name` (`queue_name`),
  KEY `available_at` (`available_at`),
  KEY `delivered_at` (`delivered_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_messenger_messages`
--

LOCK TABLES `sys_messenger_messages` WRITE;
/*!40000 ALTER TABLE `sys_messenger_messages` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_messenger_messages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_news`
--

DROP TABLE IF EXISTS `sys_news`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_news` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `title` varchar(255) NOT NULL DEFAULT '',
  `content` longtext DEFAULT NULL,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`,`hidden`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_news`
--

LOCK TABLES `sys_news` WRITE;
/*!40000 ALTER TABLE `sys_news` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_news` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_note`
--

DROP TABLE IF EXISTS `sys_note`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_note` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `sorting` int(11) NOT NULL DEFAULT 0,
  `cruser` int(10) unsigned NOT NULL DEFAULT 0,
  `category` int(10) unsigned NOT NULL DEFAULT 0,
  `subject` varchar(255) NOT NULL DEFAULT '',
  `message` longtext DEFAULT NULL,
  `personal` smallint(5) unsigned NOT NULL DEFAULT 0,
  `position` int(10) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_note`
--

LOCK TABLES `sys_note` WRITE;
/*!40000 ALTER TABLE `sys_note` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_note` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_preview`
--

DROP TABLE IF EXISTS `sys_preview`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_preview` (
  `keyword` varchar(32) NOT NULL DEFAULT '',
  `tstamp` int(11) NOT NULL DEFAULT 0,
  `endtime` int(11) NOT NULL DEFAULT 0,
  `config` text DEFAULT NULL,
  PRIMARY KEY (`keyword`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_preview`
--

LOCK TABLES `sys_preview` WRITE;
/*!40000 ALTER TABLE `sys_preview` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_preview` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_redirect`
--

DROP TABLE IF EXISTS `sys_redirect`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_redirect` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `updatedon` int(10) unsigned NOT NULL DEFAULT 0,
  `createdon` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `disabled` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `description` text DEFAULT NULL,
  `hitcount` int(11) NOT NULL DEFAULT 0,
  `source_host` varchar(255) NOT NULL DEFAULT '',
  `source_path` text NOT NULL DEFAULT '',
  `force_https` smallint(5) unsigned NOT NULL DEFAULT 0,
  `keep_query_parameters` smallint(5) unsigned NOT NULL DEFAULT 0,
  `respect_query_parameters` smallint(5) unsigned NOT NULL DEFAULT 0,
  `target` text NOT NULL DEFAULT '',
  `target_statuscode` int(10) unsigned NOT NULL DEFAULT 0,
  `lasthiton` bigint(20) NOT NULL DEFAULT 0,
  `disable_hitcount` smallint(5) unsigned NOT NULL DEFAULT 0,
  `is_regexp` smallint(5) unsigned NOT NULL DEFAULT 0,
  `protected` smallint(5) unsigned NOT NULL DEFAULT 0,
  `creation_type` int(10) unsigned NOT NULL DEFAULT 0,
  `integrity_status` varchar(180) NOT NULL DEFAULT '',
  PRIMARY KEY (`uid`),
  KEY `index_source` (`source_host`(80),`source_path`(80)),
  KEY `parent` (`pid`,`deleted`,`disabled`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_redirect`
--

LOCK TABLES `sys_redirect` WRITE;
/*!40000 ALTER TABLE `sys_redirect` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_redirect` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_refindex`
--

DROP TABLE IF EXISTS `sys_refindex`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_refindex` (
  `hash` varchar(32) CHARACTER SET ascii COLLATE ascii_bin NOT NULL DEFAULT '',
  `tablename` varchar(64) NOT NULL DEFAULT '',
  `recuid` int(10) unsigned NOT NULL DEFAULT 0,
  `field` varchar(64) NOT NULL DEFAULT '',
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 2147483647,
  `t3ver_state` int(10) unsigned NOT NULL DEFAULT 0,
  `flexpointer` varchar(255) NOT NULL DEFAULT '',
  `softref_key` varchar(30) NOT NULL DEFAULT '',
  `softref_id` varchar(40) NOT NULL DEFAULT '',
  `sorting` int(11) NOT NULL DEFAULT 0,
  `workspace` int(10) unsigned NOT NULL DEFAULT 0,
  `ref_table` varchar(64) NOT NULL DEFAULT '',
  `ref_uid` int(11) NOT NULL DEFAULT 0,
  `ref_field` varchar(64) NOT NULL DEFAULT '',
  `ref_hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `ref_starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `ref_endtime` int(10) unsigned NOT NULL DEFAULT 2147483647,
  `ref_t3ver_state` int(10) unsigned NOT NULL DEFAULT 0,
  `ref_sorting` int(11) NOT NULL DEFAULT 0,
  `ref_string` varchar(1024) NOT NULL DEFAULT '',
  PRIMARY KEY (`hash`),
  KEY `lookup_rec` (`tablename`,`recuid`,`field`,`workspace`,`ref_t3ver_state`,`ref_hidden`,`ref_starttime`,`ref_endtime`),
  KEY `lookup_ref` (`ref_table`,`ref_uid`,`tablename`,`workspace`,`t3ver_state`,`hidden`,`starttime`,`endtime`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_refindex`
--

LOCK TABLES `sys_refindex` WRITE;
/*!40000 ALTER TABLE `sys_refindex` DISABLE KEYS */;
INSERT INTO `sys_refindex` VALUES
('097c243728f05014ede654c1f981e4ab','tx_mask_all_cases',1,'tx_mask_photo_case',0,0,2147483647,0,'','','',0,0,'sys_file_reference',21,'',0,0,2147483647,0,0,''),
('0a897d03bb914d175e32c8da295e9f41','tx_mask_all_cases',5,'tx_mask_photo_case',0,0,2147483647,0,'','','',0,0,'sys_file_reference',19,'',0,0,2147483647,0,0,''),
('0bf776017561335a06e345e6eb9083ed','tt_content',5,'tx_mask_chose_link',0,0,2147483647,0,'','typolink','366b35c5ce3995b5945a693faf4714a8:0',0,0,'pages',2,'',0,0,2147483647,0,0,''),
('0cb7ea8888640e9441e3e32e7d41c46d','tx_mask_all_cases',2,'tx_mask_link_for_image',0,0,2147483647,0,'','typolink','9e5d51705760903b37ce7e2c79753d58:0',0,0,'pages',6,'',0,0,2147483647,0,0,''),
('103c1948b2488fd41064c2450e9baeca','tt_content',7,'tx_mask_all_cases',0,0,2147483647,0,'','','',5,0,'tx_mask_all_cases',6,'',0,0,2147483647,0,0,''),
('13e3f775f5fe55e34e6c3053fc81a294','sys_file',7,'metadata',0,0,2147483647,0,'','','',0,0,'sys_file_metadata',7,'',0,0,2147483647,0,0,''),
('170a60d236441644704b25c84612cacb','tt_content',8,'tx_mask_images_for_this_case',0,0,2147483647,0,'','','',0,0,'sys_file_reference',8,'',0,0,2147483647,0,0,''),
('1891e5b68039b20ea9ed0acf765648c4','sys_file',11,'storage',0,0,2147483647,0,'','','',0,0,'sys_file_storage',1,'',0,0,2147483647,0,0,''),
('1b7a8d394177a34fb71e3b9a1e692a16','sys_file_reference',7,'uid_local',0,0,2147483647,0,'','','',0,0,'sys_file',3,'',0,0,2147483647,0,0,''),
('1e69fc3860920daf3b38a32f2cfda0d7','tt_content',2,'bodytext',0,0,2147483647,0,'','typolink_tag','3',0,0,'_STRING',0,'',0,0,2147483647,0,0,'+41786011099'),
('212d04a3e9e625887852f7211a384e14','tx_mask_all_cases',2,'tx_mask_photo_case',0,0,2147483647,0,'','','',0,0,'sys_file_reference',22,'',0,0,2147483647,0,0,''),
('298d40d3d8c9e9c1421bbc669cbd39f6','tt_content',9,'tx_mask_photo_info',0,0,2147483647,0,'','','',0,0,'sys_file_reference',18,'',0,0,2147483647,0,0,''),
('2c5153ae6102b7d62cd53402fa7ad9e6','sys_file_reference',5,'uid_local',0,0,2147483647,0,'','','',0,0,'sys_file',3,'',0,0,2147483647,0,0,''),
('30450561d873adcc65d07231bb54d318','sys_file',13,'metadata',0,0,2147483647,0,'','','',0,0,'sys_file_metadata',13,'',0,0,2147483647,0,0,''),
('309cc064d452a04184259f54ddf0f537','sys_file_reference',25,'uid_local',0,0,2147483647,0,'','','',0,0,'sys_file',14,'',0,0,2147483647,0,0,''),
('322e3c71e224049772876d0247317e84','sys_category',2,'items',0,0,2147483647,0,'','','',0,0,'tx_mask_all_cases',1,'tx_mask_catgeory',0,0,2147483647,0,1,''),
('39302b34fcc68b7cc0dab6f16be7c324','sys_file',8,'metadata',0,0,2147483647,0,'','','',0,0,'sys_file_metadata',8,'',0,0,2147483647,0,0,''),
('3be13d8a8dc45bf0977d231b915f3677','tx_mask_all_cases',3,'tx_mask_photo_case',0,0,2147483647,0,'','','',0,0,'sys_file_reference',23,'',0,0,2147483647,0,0,''),
('3fe71cc32471471a7d39c7531d211f9a','sys_file_reference',19,'uid_local',0,0,2147483647,0,'','','',0,0,'sys_file',9,'',0,0,2147483647,0,0,''),
('4600140961861661c41f1420de51649b','tt_content',2,'bodytext',0,0,2147483647,0,'','typolink_tag','5',0,0,'_STRING',0,'',0,0,2147483647,0,0,'hello@raffaelwaldner.com'),
('4ab6d17a6a3044d7ba50e8c34a4c6d14','tt_content',5,'tx_mask_home_image',0,0,2147483647,0,'','','',0,0,'sys_file_reference',6,'',0,0,2147483647,0,0,''),
('4cf82f5da84625839f976b9fe08c89af','tx_mask_all_cases',4,'parentid',0,0,2147483647,0,'','','',0,0,'tt_content',7,'',0,0,2147483647,0,0,''),
('4ea4299836930fb05fc5037fa0d97eac','tt_content',8,'tx_mask_images_for_this_case',0,0,2147483647,0,'','','',2,0,'sys_file_reference',10,'',0,0,2147483647,0,0,''),
('52fa3e6bcffb9d450006ed66f0c9b357','tt_content',2,'bodytext',0,0,2147483647,0,'','email','2',0,0,'_STRING',0,'',0,0,2147483647,0,0,'hello@raffaelwaldner.com'),
('5348876c0d7ab52a084c91f812d479c6','tt_content',7,'tx_mask_all_cases',0,0,2147483647,0,'','','',3,0,'tx_mask_all_cases',4,'',0,0,2147483647,0,0,''),
('5490c4a2f55e374c40a828326d306486','sys_file_reference',18,'uid_local',0,0,2147483647,0,'','','',0,0,'sys_file',9,'',0,0,2147483647,0,0,''),
('5b17ec0d11c2234242c259bb9fa85e2d','tt_content',8,'tx_mask_images_for_this_case',0,0,2147483647,0,'','','',3,0,'sys_file_reference',11,'',0,0,2147483647,0,0,''),
('5cf62de176f58998d1750ec070eb9269','sys_file',2,'metadata',0,0,2147483647,0,'','','',0,0,'sys_file_metadata',2,'',0,0,2147483647,0,0,''),
('64b2a394e0c1aa7126a38e5bebdb72a5','sys_file',8,'storage',0,0,2147483647,0,'','','',0,0,'sys_file_storage',1,'',0,0,2147483647,0,0,''),
('65c020390659d6b1467d58b4f601086b','sys_file_reference',8,'uid_local',0,0,2147483647,0,'','','',0,0,'sys_file',4,'',0,0,2147483647,0,0,''),
('662118c0b7a0096482db813011801a45','sys_file',1,'storage',0,0,2147483647,0,'','','',0,0,'sys_file_storage',1,'',0,0,2147483647,0,0,''),
('6a94b41f5ae34b7bae0ec9070182ed92','sys_file',13,'storage',0,0,2147483647,0,'','','',0,0,'sys_file_storage',1,'',0,0,2147483647,0,0,''),
('7140d136d6ed24576f213106d6e111eb','tx_mask_all_cases',4,'tx_mask_photo_case',0,0,2147483647,0,'','','',0,0,'sys_file_reference',16,'',0,0,2147483647,0,0,''),
('7309365359e95439e9fd6249ac990619','tt_content',7,'tx_mask_all_cases',0,0,2147483647,0,'','','',4,0,'tx_mask_all_cases',5,'',0,0,2147483647,0,0,''),
('74b15b7ac1541232800fb35e69702350','tx_mask_all_cases',1,'parentid',0,0,2147483647,0,'','','',0,0,'tt_content',7,'',0,0,2147483647,0,0,''),
('750831d1fff4b9004dc00b3fef4c65e2','tx_mask_all_cases',4,'tx_mask_link_for_image',0,0,2147483647,0,'','typolink','fe13e2f66d3df416ffb28c949f71ff40:0',0,0,'pages',6,'',0,0,2147483647,0,0,''),
('7512f9bda44614486855a3d17a82fb50','sys_category',4,'items',0,0,2147483647,0,'','','',0,0,'tx_mask_all_cases',3,'tx_mask_catgeory',0,0,2147483647,0,1,''),
('771235945d6775c6a28e432603da5f7f','sys_file_reference',12,'uid_local',0,0,2147483647,0,'','','',0,0,'sys_file',8,'',0,0,2147483647,0,0,''),
('77c1b13d2222b2a264bf63ae39a484d0','sys_file',9,'storage',0,0,2147483647,0,'','','',0,0,'sys_file_storage',1,'',0,0,2147483647,0,0,''),
('786e131be796ac4b5888c15f165f7546','sys_file',7,'storage',0,0,2147483647,0,'','','',0,0,'sys_file_storage',1,'',0,0,2147483647,0,0,''),
('7acb7bc43e93e884930881cd6d16ff2f','tx_mask_all_cases',6,'tx_mask_link_for_image',0,0,2147483647,0,'','typolink','2b9fde24743a4425e5d669b5a2db8eb8:0',0,0,'pages',6,'',0,0,2147483647,0,0,''),
('7b7f91e72f74cd18554a7d2c75bfb6c1','tt_content',7,'tx_mask_all_cases',0,0,2147483647,0,'','','',2,0,'tx_mask_all_cases',3,'',0,0,2147483647,0,0,''),
('7d4c1f918f8c3202234f26e00206eac7','tt_content',4,'tx_mask_home_image',0,0,2147483647,0,'','','',0,0,'sys_file_reference',5,'',0,0,2147483647,0,0,''),
('7d9255aab106d4e72fa128313070dea5','sys_category',2,'items',0,0,2147483647,0,'','','',2,0,'tx_mask_all_cases',5,'tx_mask_catgeory',0,0,2147483647,0,1,''),
('7ec2cabc104d18b6886cb8f595be8b36','tt_content',3,'tx_mask_chose_link',0,0,2147483647,0,'','typolink','c3bf3cf928c884bb73f7b61403e727bb:0',0,0,'pages',2,'',0,0,2147483647,0,0,''),
('835c6fe89399cf6fcb8382c6919ead07','tt_content',7,'tx_mask_all_cases',0,0,2147483647,0,'','','',0,0,'tx_mask_all_cases',1,'',0,0,2147483647,0,0,''),
('8cdd0f70f75166d5da86b8bfebdf0d5e','sys_category',2,'items',0,0,2147483647,0,'','','',3,0,'tx_mask_all_cases',6,'tx_mask_catgeory',0,0,2147483647,0,1,''),
('8db938d967725220c55198fc6929d0a3','tx_mask_all_cases',5,'tx_mask_link_for_image',0,0,2147483647,0,'','typolink','a81ac67bcd684c9314d24b21d5dfd2ed:0',0,0,'pages',6,'',0,0,2147483647,0,0,''),
('90bef0838b6a0aa50a5150f208b73b71','tx_mask_all_cases',1,'tx_mask_link_for_image',0,0,2147483647,0,'','typolink','cd3e6fbc3f170e82dc86e111ee7b4421:0',0,0,'pages',6,'',0,0,2147483647,0,0,''),
('a1dfb78b46f8acf4ab9800311f1c96f4','tx_mask_all_cases',3,'tx_mask_link_for_image',0,0,2147483647,0,'','typolink','0a6d76bc9a4fab71b996a0371a8c5a8f:0',0,0,'pages',6,'',0,0,2147483647,0,0,''),
('a2c623dd77390ec9f270bbc413154e5a','sys_file_reference',22,'uid_local',0,0,2147483647,0,'','','',0,0,'sys_file',11,'',0,0,2147483647,0,0,''),
('a584c675c94a1ae29e74f647cdb8e3b3','sys_file',4,'storage',0,0,2147483647,0,'','','',0,0,'sys_file_storage',1,'',0,0,2147483647,0,0,''),
('a5b4380c52b1e554ea59a78a9003c0ff','sys_file_reference',21,'uid_local',0,0,2147483647,0,'','','',0,0,'sys_file',10,'',0,0,2147483647,0,0,''),
('a60cdbae4aa3ad1a738f40534059fe32','tx_mask_all_cases',6,'tx_mask_photo_case',0,0,2147483647,0,'','','',0,0,'sys_file_reference',20,'',0,0,2147483647,0,0,''),
('a62806cbfcc536dffe02d21003163e87','sys_file_reference',20,'uid_local',0,0,2147483647,0,'','','',0,0,'sys_file',2,'',0,0,2147483647,0,0,''),
('a71d156cbbc1fd0aea0e6f9e84024815','sys_file',14,'storage',0,0,2147483647,0,'','','',0,0,'sys_file_storage',1,'',0,0,2147483647,0,0,''),
('ab57b95d0ed34d9bfb5f3cdf7a8e4d7b','sys_file_reference',23,'uid_local',0,0,2147483647,0,'','','',0,0,'sys_file',12,'',0,0,2147483647,0,0,''),
('ad92a7d4a0b5d864fcd31905c0791f3b','sys_file',5,'storage',0,0,2147483647,0,'','','',0,0,'sys_file_storage',1,'',0,0,2147483647,0,0,''),
('ae3590d7e2d0dd6f07cf0c9dd747ee1c','sys_file_reference',9,'uid_local',0,0,2147483647,0,'','','',0,0,'sys_file',5,'',0,0,2147483647,0,0,''),
('b0ae16f14be1df26f90dd69fd989e6a5','tx_mask_all_cases',2,'parentid',0,0,2147483647,0,'','','',0,0,'tt_content',7,'',0,0,2147483647,0,0,''),
('b29f51a7f7e6e6dcc6d99be7849ae442','sys_file',2,'storage',0,0,2147483647,0,'','','',0,0,'sys_file_storage',1,'',0,0,2147483647,0,0,''),
('b916bee7d6f2b1fe704a42a78a7c99ce','tt_content',8,'tx_mask_images_for_this_case',0,0,2147483647,0,'','','',4,0,'sys_file_reference',12,'',0,0,2147483647,0,0,''),
('bb07476d9b0172491715d5ea40709c28','sys_file_reference',6,'uid_local',0,0,2147483647,0,'','','',0,0,'sys_file',3,'',0,0,2147483647,0,0,''),
('c21785f4628a2dca51bbef8b626e0032','sys_category',3,'items',0,0,2147483647,0,'','','',0,0,'tx_mask_all_cases',4,'tx_mask_catgeory',0,0,2147483647,0,1,''),
('c21b5b72cffd19eb755c7f992203900a','sys_file_reference',10,'uid_local',0,0,2147483647,0,'','','',0,0,'sys_file',6,'',0,0,2147483647,0,0,''),
('c302fdd779779daafac5801dd516c942','tx_mask_all_cases',5,'parentid',0,0,2147483647,0,'','','',0,0,'tt_content',7,'',0,0,2147483647,0,0,''),
('c82baf5d42c5ddb6cdafb1516e30a00c','tx_mask_all_cases',6,'parentid',0,0,2147483647,0,'','','',0,0,'tt_content',7,'',0,0,2147483647,0,0,''),
('c8d13c38659ba99e074a979b57f8f03d','sys_category',2,'items',0,0,2147483647,0,'','','',1,0,'tx_mask_all_cases',2,'tx_mask_catgeory',0,0,2147483647,0,1,''),
('c9367facc88b37d9ac2752b6adad14d8','tt_content',8,'tx_mask_images_for_this_case',0,0,2147483647,0,'','','',1,0,'sys_file_reference',9,'',0,0,2147483647,0,0,''),
('c94b13fcf614f9406dabce55746b391e','sys_file_reference',16,'uid_local',0,0,2147483647,0,'','','',0,0,'sys_file',7,'',0,0,2147483647,0,0,''),
('cb9ba9086382d45242ec8d8caace6ff9','sys_file_reference',11,'uid_local',0,0,2147483647,0,'','','',0,0,'sys_file',7,'',0,0,2147483647,0,0,''),
('ccc76f735cb38dca39df162b0b627353','sys_file',12,'storage',0,0,2147483647,0,'','','',0,0,'sys_file_storage',1,'',0,0,2147483647,0,0,''),
('d3426f83555af3af0177f49c004b75a8','tt_content',4,'tx_mask_chose_link',0,0,2147483647,0,'','typolink','165295ccf30c8b46cd41453779d485f7:0',0,0,'pages',2,'',0,0,2147483647,0,0,''),
('d6663e0bc364ba0aac493cd2ecf611fb','tt_content',6,'tx_mask_home_image',0,0,2147483647,0,'','','',0,0,'sys_file_reference',7,'',0,0,2147483647,0,0,''),
('d762da2cbea3fc2bcaf1db96ded74dd7','sys_file',3,'storage',0,0,2147483647,0,'','','',0,0,'sys_file_storage',1,'',0,0,2147483647,0,0,''),
('d860d9389667c92145871d401a40f562','sys_file',6,'metadata',0,0,2147483647,0,'','','',0,0,'sys_file_metadata',6,'',0,0,2147483647,0,0,''),
('e309de50a33553d403701ea76e557215','tt_content',7,'tx_mask_all_cases',0,0,2147483647,0,'','','',1,0,'tx_mask_all_cases',2,'',0,0,2147483647,0,0,''),
('e85faa2529a712059d6ba8cb10022ff1','tx_mask_all_cases',3,'parentid',0,0,2147483647,0,'','','',0,0,'tt_content',7,'',0,0,2147483647,0,0,''),
('f499e77e72471e85f95264bfae9fbe18','tt_content',3,'tx_mask_home_image',0,0,2147483647,0,'','','',0,0,'sys_file_reference',25,'',0,0,2147483647,0,0,''),
('f6062209d87aa82eace335f4ab0c7610','sys_file',10,'storage',0,0,2147483647,0,'','','',0,0,'sys_file_storage',1,'',0,0,2147483647,0,0,''),
('f65a0036c032c205fbec731c7f9abb9d','sys_file',6,'storage',0,0,2147483647,0,'','','',0,0,'sys_file_storage',1,'',0,0,2147483647,0,0,''),
('ffa602de6cc41aa063aec87c7234f976','sys_file',5,'metadata',0,0,2147483647,0,'','','',0,0,'sys_file_metadata',5,'',0,0,2147483647,0,0,''),
('ffd7e32721e0375fb0ba6c115bef3b34','tt_content',6,'tx_mask_chose_link',0,0,2147483647,0,'','typolink','397cdef3cdf165c12246270fe4c4c7cf:0',0,0,'pages',2,'',0,0,2147483647,0,0,'');
/*!40000 ALTER TABLE `sys_refindex` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_registry`
--

DROP TABLE IF EXISTS `sys_registry`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_registry` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `entry_namespace` varchar(128) NOT NULL DEFAULT '',
  `entry_key` varchar(128) NOT NULL DEFAULT '',
  `entry_value` mediumblob DEFAULT NULL,
  PRIMARY KEY (`uid`),
  UNIQUE KEY `entry_identifier` (`entry_namespace`,`entry_key`)
) ENGINE=InnoDB AUTO_INCREMENT=25 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_registry`
--

LOCK TABLES `sys_registry` WRITE;
/*!40000 ALTER TABLE `sys_registry` DISABLE KEYS */;
INSERT INTO `sys_registry` VALUES
(1,'installUpdate','TYPO3\\CMS\\Install\\Updates\\BackendGroupsExplicitAllowDenyMigration','i:1;'),
(2,'installUpdate','TYPO3\\CMS\\Install\\Updates\\BackendModulePermissionMigration','i:1;'),
(3,'installUpdate','TYPO3\\CMS\\Install\\Updates\\IndexedSearchCTypeMigration','i:1;'),
(4,'installUpdate','TYPO3\\CMS\\Install\\Updates\\MigrateSiteSettingsConfigUpdate','i:1;'),
(5,'installUpdate','TYPO3\\CMS\\Install\\Updates\\PagesRecyclerDoktypeMigration','i:1;'),
(6,'installUpdate','TYPO3\\CMS\\Install\\Updates\\SynchronizeColPosAndCTypeWithDefaultLanguage','i:1;'),
(7,'installUpdate','TYPO3\\CMS\\Install\\Updates\\SysFileCollectionIdentifierMigration','i:1;'),
(8,'installUpdate','TYPO3\\CMS\\Install\\Updates\\SysFileMountIdentifierMigration','i:1;'),
(9,'installUpdate','TYPO3\\CMS\\Install\\Updates\\SysLogSerializationUpdate','i:1;'),
(10,'installUpdate','TYPO3\\CMS\\Install\\Updates\\SysTemplateNoWorkspaceMigration','i:1;'),
(11,'installUpdate','TYPO3\\CMS\\Extensionmanager\\Updates\\FeLoginModeExtractionUpdate','i:1;'),
(12,'installUpdate','GeorgRinger\\News\\Updates\\NewsSlugUpdater','i:1;'),
(13,'installUpdate','GeorgRinger\\News\\Updates\\PluginPermissionUpdater','i:1;'),
(14,'installUpdate','GeorgRinger\\News\\Updates\\PluginUpdater','i:1;'),
(15,'installUpdate','GeorgRinger\\News\\Updates\\PopulateCategorySlugs','i:1;'),
(16,'installUpdate','GeorgRinger\\News\\Updates\\PopulateTagSlugs','i:1;'),
(17,'installUpdate','GeorgRinger\\News\\Updates\\RelatedLinkIntegerDefault','i:1;'),
(18,'installUpdate','GeorgRinger\\News\\Updates\\TitleFieldDefault','i:1;'),
(19,'installUpdate','MASK\\Mask\\Updates\\ConvertTemplatesToUppercase','i:1;'),
(20,'installUpdate','MASK\\Mask\\Updates\\FillTranslationSourceField','i:1;'),
(21,'installUpdate','MASK\\Mask\\Updates\\MigrateContentFields','i:1;'),
(22,'installUpdate','MASK\\Mask\\Updates\\MoveRteOptions','i:1;'),
(23,'installUpdateRows','rowUpdatersDone','a:1:{i:0;s:69:\"TYPO3\\CMS\\Install\\Updates\\RowUpdater\\SysRedirectRootPageMoveMigration\";}'),
(24,'core','formProtectionSessionToken:1','s:64:\"7695b0b3e4f499dcc15feec7641e97883ea344493481b007b36a2111da034db3\";');
/*!40000 ALTER TABLE `sys_registry` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_template`
--

DROP TABLE IF EXISTS `sys_template`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_template` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `sorting` int(11) NOT NULL DEFAULT 0,
  `description` text DEFAULT NULL,
  `tx_impexp_origuid` int(11) NOT NULL DEFAULT 0,
  `title` varchar(255) NOT NULL DEFAULT '',
  `root` smallint(5) unsigned NOT NULL DEFAULT 0,
  `clear` smallint(5) unsigned NOT NULL DEFAULT 0,
  `constants` longtext DEFAULT NULL,
  `include_static_file` longtext DEFAULT NULL,
  `basedOn` longtext DEFAULT NULL,
  `includeStaticAfterBasedOn` smallint(5) unsigned NOT NULL DEFAULT 0,
  `config` longtext DEFAULT NULL,
  `static_file_mode` int(10) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `roottemplate` (`deleted`,`hidden`,`root`),
  KEY `parent` (`pid`,`deleted`,`hidden`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_template`
--

LOCK TABLES `sys_template` WRITE;
/*!40000 ALTER TABLE `sys_template` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_template` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_workspace`
--

DROP TABLE IF EXISTS `sys_workspace`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_workspace` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `description` text DEFAULT NULL,
  `title` varchar(30) NOT NULL DEFAULT '',
  `adminusers` longtext DEFAULT NULL,
  `members` longtext DEFAULT NULL,
  `db_mountpoints` longtext DEFAULT NULL,
  `file_mountpoints` varchar(255) DEFAULT '',
  `publish_time` bigint(20) NOT NULL DEFAULT 0,
  `freeze` smallint(5) unsigned NOT NULL DEFAULT 0,
  `live_edit` smallint(5) unsigned NOT NULL DEFAULT 0,
  `publish_access` smallint(5) unsigned NOT NULL DEFAULT 0,
  `previewlink_lifetime` int(11) NOT NULL DEFAULT 0,
  `stagechg_notification` smallint(5) unsigned NOT NULL DEFAULT 1,
  `custom_stages` int(10) unsigned NOT NULL DEFAULT 0,
  `edit_notification_defaults` longtext DEFAULT NULL,
  `edit_allow_notificaton_settings` smallint(5) unsigned NOT NULL DEFAULT 3,
  `edit_notification_preselection` smallint(5) unsigned NOT NULL DEFAULT 2,
  `publish_notification_defaults` longtext DEFAULT NULL,
  `publish_allow_notificaton_settings` smallint(5) unsigned NOT NULL DEFAULT 3,
  `publish_notification_preselection` smallint(5) unsigned NOT NULL DEFAULT 1,
  `execute_notification_defaults` longtext DEFAULT NULL,
  `execute_allow_notificaton_settings` smallint(5) unsigned NOT NULL DEFAULT 3,
  `execute_notification_preselection` smallint(5) unsigned NOT NULL DEFAULT 3,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_workspace`
--

LOCK TABLES `sys_workspace` WRITE;
/*!40000 ALTER TABLE `sys_workspace` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_workspace` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_workspace_stage`
--

DROP TABLE IF EXISTS `sys_workspace_stage`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_workspace_stage` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `sorting` int(11) NOT NULL DEFAULT 0,
  `parentid` int(10) unsigned NOT NULL DEFAULT 0,
  `title` varchar(30) NOT NULL DEFAULT '',
  `responsible_persons` longtext DEFAULT NULL,
  `default_mailcomment` longtext DEFAULT NULL,
  `notification_defaults` longtext DEFAULT NULL,
  `allow_notificaton_settings` smallint(5) unsigned NOT NULL DEFAULT 3,
  `notification_preselection` smallint(5) unsigned NOT NULL DEFAULT 8,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_workspace_stage`
--

LOCK TABLES `sys_workspace_stage` WRITE;
/*!40000 ALTER TABLE `sys_workspace_stage` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_workspace_stage` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tt_content`
--

DROP TABLE IF EXISTS `tt_content`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tt_content` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `fe_group` varchar(255) NOT NULL DEFAULT '0',
  `sorting` int(11) NOT NULL DEFAULT 0,
  `rowDescription` text DEFAULT NULL,
  `editlock` smallint(5) unsigned NOT NULL DEFAULT 0,
  `sys_language_uid` int(11) NOT NULL DEFAULT 0,
  `l18n_parent` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_source` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_state` text DEFAULT NULL,
  `l18n_diffsource` mediumblob DEFAULT NULL,
  `t3ver_oid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_wsid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `frame_class` varchar(60) NOT NULL DEFAULT 'default',
  `colPos` int(10) unsigned NOT NULL DEFAULT 0,
  `table_caption` varchar(255) DEFAULT NULL,
  `tx_impexp_origuid` int(11) NOT NULL DEFAULT 0,
  `tx_news_related_news` int(11) NOT NULL DEFAULT 0,
  `tx_container_parent` int(11) NOT NULL DEFAULT 0,
  `CType` varchar(255) NOT NULL DEFAULT '',
  `categories` int(10) unsigned NOT NULL DEFAULT 0,
  `layout` int(10) unsigned NOT NULL DEFAULT 0,
  `space_before_class` varchar(60) NOT NULL DEFAULT '',
  `space_after_class` varchar(60) NOT NULL DEFAULT '',
  `date` bigint(20) NOT NULL DEFAULT 0,
  `header` varchar(255) NOT NULL DEFAULT '',
  `header_layout` int(10) unsigned NOT NULL DEFAULT 0,
  `header_position` varchar(255) NOT NULL DEFAULT '',
  `header_link` text NOT NULL DEFAULT '',
  `subheader` varchar(255) NOT NULL DEFAULT '',
  `bodytext` longtext DEFAULT NULL,
  `image` int(10) unsigned NOT NULL DEFAULT 0,
  `assets` int(10) unsigned NOT NULL DEFAULT 0,
  `imagewidth` int(10) unsigned NOT NULL DEFAULT 0,
  `imageheight` int(10) unsigned NOT NULL DEFAULT 0,
  `imageorient` int(10) unsigned NOT NULL DEFAULT 0,
  `imageborder` smallint(5) unsigned NOT NULL DEFAULT 0,
  `image_zoom` smallint(5) unsigned NOT NULL DEFAULT 0,
  `imagecols` int(10) unsigned NOT NULL DEFAULT 0,
  `pages` longtext DEFAULT NULL,
  `recursive` int(10) unsigned NOT NULL DEFAULT 0,
  `list_type` varchar(255) NOT NULL DEFAULT '',
  `media` int(10) unsigned NOT NULL DEFAULT 0,
  `records` longtext DEFAULT NULL,
  `sectionIndex` smallint(5) unsigned NOT NULL DEFAULT 1,
  `linkToTop` smallint(5) unsigned NOT NULL DEFAULT 0,
  `pi_flexform` longtext DEFAULT NULL,
  `selected_categories` longtext DEFAULT NULL,
  `category_field` varchar(64) NOT NULL DEFAULT '',
  `bullets_type` int(10) unsigned NOT NULL DEFAULT 0,
  `cols` int(10) unsigned NOT NULL DEFAULT 0,
  `table_class` varchar(60) NOT NULL DEFAULT '',
  `table_delimiter` int(10) unsigned NOT NULL DEFAULT 0,
  `table_enclosure` int(10) unsigned NOT NULL DEFAULT 0,
  `table_header_position` int(10) unsigned NOT NULL DEFAULT 0,
  `table_tfoot` smallint(5) unsigned NOT NULL DEFAULT 0,
  `file_collections` longtext DEFAULT NULL,
  `filelink_size` smallint(5) unsigned NOT NULL DEFAULT 0,
  `filelink_sorting` varchar(64) NOT NULL DEFAULT '',
  `filelink_sorting_direction` varchar(4) NOT NULL DEFAULT '',
  `target` varchar(30) NOT NULL DEFAULT '',
  `uploads_description` smallint(5) unsigned NOT NULL DEFAULT 0,
  `uploads_type` int(10) unsigned NOT NULL DEFAULT 0,
  `tx_mask_home_image` int(10) unsigned NOT NULL DEFAULT 0,
  `tx_mask_small_text_on_image` mediumtext DEFAULT NULL,
  `tx_mask_chose_link` varchar(255) NOT NULL DEFAULT '',
  `tx_mask_all_cases` int(10) unsigned NOT NULL DEFAULT 0,
  `tx_mask_images_for_this_case` int(10) unsigned NOT NULL DEFAULT 0,
  `tx_mask_add_titiel_elo` mediumtext DEFAULT NULL,
  `tx_mask_photo_info` int(10) unsigned NOT NULL DEFAULT 0,
  `tx_mask_text_info` mediumtext DEFAULT NULL,
  `tx_mask_clients_first_colum` mediumtext DEFAULT NULL,
  `tx_mask_clienst_second_col` mediumtext DEFAULT NULL,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`sorting`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`),
  KEY `language` (`l18n_parent`,`sys_language_uid`),
  KEY `index_newscontent` (`tx_news_related_news`),
  KEY `container_parent` (`tx_container_parent`),
  KEY `CType` (`CType`),
  KEY `translation_source` (`l10n_source`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tt_content`
--

LOCK TABLES `tt_content` WRITE;
/*!40000 ALTER TABLE `tt_content` DISABLE KEYS */;
INSERT INTO `tt_content` VALUES
(1,1,1762422672,1762273125,1,0,0,0,'',256,'',0,0,0,0,NULL,'{\"CType\":\"\",\"categories\":\"\",\"colPos\":\"\",\"date\":\"\",\"editlock\":\"\",\"endtime\":\"\",\"fe_group\":\"\",\"frame_class\":\"\",\"header\":\"\",\"header_layout\":\"\",\"header_link\":\"\",\"header_position\":\"\",\"hidden\":\"\",\"image\":\"\",\"image_zoom\":\"\",\"imageborder\":\"\",\"imagecols\":\"\",\"imageheight\":\"\",\"imageorient\":\"\",\"imagewidth\":\"\",\"layout\":\"\",\"linkToTop\":\"\",\"rowDescription\":\"\",\"sectionIndex\":\"\",\"space_after_class\":\"\",\"space_before_class\":\"\",\"starttime\":\"\",\"subheader\":\"\"}',0,0,0,0,'default',0,NULL,0,0,0,'image',0,0,'','',0,'',0,'','','',NULL,1,0,0,0,0,0,0,2,NULL,0,'',0,NULL,1,0,NULL,NULL,'',0,0,'',124,0,0,0,NULL,0,'','','',0,0,0,NULL,'',0,0,NULL,0,NULL,NULL,NULL),
(2,4,1762416979,1762416979,0,0,0,0,'',256,'',0,0,0,0,NULL,'',0,0,0,0,'default',0,NULL,0,0,0,'text',0,0,'','',0,'',0,'','','','<p>Raffael Waldner Fotografie<br /><a href=\"https://maps.app.goo.gl/7nodM6A4MA3crJyk8\">Aarbergergasse 40 – Bern</a><br /><a href=\"tel:+41786011099\">+41 78 601 10 99</a><br /><a href=\"mailto:hello@raffaelwaldner.com\">hello@raffaelwaldner.com</a></p>',0,0,0,0,0,0,0,2,NULL,0,'',0,NULL,1,0,NULL,NULL,'',0,0,'',124,0,0,0,NULL,0,'','','',0,0,0,NULL,'',0,0,NULL,0,NULL,NULL,NULL),
(3,1,1762444587,1762422668,0,0,0,0,'',128,'',0,0,0,0,NULL,'{\"CType\":\"\",\"categories\":\"\",\"colPos\":\"\",\"editlock\":\"\",\"endtime\":\"\",\"fe_group\":\"\",\"frame_class\":\"\",\"header\":\"\",\"hidden\":\"\",\"layout\":\"\",\"linkToTop\":\"\",\"rowDescription\":\"\",\"sectionIndex\":\"\",\"space_after_class\":\"\",\"space_before_class\":\"\",\"starttime\":\"\",\"tx_mask_chose_link\":\"\",\"tx_mask_home_image\":\"\",\"tx_mask_small_text_on_image\":\"\"}',0,0,0,0,'default',0,NULL,0,0,0,'mask_case_home',0,0,'','',0,'Only for orientation purposes',0,'','','',NULL,0,0,0,0,0,0,0,2,NULL,0,'',0,NULL,1,0,NULL,NULL,'',0,0,'',124,0,0,0,NULL,0,'','','',0,0,1,'<p>Lorem ipsum dolorem,&nbsp;<br />Zurich, Switzerland</p>','t3://page?uid=2',0,0,NULL,0,NULL,NULL,NULL),
(4,1,1762423393,1762423246,0,0,0,0,'',384,'',0,0,0,0,NULL,'{\"CType\":\"\",\"categories\":\"\",\"colPos\":\"\",\"editlock\":\"\",\"endtime\":\"\",\"fe_group\":\"\",\"frame_class\":\"\",\"header\":\"\",\"hidden\":\"\",\"layout\":\"\",\"linkToTop\":\"\",\"rowDescription\":\"\",\"sectionIndex\":\"\",\"space_after_class\":\"\",\"space_before_class\":\"\",\"starttime\":\"\",\"tx_mask_chose_link\":\"\",\"tx_mask_home_image\":\"\",\"tx_mask_small_text_on_image\":\"\"}',0,0,0,0,'default',0,NULL,0,0,0,'mask_case_home',0,0,'','',0,'Only for orientation purposes',0,'','','',NULL,0,0,0,0,0,0,0,2,'',0,'',0,'',1,0,NULL,'0','',0,0,'',124,0,0,0,'',0,'','','',0,0,1,'<p>Lorem ipsum dolorem,&nbsp;<br />Zurich, Switzerland</p>','t3://page?uid=2',0,0,NULL,0,NULL,NULL,NULL),
(5,1,1762423425,1762423420,0,0,0,0,'',640,'',0,0,0,0,NULL,'{\"hidden\":\"\"}',0,0,0,0,'default',0,NULL,0,0,0,'mask_case_home',0,0,'','',0,'Only for orientation purposes',0,'','','',NULL,0,0,0,0,0,0,0,2,'',0,'',0,'',1,0,NULL,'0','',0,0,'',124,0,0,0,'',0,'','','',0,0,1,'<p>Lorem ipsum dolorem,&nbsp;<br />Zurich, Switzerland</p>','t3://page?uid=2',0,0,NULL,0,NULL,NULL,NULL),
(6,1,1762423423,1762423422,0,0,0,0,'',896,'',0,0,0,0,NULL,'{\"hidden\":\"\"}',0,0,0,0,'default',0,NULL,0,0,0,'mask_case_home',0,0,'','',0,'Only for orientation purposes',0,'','','',NULL,0,0,0,0,0,0,0,2,'',0,'',0,'',1,0,NULL,'0','',0,0,'',124,0,0,0,'',0,'','','',0,0,1,'<p>Lorem ipsum dolorem,&nbsp;<br />Zurich, Switzerland</p>','t3://page?uid=2',0,0,NULL,0,NULL,NULL,NULL),
(7,2,1762443238,1762425054,0,0,0,0,'',256,'',0,0,0,0,NULL,'{\"CType\":\"\",\"categories\":\"\",\"colPos\":\"\",\"editlock\":\"\",\"endtime\":\"\",\"fe_group\":\"\",\"frame_class\":\"\",\"hidden\":\"\",\"layout\":\"\",\"linkToTop\":\"\",\"rowDescription\":\"\",\"sectionIndex\":\"\",\"space_after_class\":\"\",\"space_before_class\":\"\",\"starttime\":\"\",\"tx_mask_all_cases\":\"\"}',0,0,0,0,'default',0,NULL,0,0,0,'mask_work',0,0,'','',0,'',0,'','','',NULL,0,0,0,0,0,0,0,2,NULL,0,'',0,NULL,1,0,NULL,NULL,'',0,0,'',124,0,0,0,NULL,0,'','','',0,0,0,NULL,'',6,0,NULL,0,NULL,NULL,NULL),
(8,6,1762432949,1762432251,0,0,0,0,'',256,'',0,0,0,0,NULL,'{\"CType\":\"\",\"categories\":\"\",\"colPos\":\"\",\"editlock\":\"\",\"endtime\":\"\",\"fe_group\":\"\",\"frame_class\":\"\",\"header\":\"\",\"hidden\":\"\",\"layout\":\"\",\"linkToTop\":\"\",\"rowDescription\":\"\",\"sectionIndex\":\"\",\"space_after_class\":\"\",\"space_before_class\":\"\",\"starttime\":\"\",\"tx_mask_add_titiel_elo\":\"\",\"tx_mask_images_for_this_case\":\"\"}',0,0,0,0,'default',0,NULL,0,0,0,'mask_detail',0,0,'','',0,'Sinisha Lüscher',0,'','','',NULL,0,0,0,0,0,0,0,2,NULL,0,'',0,NULL,1,0,NULL,NULL,'',0,0,'',124,0,0,0,NULL,0,'','','',0,0,0,NULL,'',0,5,'<p>Sinisha Lüscher, &nbsp;<br />Zurich, Switzerland</p>',0,NULL,NULL,NULL),
(9,3,1762442309,1762441921,0,0,0,0,'',256,'',0,0,0,0,NULL,'{\"CType\":\"\",\"categories\":\"\",\"colPos\":\"\",\"editlock\":\"\",\"endtime\":\"\",\"fe_group\":\"\",\"frame_class\":\"\",\"header\":\"\",\"hidden\":\"\",\"layout\":\"\",\"linkToTop\":\"\",\"rowDescription\":\"\",\"sectionIndex\":\"\",\"space_after_class\":\"\",\"space_before_class\":\"\",\"starttime\":\"\",\"tx_mask_clienst_second_col\":\"\",\"tx_mask_clients_first_colum\":\"\",\"tx_mask_photo_info\":\"\",\"tx_mask_text_info\":\"\"}',0,0,0,0,'default',0,NULL,0,0,0,'mask_info',0,0,'','',0,'Info – nur informativ',0,'','','',NULL,0,0,0,0,0,0,0,2,NULL,0,'',0,NULL,1,0,NULL,NULL,'',0,0,'',124,0,0,0,NULL,0,'','','',0,0,0,NULL,'',0,0,NULL,1,'<p>Raffael Waldner, geboren in Basel mit jenischen Wurzeln, studierte Fotografie in Leipzig und Zürich. Seine Arbeiten wurden weltweit in zahlreichen Ausstellungen gezeigt. Er war Teil des Projekts «Regeneration 50 Photographers of Tomorrow» und hat mehrere Bücher veröffentlicht. Fasziniert von der Fotografie an der Schnittstelle zwischen Kunst und Dokumentation, interessiert er sich für die Untersuchung von Lebensbedingungen, Orten und Alltagsgegen- ständen und den Werten, die sie vermitteln. Er konzentriert sich auf seine persönlichen Arbeiten und Aufträge für Unternehmens-, Industrie-, Redaktions- und Porträtkunden in der Schweiz und im Ausland und unterrichtet Fotografie an der HKB, Hochschule der Künste Bern und der F+F, Schule für Kunst und Design Zürich. Raffael Waldner ist Mitinhaber der Agentur 13Photo in Zürich, heute die grösste Foto- grafenagentur der Schweiz mit über 50 Mitgliedern.&nbsp;</p>\r\n\r\n<p>Raffael Waldners Fotografie ist ein Dialog zwischen Distanz und Nähe. Waldner beobachtet mit kühler Klarheit und zugleich feiner Empathie. Seine Porträts, Architekturen und Stories sind nie zufällig – sie sind sorgfältig komponierte Beobachtungen über Menschen, Räume und Strukturen. In seiner Bildwelt herrscht ein kontrolliertes Licht, eine klare Ordnung und eine spürbare Ruhe. Doch unter dieser Oberfläche liegt Bewegung – Ironie, Verletzlichkeit, Kraft. Waldner zeigt das Unspektakuläre mit Würde, das Gewöhnliche mit Bedeutung. Seine Arbeiten sind visuelle Analysen des Alltags, präzise, eigenwillig und voller Haltung. Sie sprechen die Sprache von Authentizität, Intelligenz und visueller Eleganz – ohne Pathos, aber mit Tiefe. Analytisch. Still. Direkt. Fotografie als Spiegel gesell-schaftlicher Wirklichkeit – reduziert, menschlich, zeitlos.</p>','<p>ADACMagazin<br />Annabelle<br />Beobachter<br />BeobachterNatur<br />Bergwelten<br />Bilanz<br />Bloomberg<br />Brigitte<br />DasMagazin<br />DU<br />DieZeit<br />Focus<br />FreemansWorld<br />FritzundFränzi<br />Handelszeitung<br />Hochparterre<br />Liberation<br />MillionaireMagazin<br />MMagazin<br />NZZ<br />NZZFolio<br />NZZamSonntag<br />NZZGeschichte<br />Saisonküche<br />SchweizerFamilie<br />SISport<br />SonntagsZeitung<br />Spiegel<br />Stern<br />Tages-Anzeiger<br />VIA<br />Vivai<br />Weltwoche<br />ZeitMagazin<br />Z-Magazin</p>','<p>AVAAargauVerkehr<br />AXA<br />BernExpo<br />BeyerChronometrie<br />BernerFachhochschule<br />Blausee<br />Buhlergroup<br />BundesamtfürUmwelt<br />Burgerspital<br />Comet<br />Crafft<br />CreditSuisse<br />Designsensor<br />Dr.MeyerImmobilien<br />E+AKaufmann<br />Elektra<br />GCAAltium<br />Infel<br />Isolutions<br />Kitchener<br />Marrazzi<br />Metaphor<br />Migros-Genossenschafts-<br />Bund<br />NewID<br />NobelBiocare<br />Primafila<br />Republica<br />Saurer<br />SBB<br />SGE<br />Siegfried<br />Spillmann/Felser/LeoBurnett<br />Stoppani<br />Sturm&amp;Bräm<br />Suva<br />Swissbanking<br />Unibasel</p>');
/*!40000 ALTER TABLE `tt_content` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tx_extensionmanager_domain_model_extension`
--

DROP TABLE IF EXISTS `tx_extensionmanager_domain_model_extension`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tx_extensionmanager_domain_model_extension` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `extension_key` varchar(60) NOT NULL DEFAULT '',
  `remote` varchar(100) NOT NULL DEFAULT 'ter',
  `version` varchar(15) NOT NULL DEFAULT '',
  `alldownloadcounter` int(10) unsigned NOT NULL DEFAULT 0,
  `downloadcounter` int(10) unsigned NOT NULL DEFAULT 0,
  `title` varchar(150) NOT NULL DEFAULT '',
  `serialized_dependencies` mediumtext DEFAULT NULL,
  `author_name` varchar(255) NOT NULL DEFAULT '',
  `author_email` varchar(255) NOT NULL DEFAULT '',
  `ownerusername` varchar(50) NOT NULL DEFAULT '',
  `md5hash` varchar(35) NOT NULL DEFAULT '',
  `authorcompany` varchar(255) NOT NULL DEFAULT '',
  `integer_version` int(11) NOT NULL DEFAULT 0,
  `lastreviewedversion` int(11) NOT NULL DEFAULT 0,
  `documentation_link` varchar(2048) DEFAULT NULL,
  `distribution_image` varchar(255) DEFAULT NULL,
  `distribution_welcome_image` varchar(255) DEFAULT NULL,
  `description` longtext DEFAULT NULL,
  `state` int(10) unsigned NOT NULL DEFAULT 0,
  `category` int(10) unsigned NOT NULL DEFAULT 0,
  `last_updated` bigint(20) NOT NULL DEFAULT 0,
  `update_comment` longtext DEFAULT NULL,
  `current_version` smallint(5) unsigned NOT NULL DEFAULT 0,
  `review_state` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  UNIQUE KEY `versionextrepo` (`extension_key`,`version`,`remote`),
  KEY `index_extrepo` (`extension_key`,`remote`),
  KEY `index_versionrepo` (`integer_version`,`remote`,`extension_key`),
  KEY `index_currentversions` (`current_version`,`review_state`),
  KEY `parent` (`pid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tx_extensionmanager_domain_model_extension`
--

LOCK TABLES `tx_extensionmanager_domain_model_extension` WRITE;
/*!40000 ALTER TABLE `tx_extensionmanager_domain_model_extension` DISABLE KEYS */;
/*!40000 ALTER TABLE `tx_extensionmanager_domain_model_extension` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tx_impexp_presets`
--

DROP TABLE IF EXISTS `tx_impexp_presets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tx_impexp_presets` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `title` varchar(255) NOT NULL DEFAULT '',
  `public` smallint(6) NOT NULL DEFAULT 0,
  `item_uid` int(11) NOT NULL DEFAULT 0,
  `user_uid` int(10) unsigned NOT NULL DEFAULT 0,
  `preset_data` blob DEFAULT NULL,
  PRIMARY KEY (`uid`),
  KEY `lookup` (`item_uid`),
  KEY `parent` (`pid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tx_impexp_presets`
--

LOCK TABLES `tx_impexp_presets` WRITE;
/*!40000 ALTER TABLE `tx_impexp_presets` DISABLE KEYS */;
/*!40000 ALTER TABLE `tx_impexp_presets` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tx_linkvalidator_link`
--

DROP TABLE IF EXISTS `tx_linkvalidator_link`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tx_linkvalidator_link` (
  `uid` int(11) NOT NULL AUTO_INCREMENT,
  `record_uid` int(11) NOT NULL DEFAULT 0,
  `record_pid` int(11) NOT NULL DEFAULT 0,
  `language` int(11) NOT NULL DEFAULT -1,
  `headline` varchar(255) NOT NULL DEFAULT '',
  `field` varchar(255) NOT NULL DEFAULT '',
  `table_name` varchar(255) NOT NULL DEFAULT '',
  `element_type` varchar(255) NOT NULL DEFAULT '',
  `link_title` text DEFAULT NULL,
  `url` text DEFAULT NULL,
  `url_response` text DEFAULT NULL,
  `last_check` int(11) NOT NULL DEFAULT 0,
  `link_type` varchar(50) NOT NULL DEFAULT '',
  `needs_recheck` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tx_linkvalidator_link`
--

LOCK TABLES `tx_linkvalidator_link` WRITE;
/*!40000 ALTER TABLE `tx_linkvalidator_link` DISABLE KEYS */;
/*!40000 ALTER TABLE `tx_linkvalidator_link` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tx_mask_all_cases`
--

DROP TABLE IF EXISTS `tx_mask_all_cases`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tx_mask_all_cases` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `fe_group` varchar(255) NOT NULL DEFAULT '0',
  `sorting` int(11) NOT NULL DEFAULT 0,
  `editlock` smallint(5) unsigned NOT NULL DEFAULT 0,
  `sys_language_uid` int(11) NOT NULL DEFAULT 0,
  `l10n_parent` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_source` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_state` text DEFAULT NULL,
  `t3_origuid` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_diffsource` mediumblob DEFAULT NULL,
  `t3ver_oid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_wsid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `tx_mask_text_on_image` mediumtext DEFAULT NULL,
  `tx_mask_link_for_image` varchar(255) NOT NULL DEFAULT '',
  `tx_mask_photo_case` int(10) unsigned NOT NULL DEFAULT 0,
  `parentid` int(11) NOT NULL DEFAULT 0,
  `parenttable` varchar(255) DEFAULT '',
  `tx_mask_catgeory` int(10) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`,`hidden`),
  KEY `translation_source` (`l10n_source`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tx_mask_all_cases`
--

LOCK TABLES `tx_mask_all_cases` WRITE;
/*!40000 ALTER TABLE `tx_mask_all_cases` DISABLE KEYS */;
INSERT INTO `tx_mask_all_cases` VALUES
(1,2,1762443238,1762434972,0,0,0,0,'',1,0,0,0,0,NULL,0,'{\"editlock\":\"\",\"endtime\":\"\",\"fe_group\":\"\",\"hidden\":\"\",\"starttime\":\"\",\"tx_mask_catgeory\":\"\",\"tx_mask_link_for_image\":\"\",\"tx_mask_photo_case\":\"\",\"tx_mask_text_on_image\":\"\"}',0,0,0,0,'<p>Sinisha Lüscher, &nbsp;<br />Zurich, Switzerland</p>','t3://page?uid=6',1,7,'tt_content',1),
(2,2,1762443238,1762437321,0,0,0,0,'',2,0,0,0,0,NULL,0,'{\"hidden\":\"\"}',0,0,0,0,'<p>Sinisha Lüscher, &nbsp;<br />Zurich, Switzerland</p>','t3://page?uid=6',1,7,'tt_content',1),
(3,2,1762443238,1762437355,0,0,0,0,'',3,0,0,0,0,NULL,0,'{\"editlock\":\"\",\"endtime\":\"\",\"fe_group\":\"\",\"hidden\":\"\",\"starttime\":\"\",\"tx_mask_catgeory\":\"\",\"tx_mask_link_for_image\":\"\",\"tx_mask_photo_case\":\"\",\"tx_mask_text_on_image\":\"\"}',0,0,0,0,'<p>Sinisha Lüscher, &nbsp;<br />Zurich, Switzerland</p>','t3://page?uid=6',1,7,'tt_content',1),
(4,2,1762443238,1762437772,0,0,0,0,'',4,0,0,0,0,NULL,0,'{\"hidden\":\"\"}',0,0,0,0,'<p>Sinisha Lüscher, &nbsp;<br />Zurich, Switzerland</p>','t3://page?uid=6',1,7,'tt_content',1),
(5,2,1762443238,1762439342,0,0,0,0,'',5,0,0,0,0,NULL,0,'{\"editlock\":\"\",\"endtime\":\"\",\"fe_group\":\"\",\"hidden\":\"\",\"starttime\":\"\",\"tx_mask_catgeory\":\"\",\"tx_mask_link_for_image\":\"\",\"tx_mask_photo_case\":\"\",\"tx_mask_text_on_image\":\"\"}',0,0,0,0,'<p>Sinisha Lüscher,&nbsp;<br />Zurich, Switzerland</p>','t3://page?uid=6',1,7,'tt_content',1),
(6,2,1762443238,1762442661,0,0,0,0,'',6,0,0,0,0,NULL,0,'{\"editlock\":\"\",\"endtime\":\"\",\"fe_group\":\"\",\"hidden\":\"\",\"starttime\":\"\",\"tx_mask_catgeory\":\"\",\"tx_mask_link_for_image\":\"\",\"tx_mask_photo_case\":\"\",\"tx_mask_text_on_image\":\"\"}',0,0,0,0,'<p>Sinisha Lüscher,&nbsp;<br />Zurich, Switzerland</p>','t3://page?uid=6',1,7,'tt_content',1);
/*!40000 ALTER TABLE `tx_mask_all_cases` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tx_news_domain_model_link`
--

DROP TABLE IF EXISTS `tx_news_domain_model_link`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tx_news_domain_model_link` (
  `description` text DEFAULT NULL,
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `sorting` int(11) NOT NULL DEFAULT 0,
  `sys_language_uid` int(11) NOT NULL DEFAULT 0,
  `l10n_parent` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_source` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_state` text DEFAULT NULL,
  `t3_origuid` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_diffsource` mediumblob DEFAULT NULL,
  `t3ver_oid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_wsid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `parent` int(11) NOT NULL DEFAULT 0,
  `title` tinytext DEFAULT NULL,
  `uri` text DEFAULT NULL,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`,`hidden`),
  KEY `translation_source` (`l10n_source`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tx_news_domain_model_link`
--

LOCK TABLES `tx_news_domain_model_link` WRITE;
/*!40000 ALTER TABLE `tx_news_domain_model_link` DISABLE KEYS */;
/*!40000 ALTER TABLE `tx_news_domain_model_link` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tx_news_domain_model_news`
--

DROP TABLE IF EXISTS `tx_news_domain_model_news`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tx_news_domain_model_news` (
  `notes` text DEFAULT NULL,
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `fe_group` varchar(255) NOT NULL DEFAULT '0',
  `editlock` smallint(5) unsigned NOT NULL DEFAULT 0,
  `sys_language_uid` int(11) NOT NULL DEFAULT 0,
  `l10n_parent` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_source` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_state` text DEFAULT NULL,
  `t3_origuid` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_diffsource` mediumblob DEFAULT NULL,
  `t3ver_oid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_wsid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `sorting` int(11) NOT NULL DEFAULT 0,
  `title` varchar(255) NOT NULL DEFAULT '',
  `teaser` text DEFAULT NULL,
  `bodytext` mediumtext DEFAULT NULL,
  `datetime` bigint(20) NOT NULL DEFAULT 0,
  `archive` bigint(20) NOT NULL DEFAULT 0,
  `author` tinytext DEFAULT NULL,
  `author_email` tinytext DEFAULT NULL,
  `categories` int(11) NOT NULL DEFAULT 0,
  `related` int(11) NOT NULL DEFAULT 0,
  `related_from` int(11) NOT NULL DEFAULT 0,
  `related_files` tinytext DEFAULT NULL,
  `fal_related_files` int(10) unsigned DEFAULT 0,
  `related_links` int(11) NOT NULL DEFAULT 0,
  `type` varchar(100) NOT NULL DEFAULT '0',
  `keywords` text DEFAULT NULL,
  `description` text DEFAULT NULL,
  `tags` int(11) NOT NULL DEFAULT 0,
  `media` text DEFAULT NULL,
  `fal_media` int(10) unsigned DEFAULT 0,
  `internalurl` text DEFAULT NULL,
  `externalurl` text DEFAULT NULL,
  `istopnews` int(11) NOT NULL DEFAULT 0,
  `content_elements` int(11) NOT NULL DEFAULT 0,
  `path_segment` varchar(2048) DEFAULT NULL,
  `alternative_title` tinytext DEFAULT NULL,
  `sitemap_changefreq` varchar(10) NOT NULL DEFAULT '',
  `sitemap_priority` decimal(2,1) NOT NULL DEFAULT 0.5,
  `import_id` varchar(100) NOT NULL DEFAULT '',
  `import_source` varchar(100) NOT NULL DEFAULT '',
  PRIMARY KEY (`uid`),
  KEY `path_segment` (`path_segment`(185),`uid`),
  KEY `import` (`import_id`,`import_source`),
  KEY `parent` (`pid`,`deleted`,`hidden`),
  KEY `translation_source` (`l10n_source`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tx_news_domain_model_news`
--

LOCK TABLES `tx_news_domain_model_news` WRITE;
/*!40000 ALTER TABLE `tx_news_domain_model_news` DISABLE KEYS */;
/*!40000 ALTER TABLE `tx_news_domain_model_news` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tx_news_domain_model_news_related_mm`
--

DROP TABLE IF EXISTS `tx_news_domain_model_news_related_mm`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tx_news_domain_model_news_related_mm` (
  `uid_local` int(11) NOT NULL DEFAULT 0,
  `uid_foreign` int(11) NOT NULL DEFAULT 0,
  `sorting` int(11) NOT NULL DEFAULT 0,
  `sorting_foreign` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid_local`,`uid_foreign`),
  KEY `uid_local` (`uid_local`),
  KEY `uid_foreign` (`uid_foreign`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tx_news_domain_model_news_related_mm`
--

LOCK TABLES `tx_news_domain_model_news_related_mm` WRITE;
/*!40000 ALTER TABLE `tx_news_domain_model_news_related_mm` DISABLE KEYS */;
/*!40000 ALTER TABLE `tx_news_domain_model_news_related_mm` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tx_news_domain_model_news_tag_mm`
--

DROP TABLE IF EXISTS `tx_news_domain_model_news_tag_mm`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tx_news_domain_model_news_tag_mm` (
  `uid_local` int(11) NOT NULL DEFAULT 0,
  `uid_foreign` int(11) NOT NULL DEFAULT 0,
  `sorting` int(11) NOT NULL DEFAULT 0,
  `sorting_foreign` int(10) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid_local`,`uid_foreign`),
  KEY `uid_local` (`uid_local`),
  KEY `uid_foreign` (`uid_foreign`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tx_news_domain_model_news_tag_mm`
--

LOCK TABLES `tx_news_domain_model_news_tag_mm` WRITE;
/*!40000 ALTER TABLE `tx_news_domain_model_news_tag_mm` DISABLE KEYS */;
/*!40000 ALTER TABLE `tx_news_domain_model_news_tag_mm` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tx_news_domain_model_news_ttcontent_mm`
--

DROP TABLE IF EXISTS `tx_news_domain_model_news_ttcontent_mm`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tx_news_domain_model_news_ttcontent_mm` (
  `uid_local` int(11) NOT NULL DEFAULT 0,
  `uid_foreign` int(11) NOT NULL DEFAULT 0,
  `sorting` int(11) NOT NULL DEFAULT 0,
  KEY `uid_local` (`uid_local`),
  KEY `uid_foreign` (`uid_foreign`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tx_news_domain_model_news_ttcontent_mm`
--

LOCK TABLES `tx_news_domain_model_news_ttcontent_mm` WRITE;
/*!40000 ALTER TABLE `tx_news_domain_model_news_ttcontent_mm` DISABLE KEYS */;
/*!40000 ALTER TABLE `tx_news_domain_model_news_ttcontent_mm` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tx_news_domain_model_tag`
--

DROP TABLE IF EXISTS `tx_news_domain_model_tag`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tx_news_domain_model_tag` (
  `notes` text DEFAULT NULL,
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `sys_language_uid` int(11) NOT NULL DEFAULT 0,
  `l10n_parent` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_source` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_state` text DEFAULT NULL,
  `l10n_diffsource` mediumblob DEFAULT NULL,
  `t3ver_oid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_wsid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `title` tinytext DEFAULT NULL,
  `slug` varchar(2048) DEFAULT NULL,
  `seo_title` varchar(255) NOT NULL DEFAULT '',
  `seo_description` text DEFAULT NULL,
  `seo_headline` varchar(255) NOT NULL DEFAULT '',
  `seo_text` text DEFAULT NULL,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`,`hidden`),
  KEY `translation_source` (`l10n_source`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tx_news_domain_model_tag`
--

LOCK TABLES `tx_news_domain_model_tag` WRITE;
/*!40000 ALTER TABLE `tx_news_domain_model_tag` DISABLE KEYS */;
/*!40000 ALTER TABLE `tx_news_domain_model_tag` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tx_scheduler_task`
--

DROP TABLE IF EXISTS `tx_scheduler_task`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tx_scheduler_task` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `disable` smallint(5) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `description` text DEFAULT NULL,
  `nextexecution` int(10) unsigned NOT NULL DEFAULT 0,
  `lastexecution_time` int(10) unsigned NOT NULL DEFAULT 0,
  `lastexecution_failure` text DEFAULT NULL,
  `lastexecution_context` varchar(3) NOT NULL DEFAULT '',
  `serialized_task_object` mediumblob DEFAULT NULL,
  `serialized_executions` mediumblob DEFAULT NULL,
  `task_group` int(10) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `index_nextexecution` (`nextexecution`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tx_scheduler_task`
--

LOCK TABLES `tx_scheduler_task` WRITE;
/*!40000 ALTER TABLE `tx_scheduler_task` DISABLE KEYS */;
/*!40000 ALTER TABLE `tx_scheduler_task` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tx_scheduler_task_group`
--

DROP TABLE IF EXISTS `tx_scheduler_task_group`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tx_scheduler_task_group` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `sorting` int(11) NOT NULL DEFAULT 0,
  `groupName` varchar(80) NOT NULL DEFAULT '',
  `description` longtext DEFAULT NULL,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`,`hidden`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tx_scheduler_task_group`
--

LOCK TABLES `tx_scheduler_task_group` WRITE;
/*!40000 ALTER TABLE `tx_scheduler_task_group` DISABLE KEYS */;
/*!40000 ALTER TABLE `tx_scheduler_task_group` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-11-12  8:22:11
